# XM540 보행·버티기 정책 연결

> 학습부터 토크 ON/OFF와 실제 정책 실행까지 한 순서로 진행할 때는
> [XM540 통합 매뉴얼](XM540_END_TO_END_MANUAL.md)을 따른다.

> 확인된 TensorRT 10.3 로봇 환경에서는 [로봇에서 직접 TensorRT 변환](JETSON_TENSORRT.md)을
> 우선 따른다. 이 경로는 ONNX를 거치지 않는다. 아래 ONNX 방식은 대체 실행 경로다.

`RL-Model-save/RL_walk.pt`는 보행, `RL_fall_after_walk.pt`는 위험 기울기에서
버티고 보행 준비 자세로 복귀하는 정책으로 사용한다. 하나의 `xm540_dual_policy`
노드가 두 정책을 선택하고 관절 명령을 발행한다.

현재 두 체크포인트는 Ubuntu Isaac Lab 규격 추출과 관측 비교, 로봇의 TensorRT 변환,
엔진 수치 비교 및 ROS 2 preview까지 통과했다. 실제 모터 출력 검증은 별도 단계다.

## 모델 규격

| 역할 | 입력 | 출력 | 위상 | 명령 |
|---|---:|---:|---|---|
| WALK | 355 | 20 | 0.8초 주기 sin, cos | `/cmd_vel` |
| RECOVERY | 345 | 20 | 없음 | 항상 0 |

원본 `.pt` 두 파일은 RSL-RL 학습 체크포인트다. Jetson 배포 기본값은
`inference_backend=onnx`이며, 개발 PC에서 Actor만 ONNX로 내보낸다.
로봇에서는 NumPy와 ONNX Runtime CPU로 실행하므로 PyTorch가 필요하지 않다.
ONNX는 batch=1, FP32, opset 11, IR 6의 Gemm/Elu 그래프이며, 49개 입력으로 원본 출력과
비교한다. 로봇의 실제 ONNX Runtime 버전과 20ms 실행 주기 충족 여부는 별도 검증한다.
기존 `.pt` 직접 실행은 `inference_backend:=pytorch`로 명시해야 한다.

관측 순서는 몸체 각속도 ×0.2, projected gravity, 속도 명령, 기본 자세 대비 관절 위치,
관절 속도 ×0.05, 직전 action, 보행 위상(보행만)이다. **항목별 5프레임을 먼저 이어 붙이고
그다음 항목들을 결합한다.** 두 정책은 선택된 실제 action 이력을 공유하고 각자 관측 이력을
갱신한다. 위상 시계는 정책 전환 중에도 진행한다.
이력 배치는 [Isaac Lab ObservationManager](https://github.com/isaac-sim/IsaacLab/blob/main/source/isaaclab/isaaclab/managers/observation_manager.py)
기준이며, 아래 exporter가 설치된 학습 환경과 수치 비교한다.

관절 순서는 URDF 파일 순서나 모터 ID 순서로 추측하지 않는다. 실제 articulation 순서를
JSON으로 추출하고, `/joint_states.name`으로 재배열한다. 20개 위치·속도가 모두 필요하다.
JSON에는 체크포인트 SHA-256, 기본 자세, action 배율, 관절 제한, 관측 배율·이력도 저장한다.

## 1. Ubuntu 학습 환경에서 규격 추출

학습 때 사용한 코드·USD 자산·Isaac Lab 버전으로 실행한다. 현재 코드가 당시 설정과
다르면 먼저 학습 로그의 설정과 대조해야 한다. 입력 차원이 같다는 것만으로 호환성을
보장할 수 없다. 보상 함수 자체는 실물 추론에 사용되지 않는다.

아래 명령은 저장소 루트에서 실행한다. `ISAACLAB_PATH`를 실제 경로로 바꾼다.

```bash
export ISAACLAB_PATH="$HOME/IsaacLab"
"$ISAACLAB_PATH/isaaclab.sh" -p robotmodel/XM540_robot/scripts/export_sim2real_contract.py \
  --task Unitree-XM540-Velocity-Flat-v0 \
  --checkpoint RL-Model-save/RL_walk.pt \
  --output RL-Model-save/jetson/RL_walk.json \
  --onnx-output RL-Model-save/jetson/RL_walk.onnx --headless

"$ISAACLAB_PATH/isaaclab.sh" -p robotmodel/XM540_robot/scripts/export_sim2real_contract.py \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --checkpoint RL-Model-save/RL_fall_after_walk.pt \
  --output RL-Model-save/jetson/RL_fall_after_walk.json \
  --onnx-output RL-Model-save/jetson/RL_fall_after_walk.onnx --headless
```

각 exporter는 16스텝 동안 배포 관측을 시뮬레이터 관측과 비교한 뒤 JSON을 쓴다.
비교 실패 시 JSON을 손으로 채워 우회하지 말고 실제 학습 환경의 관측 구현을 확인한다.
이 검사는 관측 계산 호환성 검사이며 두 정책 전환의 물리적 안정성을 검증하는 시험은 아니다.

## 2. ROS 2 실행 환경 준비

학습 PC의 exporter에는 PyTorch, NumPy, onnx, onnxruntime이 필요하다.
로봇에는 ROS 2 Python과 호환되는 NumPy 및 ONNX Runtime CPU가 필요하다.
두 `.onnx`와 ONNX 해시가 기록된 두 `.json`을 `/home/robo04/sim2real_ws/models/`에 복사한다.
이름이 같은 이전 JSON이라도 ONNX 해시가 없으면 ONNX 실행에 사용할 수 없다.

구형 Jetson Nano와 Orin Nano는 설치 환경이 다르다. 먼저 로봇에서 다음을 확인한다.

```bash
cat /etc/nv_tegra_release
python3 --version
uname -m
echo "$ROS_DISTRO"
python3 -c "import onnxruntime as ort; print(ort.__version__, ort.get_available_providers())"
```

미설치이면 마지막 명령은 실패한다. 이 정보를 확인한 뒤 맞는 ARM64/Python 런타임을
설치해야 한다. 최신 `onnxruntime-gpu`를 일괄 설치하지 않는다. 현재 러너는 명시적으로
ONNX 모드에서는 CPUExecutionProvider를 사용한다. TensorRT 엔진은 별도
`inference_backend=tensorrt` 모드로 실행한다.
구형 Nano의 JetPack 4 계열 지원 정보는
[NVIDIA R32.7.6 안내](https://developer.nvidia.com/embedded/linux-tegra-r3276)를 참고한다.
ROS 2 배포판의 Python을 임의로 교체하지 않는다. 현 러너는 Python 3.8 이상을 대상으로 한다.

```bash
cd sim2real_ws
colcon build --symlink-install --packages-up-to humanoid_policy_runner
source install/setup.bash
```

기존 `control.launch.py`/`bringup.launch.py` 대신 이 전용 구성을 사용한다.
기존 보행·킥·기상 러너, `fall_manager_node`, 목 제어기가 동시에 관절 명령을 보내면 안 된다.
하드웨어만 실행할 때에는 전신 정책과 목 제어가 겹치지 않게 한다.

```bash
ros2 launch humanoid_serial_bridge dynamixel_system.launch.py use_neck_control:=false
```

이 실행은 실제 하드웨어를 연다. 초기 자세 전환 등 기존 하드웨어 behavior가 끝난 뒤
정책을 시작한다. 기존 초기 자세는 학습 기본 자세와 완전히 같지 않으므로 센서값을
export된 기본 자세와 대조한다. IMU는 보정된 base frame 방향, gyro는 rad/s여야 한다.

## 3. 모터 명령 없는 추론 확인

`MODEL_DIR`를 실행 PC의 절대 경로로 지정한다.

```bash
MODEL_DIR=/home/robo04/sim2real_ws/models
ros2 launch humanoid_policy_runner xm540_dual_policy.launch.py \
  inference_backend:=onnx \
  walk_checkpoint:="$MODEL_DIR/RL_walk.onnx" \
  recovery_checkpoint:="$MODEL_DIR/RL_fall_after_walk.onnx" \
  walk_contract:="$MODEL_DIR/RL_walk.json" \
  recovery_contract:="$MODEL_DIR/RL_fall_after_walk.json" \
  enter_tilt_deg:=30.0 exit_tilt_deg:=12.0 \
  publish_joint_goals:=false
```

다른 터미널:

```bash
ros2 service call /xm540_dual_policy/start std_srvs/srv/Trigger '{}'
ros2 topic echo /xm540_dual_policy/state
ros2 topic echo /xm540_dual_policy/preview_joint_goals
```

`publish_joint_goals=false`에서는 `/joint_goals` publisher 자체를 만들지 않는다.
실물 출력 확인 단계에서만 위 launch를 `publish_joint_goals:=true`로 재시작한다.
그 뒤에도 `/start`가 필요하다. 실행 중 출력 활성화로 변경할 수 없다.

실물 출력 시작에는 신선한 센서, 토크 ON 상태 수신, 하드웨어 behavior 비활성,
단독 `/joint_goals` publisher, 복귀 각도 이내 기울기와 기본 자세 오차 0.35rad 이하가 필요하다.
이 조건은 실행 전 확인이며 하드웨어 제어 성능을 보장하지 않는다.

## 4. 사용자가 조절하는 전환 파라미터

| 파라미터 | 초기값 | 의미 |
|---|---:|---|
| `enter_tilt_deg` | 30.0° | 이상이면 즉시 WALK → RECOVERY |
| `exit_tilt_deg` | 12.0° | 이하여야 보행 복귀 후보 |
| `settle_seconds` | 0.5s | 복귀 조건을 연속 유지할 시간 |
| `exit_angular_speed` | 0.5rad/s | 복귀 시 몸체 각속도 상한 |
| `exit_pose_error` | 0.35rad | 목 제외 모든 관절의 기본 자세 최대 오차 |
| `max_recovery_seconds` | 6.0s | 복귀 실패 시간 한계 |
| `stop_tilt_deg` | 75.0° | 이상이면 FAULT로 중단 |

기울기는 `acos(-projected_gravity.z)`로 계산하며 뒤집힌 자세도 검출한다.
위 값들은 실물 검증 전 초기 설정값이다. 실행 중 변경 예:

```bash
ros2 param set /xm540_dual_policy enter_tilt_deg 35.0
ros2 param set /xm540_dual_policy exit_tilt_deg 15.0
ros2 param set /xm540_dual_policy settle_seconds 0.8
```

`0 < exit < enter < stop < 180` 관계가 필요하다. 잘못된 값은 거부한다.
복귀에는 기울기뿐 아니라 각속도와 기본 자세 정렬도 필요하다. 발 접촉·몸체 높이는
현재 실물 센서에서 제공되지 않아 전환 판정에 쓰지 않는다. 넘어져 낮게 웅크린 상태에서의
복귀 오검출 여부도 시뮬레이션과 지지 상태 시험에서 확인해야 한다.

## 출력과 하드웨어 차이

- 다리는 `기본 자세 + export된 배율 × action`으로 제어하고 관절 제한으로 제한한다.
- RECOVERY에서는 어깨·팔꿈치 action도 위치 목표로 적용한다.
- WALK의 팔과 두 정책의 목은 학습에서 stiffness=0이었다. 그 관절의 actor 출력을
  실물 위치 목표로 적용하지 않고 기본 자세를 유지한다. 실제 서보의 위치 유지와 학습의
  수동 감쇠 동역학은 같지 않으므로 별도 검증이 필요하다.
- 현재 `motor_gains.yaml`의 팔 `goal_pwm: 50`은 기존 보행용이다. 버티기 정책의 팔 이동에
  충분한지 확인해야 한다. 러너는 PID/PWM/토크를 임의로 올리지 않는다. 실측한 전용
  `gain_file`로 조정해야 하며 시뮬레이터 stiffness=50을 모터 P=50으로 복사하지 않는다.
- 센서 지연·불완전한 관절 정보·추론 오류·다른 명령 발행자·정지 버튼·토크 OFF·복귀 실패는
  FAULT를 만든다. 자동으로 다시 보행하지 않으며 명시적 `/start`가 필요하다.

```bash
ros2 service call /xm540_dual_policy/stop std_srvs/srv/Trigger '{}'
```

`/stop` 및 FAULT는 새 목표 발행을 멈춘다. **모터 토크를 끄거나 마지막 위치 목표를
해제하지 않는다.** 모터 정지는 기존 하드웨어 정지 수단으로 처리한다.

## 로컬 검증

NumPy/PyTorch/onnx/onnxruntime이 있는 개발 PC Python에서:

```bash
python -m unittest discover -s sim2real_ws/src/humanoid_policy_runner/test -p test_xm540_policy.py -v
```

실제 체크포인트가 저장소의 `RL-Model-save/`에 있으면 독립적인 함수형 Actor 계산과
러너 출력을 비교한다. 없으면 해당 테스트만 skip한다. ROS 통신·Isaac Lab exporter 실행·
정책 간 물리적 전환·실물 안정성은 별도 Ubuntu 검증 대상이다.
