# 정책 실행의 NumPy 호환성 — 2026-10-07

로봇에서 NVIDIA PyTorch 2.5.0a0 nv24.08의 NumPy 변환이 NumPy 2.2.6과
호환되지 않아 `RuntimeError: Numpy is not available`로 정책 시작이 실패했다.
현재 `pyzed 5.5`는 NumPy >=2,<3을 요구하므로 전체 NumPy를 내리지 않는다.

정책 전용 폴더에 NumPy 1.26.4를 설치한다. 이 명령은 현재 로봇에 이미
적용되어 있으며 새 로봇이나 새 workspace에서 준비할 때 사용한다.

```bash
cd /home/robo04/sim2real_ws
python3 -m pip install --only-binary=:all: --no-deps \
  --target /home/robo04/sim2real_ws/.policy-python/numpy1 \
  'numpy==1.26.4'
```

정책을 실행할 터미널마다 ROS setup을 읽은 뒤 해당 경로를 추가한다.
TensorRT 엔진 생성에서도 같은 설정을 사용한다. 카메라 실행 터미널에는
이 환경 변수를 추가하지 않는다.

```bash
cd /home/robo04/sim2real_ws
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash
export PYTHONPATH="/home/robo04/sim2real_ws/.policy-python/numpy1:${PYTHONPATH:-}"

python3 - <<'PY'
import numpy as np
import torch
print('NumPy:', np.__version__, np.__file__)
assert np.__version__ == '1.26.4'
assert torch.from_numpy(np.zeros(1, dtype=np.float32)).numpy().shape == (1,)
print('Torch/NumPy conversion OK')
PY
```

이후 같은 터미널에서 기존 `ros2 launch ... xm540_dual_policy.launch.py`
명령을 실행한다. 패키지 재빌드나 엔진 재생성은 이 NumPy 변경 때문에
필요하지 않다. 실행 중인 프로세스에는 새 환경이 적용되지 않으므로
해당 정책 프로세스를 재시작해야 한다.

2026-10-07 로봇에서 두 엔진의 계약 및 해시를 확인하고 엔진마다
준비 추론 1회와 영벡터 추론 20회를 수행했다. 출력 shape (20,)와 유한값을
확인했으며 중앙 추론 시간은 WALK 0.312ms, RECOVERY 0.328ms였다.
ROS 제어 노드를 시작하거나 모터 목표를 발행하지 않은 검사다.
이는 실제 보행 안정성이나 임의의 관측 전체에 대한 정확도 검증은 아니다.

TensorRT의 엔진 기기 호환 경고는 남아 있다. 이번 두 엔진의 로드·추론은
통과했으며, 엔진 기기 호환성을 완전히 검증한 결과는 아니다.

참고: https://numpy.org/doc/stable/user/troubleshooting-importerror.html
