# 현재 소스를 Jetson에서 새로 빌드하기

2026-11-03 사용자 요청에 따른 작업이다. Windows의
`C:/Users/jes/Desktop/isaac_ws/isaac_ws/sim2real_ws`를 배포 원본으로 사용한다.
바깥쪽 `Sim to real sample`은 이번 배포 원본이 아니다.

## 범위와 순서

1. 현재 `src`, `scripts`, `docs`, `README.md`를 묶어 로봇에 전송한다.
2. 로봇 프로세스 종료와 저장 공간을 확인하고 기존 소스/빌드 산출물을 백업한다.
3. 새 소스를 풀고 ROS Humble 환경에서 9개 패키지를 새로 빌드한다.
4. 설치 경로, 실제 import 경로, 설정 차이와 기존 모델 계약을 확인한다.
5. 관절/IMU → 정책 없는 부하 유지 → Preview → 영속도 → 저속 이동 순서로 진행한다.

Windows의 `build/install`을 복사하는 작업이 아니라 Jetson에서 `colcon build`하는 작업이다.
기존 `src/build/install/log`를 작업 폴더에서 옮겨 새 빌드를 만들고, 백업은 남긴다.
로봇의 `models`, `debug_bags`, `.policy-python`, 홈의 `.ros`는 건드리지 않는다.
TensorRT 엔진 재생성은 ROS 패키지 빌드와 별도이며 이번 교체에서 자동 수행하지 않는다.

`src` 안의 기존 ONNX/인식 모델 파일은 현재 소스 구성 그대로 포함한다.
XM540 실행에 사용하던 워크스페이스 최상위 `models/`는 이 묶음에 포함하지 않는다.
새 패키지 빌드는 정책/하드웨어 노드를 시작하거나 모터를 움직이지 않는다.

## 1. 전송 — Windows PowerShell

준비된 묶음 위치:
`C:/Users/jes/Desktop/isaac_ws/sim2real_evidence/deploy/robot_source_20261103.tar.gz`.
파일별 SHA-256은 묶음 안의 `ROBOT_SOURCE_MANIFEST.json`에 기록한다.
압축파일의 SHA-256은 옆의 `.sha256` 파일에 기록한다.

```powershell
cd C:\Users\jes\Desktop\isaac_ws\sim2real_evidence\deploy
ssh robo04@192.168.1.161 "mkdir -p /home/robo04/incoming"
if ($LASTEXITCODE -ne 0) { throw 'Cannot create incoming directory' }
scp .\robot_source_20261103.tar.gz .\robot_source_20261103.tar.gz.sha256 robo04@192.168.1.161:/home/robo04/incoming/
if ($LASTEXITCODE -ne 0) { throw 'Source upload failed' }
ssh robo04@192.168.1.161 "cd /home/robo04/incoming && sha256sum -c robot_source_20261103.tar.gz.sha256"
if ($LASTEXITCODE -ne 0) { throw 'Uploaded archive verification failed' }
```

먼저 이 출력까지 확인하고 다음 단계로 진행한다.
이 묶음은 생성 시점의 스냅샷이므로 이후 로컬 소스를 수정하면 다시 만들어야 한다.

## 2. 교체 전 확인 — 로봇 터미널

로봇이 지지되어 있고 실행 중인 정책/하드웨어/자동 재시작 서비스가 종료되었는지 확인한다.
정책 Ctrl+C 또는 토픽 부재는 모터 토크 OFF를 보장하지 않는다.
다음은 읽기 전용 확인이다. 다른 ROS 도메인이나 서비스의 존재는 별도로 확인해야 한다.

```bash
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=42 ROS_LOCALHOST_ONLY=1
ros2 node list
ps -eo pid,args | grep -E '[r]os2 (launch|run)|[x]m540_dual_policy|[b]ody_motor_controller|[m]cu_bridge_node|[i]mu_parser_node'
df -h /home/robo04
du -sh /home/robo04/sim2real_ws/src /home/robo04/sim2real_ws/build /home/robo04/sim2real_ws/install /home/robo04/sim2real_ws/log 2>/dev/null
```

출력을 확인한 뒤 교체한다. 백업은 같은 홈 파일시스템에 둔다.

```bash
set -e
cd /home/robo04/sim2real_ws
test "$(pwd -P)" = /home/robo04/sim2real_ws
cd /home/robo04/incoming
sha256sum -c robot_source_20261103.tar.gz.sha256
cd /home/robo04/sim2real_ws
BACKUP=$(mktemp -d /home/robo04/sim2real_backup_20261103_XXXXXX)
for item in src build install log scripts docs README.md ROBOT_SOURCE_MANIFEST.json; do
    if [ -e "$item" ] || [ -L "$item" ]; then
        mv -- "$item" "$BACKUP/"
    fi
done
printf 'BACKUP=%s\n' "$BACKUP"
tar -xzf /home/robo04/incoming/robot_source_20261103.tar.gz -C /home/robo04/sim2real_ws
python3 - <<'PY'
import hashlib
import json
from pathlib import Path
root = Path('/home/robo04/sim2real_ws')
manifest = json.loads((root / 'ROBOT_SOURCE_MANIFEST.json').read_text())
for item in manifest['files']:
    path = root / item['path']
    if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        raise SystemExit('HASH MISMATCH: ' + item['path'])
print('SOURCE VERIFIED:', len(manifest['files']), 'files')
print('PACKAGES:', ', '.join(manifest['packages']))
PY
```

중간에 실패하면 출력된 백업 경로와 오류를 확인한다. 반복 실행하여 백업을 중첩하지 않는다.
소스 교체로 모터 설정 파일도 로컬 버전이 된다. 백업의 `servo_map.yaml`, `motor_gains.yaml`,
IMU/포트/보정 관련 설정과 새 소스를 비교한 뒤 하드웨어를 시작한다.
백업한 이전 `install`은 이전 `src`를 가리키는 심볼릭 링크를 포함할 수 있다.
복구하려면 새 `src/build/install/log`를 따로 옮기고, 백업의 원래 경로를 먼저 복원해야 한다.

## 3. 빌드 — 이전 overlay/conda가 섞이지 않은 환경

아래 명령으로 별도 셸을 열고, 이어지는 명령은 그 셸 안에서 실행한다.

```bash
env -u AMENT_PREFIX_PATH -u CMAKE_PREFIX_PATH -u COLCON_PREFIX_PATH \
    -u PYTHONPATH -u LD_LIBRARY_PATH -u ROS_PACKAGE_PATH \
    -u VIRTUAL_ENV -u CONDA_PREFIX -u CONDA_DEFAULT_ENV \
    PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
    /bin/bash --noprofile --norc
```

```bash
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=42 ROS_LOCALHOST_ONLY=1
cd /home/robo04/sim2real_ws
command -v python3
command -v colcon
colcon list --base-paths src
colcon build --base-paths src --symlink-install --executor sequential --event-handlers console_direct+
```

対象は `humanoid_behavior_interfaces`, `humanoid_bringup`, `humanoid_game_controller`,
`humanoid_localization`, `humanoid_perception`, `humanoid_policy_runner`,
`humanoid_serial_bridge`, `humanoid_strategy`, `humanoid_utils` の9個。
의존성 부족이 나오면 오류를 확인하여 필요한 항목을 처리한다. 전체 pip/NumPy 업데이트는 하지 않는다.
빌드 성공만으로 카메라·추론·모터의 실행 검증이 끝난 것은 아니다.

## 4. 빌드 후 읽기 전용 확인

```bash
source /home/robo04/sim2real_ws/install/setup.bash
ros2 pkg prefix humanoid_policy_runner
ros2 pkg prefix humanoid_serial_bridge
ros2 pkg executables humanoid_policy_runner
python3 - <<'PY'
from pathlib import Path
from importlib.util import find_spec
spec = find_spec('humanoid_policy_runner.xm540_dual_policy_node')
assert spec and spec.origin, 'Policy module not found'
path = Path(spec.origin).resolve()
print('POLICY MODULE:', path)
assert path.is_relative_to(Path('/home/robo04/sim2real_ws/src')), 'Unexpected source path'
PY
python3 scripts/repair_xm540_walk_limits.py --models /home/robo04/sim2real_ws/models
```

마지막 명령은 `--apply` 없는 읽기 전용 검사다.
0902 WALK의 학습 범위는 `vx=[-0.15,0.35]`, `vy=[-0.1,0.1]`, `wz=[-0.15,0.15]`다.
수정 적용 결과는 아직 받지 않았다. 필요하면 기존 백업 포함 수정 도구로 처리한다.
이 범위 불일치는 이동 시험 전에 해결할 항목이며 영속도 전도 원인의 확정은 아니다.

여기까지 확인한 뒤 정책 전용 NumPy 환경의 추론 재확인, 설정 비교, 관절/IMU 확인으로 진행한다.
실물 적용의 성공 조건과 남은 작업은 [실물 적용 계획](XM540_REAL_DEPLOYMENT_PLAN.md)을 참고한다.
