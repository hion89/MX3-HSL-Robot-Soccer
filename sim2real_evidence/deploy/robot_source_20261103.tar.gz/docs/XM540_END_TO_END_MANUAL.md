# XM540 학습부터 Jetson 실물 구동까지 통합 매뉴얼

이 문서는 XM540의 새 정책을 학습하고, 배포 규격을 추출하고, 로봇의 Jetson에서
TensorRT 엔진으로 변환한 뒤, 모터 토크와 정책을 안전한 순서로 실행하는 전체 절차다.

현재 사용하는 두 정책의 역할은 다음과 같다.

| 파일 | 역할 | 관측 크기 |
|---|---|---:|
| `RL_walk.pt` | 평상시 속도 명령 보행 | 355 |
| `RL_fall_after_walk.pt` | 넘어지기 시작할 때 버티고 보행 준비 자세로 복귀 | 345 |

`fall_after_walk`는 바닥에 완전히 누운 로봇을 일으키는 기상 정책이 아니다. 이미
누운 상태에서는 `RECOVERY`로 들어간 뒤 제한 시간에 자세를 회복하지 못해 `FAULT`가
되는 것이 정상이다. 완전히 누운 로봇에는 별도의 stand-up/get-up 절차를 사용한다.

영속도에서도 정책을 켜면 다리 지지가 무너지는 경우에는
[다리 제어 조건 비교](XM540_LEG_CONTROL_COMPARISON.md)를 먼저 실행한다.
같은 WALK 모델에 실물 목표 제한과 20~25ms 액션 지연을 각각 적용하여 비교하고,
기울기 정지 조건과 넘어짐 원인을 구분한다.

## 1. PC 구성과 데이터 흐름

| 구분 | 접속 정보 | 작업 경로 | 담당 작업 |
|---|---|---|---|
| Windows 개발 PC | 로컬 | `C:\Users\jes\Desktop\isaac_ws\isaac_ws` | 코드 편집, Git, 파일 중계 |
| Ubuntu 학습 서버 | `bami122@163.180.145.122` | `/home/bami122/isaac_ws` | Isaac Lab 학습, 재생, 규격 JSON 추출 |
| 로봇 Jetson | `robo04@192.168.1.161` | `/home/robo04/sim2real_ws` | TensorRT 변환, 센서·모터·정책 실행 |

학습 서버와 로봇은 서로 다른 네트워크 대역에 있으므로 배포 파일은 기본적으로
Windows를 거쳐 이동한다.

```mermaid
flowchart LR
    W[Windows\n코드와 Git] -->|push/pull| S[Ubuntu 학습 서버\nIsaac Lab]
    S -->|model_N.pt 선택| C[체크포인트 + 학습 규격 JSON]
    C -->|scp로 Windows 경유| J[로봇 Jetson]
    J -->|직접 빌드| T[TensorRT engine + 실행 계약 JSON]
    T --> P[Preview]
    P --> L[토크 ON + Live 정책]
```

배포 파일은 다음 세 종류를 구분한다.

| 파일 | 생성 위치 | 의미 |
|---|---|---|
| `RL_*.pt` | 학습 서버 | RSL-RL 원본 체크포인트 |
| `models/RL_*.json` | 학습 서버 | 관절 순서·기본자세·관측 규격이 담긴 학습 계약 |
| `models/tensorrt/RL_*.json` | 로봇 TensorRT 빌더 | 엔진 해시와 검증 결과까지 결합한 실제 실행 계약 |
| `models/tensorrt/RL_*.build.json` | 로봇 TensorRT 빌더 | 엔진 수치 비교와 속도 측정 보고서 |

`.build.json`은 실행 계약이 아니다. 일반 `.json`으로 이름을 바꾸지 않는다.

## 2. 새 터미널에서 항상 하는 환경 설정

### 2.1 학습 서버

```bash
conda activate env_isaaclab

export WORKSPACE=/home/bami122/isaac_ws
export PROJECT="$WORKSPACE/robotmodel/XM540_robot"
export ISAACLAB_PATH="${ISAACLAB_PATH:-$HOME/IsaacLab}"
export UNITREE_RL_LAB_DIR="$WORKSPACE/unitree_rl_lab"
export XM540_ASSET_DIR="$PROJECT/assets/robots/xm540"
export PYTHONPATH="$PROJECT/source/xm540_rl_lab:$UNITREE_RL_LAB_DIR/source/unitree_rl_lab:${PYTHONPATH:-}"
export TRAIN="$ISAACLAB_PATH/scripts/reinforcement_learning/rsl_rl/train.py"
export PLAY="$ISAACLAB_PATH/scripts/reinforcement_learning/rsl_rl/play.py"

test -x "$ISAACLAB_PATH/isaaclab.sh"
test -f "$TRAIN"
test -f "$PLAY"
```

### 2.2 로봇 Jetson

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash
```

위 두 `source` 명령은 로봇의 새 터미널마다 다시 실행한다.

## 3. 학습 코드를 변경했을 때 서버에 반영

보상, 관측, 기본자세 또는 PPO 설정을 변경했다면 Windows에서 변경 내용을 검토하고
저장소에 반영한 뒤 학습 서버에서 같은 커밋을 사용한다.

Windows PowerShell:

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws
git status --short
git add <이번에 변경한 파일>
git commit -m "변경 내용을 설명하는 메시지"
git push origin main
```

학습 서버:

```bash
cd /home/bami122/isaac_ws
git status --short
git pull --ff-only origin main
git rev-parse HEAD
```

학습 서버에 로컬 소스 수정이 있으면 이를 확인하기 전에는 강제로 덮어쓰거나 reset하지
않는다. 체크포인트와 규격 JSON은 반드시 실제 학습에 사용한 source/assets와 같은
checkout에서 만든다.

현재 recovery 보상과 관련된 주요 파일은 다음과 같다.

```text
robotmodel/XM540_robot/source/xm540_rl_lab/xm540_rl_lab/tasks/locomotion/xm540/
├── fall_after_walk_env_cfg.py    # reward term과 weight
├── fall_after_walk_mdp.py        # reward 계산
├── controlled_fall_env_cfg.py    # 기반 관측·행동·종료 조건
└── fall_after_walk_ppo_cfg.py    # PPO와 로그 이름
```

현재 `fall_after_walk`는 상속된 `settled` 보상을 비활성화하고, 팔 기본자세와 발바닥
정렬이 주요 회복 보상에 함께 반영되도록 구성되어 있다. 이 소스를 수정해도 기존 `.pt`는
바뀌지 않는다. 변경된 보상을 반영하려면 새로 학습하거나 이어 학습해야 한다.

정적 구조 검사는 다음으로 실행한다.

```bash
cd /home/bami122/isaac_ws/robotmodel/XM540_robot
python -m unittest discover -s tests -p 'test_fall_after_walk_structure.py' -v
python tests/validate_model.py
```

## 4. 새 WALK 정책 학습

학습 서버에서 실행한다.

```bash
conda activate env_isaaclab
cd /home/bami122/isaac_ws/robotmodel/XM540_robot

export WORKSPACE=/home/bami122/isaac_ws
export PROJECT="$WORKSPACE/robotmodel/XM540_robot"
export ISAACLAB_PATH="${ISAACLAB_PATH:-$HOME/IsaacLab}"
export UNITREE_RL_LAB_DIR="$WORKSPACE/unitree_rl_lab"
export XM540_ASSET_DIR="$PROJECT/assets/robots/xm540"
export PYTHONPATH="$PROJECT/source/xm540_rl_lab:$UNITREE_RL_LAB_DIR/source/unitree_rl_lab:${PYTHONPATH:-}"
export TRAIN="$ISAACLAB_PATH/scripts/reinforcement_learning/rsl_rl/train.py"

"$ISAACLAB_PATH/isaaclab.sh" -p "$PROJECT/scripts/launch_external.py" "$TRAIN" \
  --task Unitree-XM540-Velocity-Flat-v0 \
  --num_envs 4096 \
  --max_iterations 5000 \
  --seed 42 \
  --device cuda:0 \
  --run_name walk_YYYYMMDD_v1 \
  --headless
```

GPU 메모리가 부족하면 `--num_envs`를 `2048` 또는 `1024`로 낮춘다. 모델 규격은
바뀌지 않는다. 로그는 다음 위치에 생성된다.

```text
/home/bami122/isaac_ws/robotmodel/XM540_robot/logs/rsl_rl/
└── xm540_velocity_flat/<날짜_시간_run_name>/
    ├── model_*.pt
    ├── params/
    └── events.out.tfevents.*
```

이전 WALK 체크포인트를 이어 학습할 때만 다음 인자를 추가한다.

```bash
--resume --checkpoint /absolute/path/to/xm540_velocity_flat/.../model_N.pt
```

## 5. 새 FALL_AFTER_WALK 정책 학습

Recovery 정책은 관측 크기가 345다. 관측 크기가 355인 WALK 체크포인트에서는 이어
학습할 수 없다.

이어 학습에 사용할 수 있는 체크포인트는 다음 두 종류다.

- 이전 `xm540_fall_after_walk` 체크포인트
- 관측과 네트워크 구조가 같은 `xm540_controlled_fall` 체크포인트

```bash
conda activate env_isaaclab
cd /home/bami122/isaac_ws/robotmodel/XM540_robot

export WORKSPACE=/home/bami122/isaac_ws
export PROJECT="$WORKSPACE/robotmodel/XM540_robot"
export ISAACLAB_PATH="${ISAACLAB_PATH:-$HOME/IsaacLab}"
export UNITREE_RL_LAB_DIR="$WORKSPACE/unitree_rl_lab"
export XM540_ASSET_DIR="$PROJECT/assets/robots/xm540"
export PYTHONPATH="$PROJECT/source/xm540_rl_lab:$UNITREE_RL_LAB_DIR/source/unitree_rl_lab:${PYTHONPATH:-}"
export TRAIN="$ISAACLAB_PATH/scripts/reinforcement_learning/rsl_rl/train.py"

RECOVERY_BASE=/absolute/path/to/compatible/model_N.pt
test -f "$RECOVERY_BASE"

"$ISAACLAB_PATH/isaaclab.sh" -p "$PROJECT/scripts/launch_external.py" "$TRAIN" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --num_envs 4096 \
  --max_iterations 3000 \
  --seed 42 \
  --device cuda:0 \
  --run_name fall_after_walk_YYYYMMDD_v1 \
  --headless \
  --resume --checkpoint "$RECOVERY_BASE"
```

호환되는 기반 체크포인트가 없으면 마지막 줄의 `--resume --checkpoint ...`를 제거하고
처음부터 학습한다. 로그는 다음 위치에 생성된다.

```text
/home/bami122/isaac_ws/robotmodel/XM540_robot/logs/rsl_rl/
└── xm540_fall_after_walk/<날짜_시간_run_name>/
```

## 6. 배포할 체크포인트 선택과 시뮬레이션 재생

가장 큰 iteration 번호를 자동으로 배포하지 않는다. TensorBoard 보상 추이와 Isaac Sim
재생을 함께 보고 후보를 명시적으로 선택한다.

최근 WALK 후보:

```bash
find "$PROJECT/logs/rsl_rl/xm540_velocity_flat" \
  -type f -name 'model_*.pt' -printf '%T@ %p\n' | sort -n | tail -20
```

최근 recovery 후보:

```bash
find "$PROJECT/logs/rsl_rl/xm540_fall_after_walk" \
  -type f -name 'model_*.pt' -printf '%T@ %p\n' | sort -n | tail -20
```

WALK 재생:

```bash
WALK_CKPT=/absolute/path/to/xm540_velocity_flat/.../model_N.pt

"$ISAACLAB_PATH/isaaclab.sh" -p "$PROJECT/scripts/launch_external.py" "$PLAY" \
  --task Unitree-XM540-Velocity-Flat-v0 \
  --checkpoint "$WALK_CKPT" \
  --num_envs 1 \
  --device cuda:0 \
  --real-time
```

Recovery 재생:

```bash
RECOVERY_CKPT=/absolute/path/to/xm540_fall_after_walk/.../model_N.pt

"$ISAACLAB_PATH/isaaclab.sh" -p "$PROJECT/scripts/launch_external.py" "$PLAY" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --checkpoint "$RECOVERY_CKPT" \
  --num_envs 1 \
  --device cuda:0 \
  --real-time
```

배포 원본은 run 디렉터리의 `model_N.pt`다. 재생 과정에서 만들어질 수 있는
`exported/policy.pt`는 현재 직접 TensorRT 변환기의 입력으로 사용하지 않는다.

## 7. 선택한 모델을 release로 고정

학습 서버에서 실행한다. `RELEASE_ID`는 실제 날짜와 버전으로 바꾼다.

```bash
export WORKSPACE=/home/bami122/isaac_ws
export RELEASE_ID=YYYYMMDD_v1
export RELEASE="$WORKSPACE/RL-Model-save/releases/$RELEASE_ID"

mkdir -p "$RELEASE"
cp -- "$WALK_CKPT" "$RELEASE/RL_walk.pt"
cp -- "$RECOVERY_CKPT" "$RELEASE/RL_fall_after_walk.pt"

sha256sum \
  "$RELEASE/RL_walk.pt" \
  "$RELEASE/RL_fall_after_walk.pt" | tee "$RELEASE/SHA256SUMS"

git -C "$WORKSPACE" rev-parse HEAD | tee "$RELEASE/source_commit.txt"
git -C "$WORKSPACE" status --short | tee "$RELEASE/source_status.txt"
```

선택한 run의 `params/env.yaml`과 `params/agent.yaml`도 release 폴더에 복사해 두는 것을
권장한다. 이름을 `RL_walk.pt`로 바꾸어도 파일 내용과 SHA-256은 바뀌지 않는다.

## 8. 학습 서버에서 규격 JSON 생성

TensorRT 엔진만으로는 관절 순서, 기본자세, action scale, 관측 이력 배치를 알 수 없다.
이 정보는 학습 서버에서 같은 source/assets로 추출한다. ONNX는 만들지 않는다.

```bash
cd /home/bami122/isaac_ws

"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/export_sim2real_contract.py" \
  --task Unitree-XM540-Velocity-Flat-v0 \
  --checkpoint "$RELEASE/RL_walk.pt" \
  --output "$RELEASE/RL_walk.json" \
  --headless

"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/export_sim2real_contract.py" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --checkpoint "$RELEASE/RL_fall_after_walk.pt" \
  --output "$RELEASE/RL_fall_after_walk.json" \
  --headless
```

`--onnx-output`은 넣지 않는다. Exporter는 다음 항목을 실제 Isaac Lab 환경에서 확인한다.

- 해석된 20개 관절 이름과 순서
- 기본 관절 자세, action scale과 관절 제한
- 관측 term 순서와 scale
- term별 5프레임 history 배치
- ELU Actor와 normalization 사용 여부
- 16 step 동안 Isaac Lab 관측과 배포 관측의 수치 일치

Exporter가 실패하면 JSON을 수동으로 만들어 통과시키지 않는다. 학습 코드, 자산,
체크포인트가 서로 맞는지 먼저 확인한다.

생성된 pair를 확인한다.

```bash
export RELEASE
python3 - <<'PY'
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ["RELEASE"])
specs = (
    ("RL_walk", "walk", 355),
    ("RL_fall_after_walk", "recovery", 345),
)
for stem, role, size in specs:
    checkpoint = root / f"{stem}.pt"
    contract = json.loads((root / f"{stem}.json").read_text())
    digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    assert contract["checkpoint_sha256"] == digest
    assert contract["role"] == role
    assert contract["observation_size"] == size
    assert contract["observation_parity_max_error"] <= 1e-3
    print(stem, role, size, digest)
PY
```

## 9. 학습 서버에서 Windows로 release 가져오기

Windows PowerShell에서 `RELEASE_ID`를 앞 단계와 같게 지정한다.

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws

$server = 'bami122@163.180.145.122'
$releaseId = 'YYYYMMDD_v1'
$serverRelease = "/home/bami122/isaac_ws/RL-Model-save/releases/$releaseId"
$localRelease = ".\RL-Model-save\releases\$releaseId"

New-Item -ItemType Directory -Force $localRelease | Out-Null

scp "${server}:${serverRelease}/RL_walk.pt" $localRelease
scp "${server}:${serverRelease}/RL_walk.json" $localRelease
scp "${server}:${serverRelease}/RL_fall_after_walk.pt" $localRelease
scp "${server}:${serverRelease}/RL_fall_after_walk.json" $localRelease
scp "${server}:${serverRelease}/SHA256SUMS" $localRelease
```

Windows에서도 해시를 기록한다.

```powershell
Get-FileHash -Algorithm SHA256 `
  "$localRelease\RL_walk.pt", `
  "$localRelease\RL_fall_after_walk.pt"
```

## 10. 로봇의 기존 모델 백업

새 모델을 덮어쓰기 전에 로봇 터미널에서 실행한다.

```bash
cd /home/robo04/sim2real_ws

STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="models/archive/$STAMP"
mkdir -p "$BACKUP"

cp -a models/RL_walk.pt models/RL_walk.json "$BACKUP/" 2>/dev/null || true
cp -a models/RL_fall_after_walk.pt models/RL_fall_after_walk.json "$BACKUP/" 2>/dev/null || true
test -d models/tensorrt && cp -a models/tensorrt "$BACKUP/"

echo "backup: /home/robo04/sim2real_ws/$BACKUP"
```

정책 프로세스가 실행 중이라면 `/stop`을 호출하고 프로세스를 종료한 뒤 모델을 교체한다.

## 11. Windows에서 로봇으로 새 모델 전송

Windows PowerShell:

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws

$robot = 'robo04@192.168.1.161'
$robotWs = '/home/robo04/sim2real_ws'
$releaseId = 'YYYYMMDD_v1'
$localRelease = ".\RL-Model-save\releases\$releaseId"

ssh $robot "mkdir -p $robotWs/models"

scp `
  "$localRelease\RL_walk.pt" `
  "$localRelease\RL_walk.json" `
  "$localRelease\RL_fall_after_walk.pt" `
  "$localRelease\RL_fall_after_walk.json" `
  "${robot}:${robotWs}/models/"
```

로봇의 입력 모델 폴더는 정확히 다음 네 파일을 가져야 한다.

```text
/home/robo04/sim2real_ws/models/
├── RL_walk.pt
├── RL_walk.json
├── RL_fall_after_walk.pt
└── RL_fall_after_walk.json
```

`RL_walk.pt`와 `RL_walk.json`은 같은 체크포인트 pair여야 하고 recovery도 마찬가지다.

## 12. 실행 코드가 바뀌었을 때만 로봇 코드 갱신

모델 네 파일만 바뀌었다면 `colcon build`는 필요 없다. 정책 Python, launch 또는
`setup.py`가 바뀌었을 때만 다음 절차를 사용한다.

Windows PowerShell:

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws

$robot = 'robo04@192.168.1.161'
$robotWs = '/home/robo04/sim2real_ws'

ssh $robot "mkdir -p $robotWs/src/humanoid_policy_runner/humanoid_policy_runner $robotWs/src/humanoid_policy_runner/launch"

$modules = @(
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_policy.py',
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_dual_policy_node.py',
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_tensorrt.py',
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_build_tensorrt.py'
)

scp $modules "${robot}:${robotWs}/src/humanoid_policy_runner/humanoid_policy_runner/"
scp .\sim2real_ws\src\humanoid_policy_runner\setup.py "${robot}:${robotWs}/src/humanoid_policy_runner/"
scp .\sim2real_ws\src\humanoid_policy_runner\launch\xm540_dual_policy.launch.py "${robot}:${robotWs}/src/humanoid_policy_runner/launch/"
```

로봇:

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash

colcon build --symlink-install --packages-up-to humanoid_policy_runner
source install/setup.bash
```

예전의 `launch/__pycache__` 복사 오류가 다시 나오면 최신 `setup.py`가 복사됐는지
확인한다. 최신 설치 규칙은 `launch/*.launch.py` 중 실제 파일만 복사한다.

## 13. 로봇에서 TensorRT 엔진 생성

확인된 로봇 환경은 Jetson Linux R36.4.0, Python 3.10.12, NVIDIA PyTorch 2.5
nv24.08 계열, TensorRT 10.3, CUDA GPU `Orin`이다. ONNX, ONNX Runtime,
PyCUDA는 이 변환 경로에 필요하지 않다.

환경을 확인한다.

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash
source install/setup.bash

python3 -c "import torch, tensorrt; print('CUDA:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0)); print('TensorRT:', tensorrt.__version__)"
```

두 모델을 FP32 엔진으로 만든다.

```bash
python3 -m humanoid_policy_runner.xm540_build_tensorrt \
  --models /home/robo04/sim2real_ws/models \
  --precision fp32
```

현재 변환기는 다음 Actor만 지원한다.

- 입력 355인 WALK 또는 입력 345인 RECOVERY
- Linear `512 → 256 → 128 → 20`
- 은닉층 activation `ELU`
- empirical normalization 미사용

구조가 달라진 체크포인트는 억지로 변환하지 않고 오류로 거부한다. 구조를 변경해 새로
학습했다면 변환기와 실행기의 규격도 함께 갱신해야 한다.

각 엔진은 원본 PyTorch Actor와 97개 입력을 비교하고, 20회 워밍업 후 200회 추론
시간을 기록한다. 성공하려면 두 결과 모두 다음 값을 가져야 한다.

```text
"engine_verified": true
"deployment_contract_available": true
```

최종 폴더에는 여섯 파일이 있어야 한다.

```text
/home/robo04/sim2real_ws/models/tensorrt/
├── RL_walk.engine
├── RL_walk.build.json
├── RL_walk.json
├── RL_fall_after_walk.engine
├── RL_fall_after_walk.build.json
└── RL_fall_after_walk.json
```

확인 명령:

```bash
ls -lh /home/robo04/sim2real_ws/models/tensorrt/

grep -H '"engine_verified"\|"deployment_contract_available"' \
  /home/robo04/sim2real_ws/models/tensorrt/*.build.json
```

TensorRT 엔진은 만든 Jetson과 TensorRT 버전에 종속된다. JetPack/TensorRT를
업데이트하거나 다른 Jetson으로 옮기면 해당 장치에서 다시 빌드한다. 우선 FP32로
검증하고 FP16은 별도 시험을 마친 경우에만 사용한다.

## 14. 로봇 하드웨어 설정 위치

실제 하드웨어 설정은 다음 파일에서 관리한다.

| 설정 | 파일 |
|---|---|
| 관절 이름, 모터 ID, 방향, 영점, 제한 | `src/humanoid_serial_bridge/config/servo_map.yaml` |
| PID, Goal PWM 등 모터 게인 | `src/humanoid_serial_bridge/config/motor_gains.yaml` |
| 로봇별 IMU 장착 보정 | `src/humanoid_bringup/config/robot_params.yaml` |
| 정책 전환 각도와 시간 | `xm540_dual_policy.launch.py` 인자 또는 ROS parameter |
| 학습 관절 기본자세·action scale | TensorRT 배포 계약 `RL_*.json` |

학습의 stiffness 값을 Dynamixel P gain에 같은 숫자로 복사하지 않는다. 두 값은 단위와
제어 계층이 다르다. 모터 게인을 수정했다면 다음으로 다시 적용할 수 있다.

```bash
ros2 service call /body_motor_controller/reload_gains std_srvs/srv/Trigger '{}'
```

Recovery 정책은 팔 action도 실제 목표로 사용한다. 따라서 팔 Goal PWM이 기본자세 복귀에
충분한지는 로봇을 지지한 시험에서 확인한다.

## 15. 하드웨어 브리지 실행과 센서 확인

로봇 터미널 A:

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash
source install/setup.bash

ls -l /dev/ttyACM0 /dev/ttyUSB0

ros2 launch humanoid_serial_bridge dynamixel_system.launch.py \
  use_neck_control:=false \
  gain_file:=/home/robo04/sim2real_ws/src/humanoid_serial_bridge/config/motor_gains.yaml
```

기본 포트는 다음과 같다.

- MCU/IMU: `/dev/ttyACM0`, 115200 baud
- U2D2/모터: `/dev/ttyUSB0`, 3000000 baud

XM540 dual policy가 20개 관절 전체를 소유하므로 `use_neck_control:=false`를 사용한다.
기존 walking/get-up/kick runner, `fall_manager_node`, `neck_control_node`처럼
`/joint_goals`를 발행하는 노드는 동시에 실행하지 않는다.

다른 터미널에서 센서를 확인한다.

```bash
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

ros2 node list | grep -E 'body_motor_controller|imu_parser|button_input'
ros2 service list | grep -E '^/u2d2/(torque_enable|robot_init|motor_reset)$'

ros2 topic echo /imu/data --once
ros2 topic echo /joint_states --once
```

`/joint_states`에는 서로 다른 20개 관절 이름과 position, velocity가 모두 있어야 한다.

## 16. 토크 ON/OFF와 초기자세

하드웨어 브리지는 시작할 때 토크를 자동으로 켜지 않는다.

### 16.1 토크만 켜기

로봇을 지지한 상태에서 실행한다.

```bash
ros2 service call /u2d2/torque_enable \
  humanoid_behavior_interfaces/srv/TorqueEnable \
  "{enable: true}"
```

상태 확인:

```bash
ros2 topic echo /u2d2/torque_enabled std_msgs/msg/Bool \
  --qos-durability transient_local --once
```

`data: true`가 나와야 한다.

### 16.2 권장 방법: 토크를 켜고 초기자세까지 이동

실물 정책을 실행하기 전에는 단순 토크 ON보다 `robot_init`을 권장한다. 이 서비스는
토크 ON, 초기 이동 속도 설정, 다리·팔·목 초기자세 이동, 최종 속도 복원을 순서대로
수행한다.

```bash
ros2 service call /u2d2/robot_init \
  humanoid_behavior_interfaces/srv/RobotInit \
  "{init_rpm: 20.0, final_rpm: 45.0, pos_tolerance_rad: 0.05, settle_count: 10, timeout_sec: 5.0}"
```

응답의 `robot_init started`는 완료가 아니라 요청이 접수됐다는 뜻이다. 다음 토픽에서
`"active": false`가 될 때까지 기다린다.

```bash
ros2 topic echo /u2d2/behavior_status
```

### 16.3 토크 끄기

로봇을 잡아 지지한 뒤 실행한다.

```bash
ros2 service call /u2d2/torque_enable \
  humanoid_behavior_interfaces/srv/TorqueEnable \
  "{enable: false}"
```

정책의 `/stop`, `Ctrl+C`, `FAULT`는 새 목표 발행을 멈출 뿐 토크를 끄지 않는다.
완전히 힘을 빼려면 위 토크 OFF 서비스 또는 물리 STOP 버튼을 사용한다.

물리 버튼 동작은 다음과 같다.

- 물리 START: `robot_init` 실행. 정책 `/start`는 별도로 호출해야 한다.
- 물리 STOP: 정책이 live이면 `FAULT`로 전환되고 전신 토크를 끈다.

## 17. 모터 출력 없는 Preview

터미널 B에서 실행한다.

```bash
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

MODEL_DIR=/home/robo04/sim2real_ws/models/tensorrt

ros2 launch humanoid_policy_runner xm540_dual_policy.launch.py \
  inference_backend:=tensorrt \
  walk_checkpoint:="$MODEL_DIR/RL_walk.engine" \
  recovery_checkpoint:="$MODEL_DIR/RL_fall_after_walk.engine" \
  walk_contract:="$MODEL_DIR/RL_walk.json" \
  recovery_contract:="$MODEL_DIR/RL_fall_after_walk.json" \
  enter_tilt_deg:=30.0 \
  exit_tilt_deg:=12.0 \
  settle_seconds:=0.5 \
  exit_angular_speed:=0.5 \
  exit_pose_error:=0.35 \
  max_recovery_seconds:=6.0 \
  stop_tilt_deg:=75.0 \
  publish_joint_goals:=false
```

터미널 C:

```bash
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

ros2 service call /xm540_dual_policy/start std_srvs/srv/Trigger '{}'
ros2 topic echo /xm540_dual_policy/state
```

직립 상태의 정상 출력:

```json
{"mode":"WALK","running":true,"publish_joint_goals":false,"error":""}
```

목표 관절과 발행 주기도 확인한다.

```bash
ros2 topic echo /xm540_dual_policy/preview_joint_goals --once
ros2 topic hz /xm540_dual_policy/preview_joint_goals
```

`publish_joint_goals:=false`에서는 `/joint_goals` publisher 자체를 만들지 않으므로
모터 목표를 보내지 않는다.

Preview 전환 시험은 로봇을 지지한 채 수행한다.

1. 직립 상태에서는 `WALK`인지 확인한다.
2. 30° 이상 기울이면 `RECOVERY`인지 확인한다.
3. 6초 안에 12° 이하로 다시 세우고 움직임을 멈춘다.
4. 기본자세 오차도 범위 안이면 0.5초 후 `WALK`로 복귀한다.

누워 있는 로봇으로 preview를 시작하면 `RECOVERY` 후 6초 뒤 `FAULT`가 되는 것이
정상이다. 모터 출력이 없으므로 스스로 자세를 회복할 수 없기 때문이다.

## 18. 전환 파라미터

| 파라미터 | 기본값 | 의미 |
|---|---:|---|
| `enter_tilt_deg` | 30° | 이상이면 WALK에서 RECOVERY로 전환 |
| `exit_tilt_deg` | 12° | 이하일 때만 WALK 복귀 후보 |
| `settle_seconds` | 0.5 s | 모든 복귀 조건을 연속 유지할 시간 |
| `exit_angular_speed` | 0.5 rad/s | WALK 복귀 허용 몸체 각속도 |
| `exit_pose_error` | 0.35 rad | 목을 제외한 관절의 기본자세 최대 오차 |
| `max_recovery_seconds` | 6.0 s | 초과하면 FAULT |
| `stop_tilt_deg` | 75° | 이상이면 즉시 FAULT |

복귀하려면 기울기, 각속도, 관절 기본자세 오차를 동시에 만족해야 한다.

실행 중 조정 예:

```bash
ros2 param set /xm540_dual_policy enter_tilt_deg 35.0
ros2 param set /xm540_dual_policy exit_tilt_deg 15.0
ros2 param set /xm540_dual_policy max_recovery_seconds 8.0
```

항상 `0 < exit < enter < stop < 180`을 만족해야 하며 recovery 제한 시간은
settle 시간보다 길어야 한다.

## 19. 실제 모터 정책 실행

Preview 정책 프로세스를 `Ctrl+C`로 완전히 종료한다. `publish_joint_goals`는 실행 중에
변경할 수 없으므로 live 모드로 새로 실행해야 한다.

먼저 충돌하는 publisher가 없는지 확인한다.

```bash
ros2 topic info /joint_goals -v
```

Live 정책을 시작하기 전 조건은 다음과 같다.

- `/imu/data`와 20개 `/joint_states`가 최신 상태
- `/u2d2/torque_enabled`가 `true`
- 물리 STOP 버튼 해제
- `/u2d2/behavior_status`가 `active: false`
- `/joint_goals`를 발행할 노드가 XM540 dual policy 하나뿐
- 로봇 기울기가 기본 12° 이하
- 목을 제외한 관절이 exported 기본자세에서 기본 0.35 rad 이내

터미널 B에서 preview와 같은 명령을 사용하되 마지막 인자만 바꾼다.

```bash
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

MODEL_DIR=/home/robo04/sim2real_ws/models/tensorrt

ros2 launch humanoid_policy_runner xm540_dual_policy.launch.py \
  inference_backend:=tensorrt \
  walk_checkpoint:="$MODEL_DIR/RL_walk.engine" \
  recovery_checkpoint:="$MODEL_DIR/RL_fall_after_walk.engine" \
  walk_contract:="$MODEL_DIR/RL_walk.json" \
  recovery_contract:="$MODEL_DIR/RL_fall_after_walk.json" \
  enter_tilt_deg:=30.0 \
  exit_tilt_deg:=12.0 \
  settle_seconds:=0.5 \
  exit_angular_speed:=0.5 \
  exit_pose_error:=0.35 \
  max_recovery_seconds:=6.0 \
  stop_tilt_deg:=75.0 \
  publish_joint_goals:=true
```

Live launch만으로 모터 목표가 시작되지는 않는다. 로봇을 직립 상태로 지지한 뒤 명시적으로
시작한다.

```bash
ros2 service call /xm540_dual_policy/start std_srvs/srv/Trigger '{}'
ros2 topic echo /xm540_dual_policy/state
```

시작 조건이 맞지 않으면 서비스 응답에 실제 기울기 또는 가장 오차가 큰 관절 이름과
오차가 표시된다. 원인을 고친 뒤 다시 `/start`를 호출한다.

## 20. WALK 속도 명령

속도 명령이 없거나 0.5초 이상 오래되면 WALK 정책에는 영벡터가 들어간다. 시험 명령은
작은 값부터 연속 발행한다.

```bash
ros2 topic pub --rate 10 /cmd_vel geometry_msgs/msg/Twist \
  "{linear: {x: 0.05, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
```

명령 publisher를 `Ctrl+C`로 종료하면 0.5초 후 정책 명령은 자동으로 0이 된다. 현재
계약의 명령 범위는 실행기가 자동으로 clip하지만 실물 시험은 작은 명령부터 올린다.

RECOVERY 모드에서는 `/cmd_vel`과 관계없이 속도 명령 관측을 항상 0으로 만든다.

## 21. 정상 정지와 재시작

정상 종료 순서는 정책 정지 후 토크 OFF다.

```bash
ros2 service call /xm540_dual_policy/stop std_srvs/srv/Trigger '{}'

ros2 service call /u2d2/torque_enable \
  humanoid_behavior_interfaces/srv/TorqueEnable \
  "{enable: false}"
```

`FAULT` 이후에도 토크는 자동으로 꺼지지 않을 수 있다. 원인을 해결한 뒤 다음 순서로
재가동한다.

1. 물리 STOP 해제
2. 로봇 지지 및 직립
3. `robot_init` 실행
4. `/u2d2/behavior_status`의 `active: false` 확인
5. 토크, IMU, 관절 상태 확인
6. `/xm540_dual_policy/start` 재호출

## 22. 새 모델 교체 시 축약 체크리스트

```text
[학습 서버]
1. 같은 source/assets에서 WALK와 RECOVERY 학습
2. model_N.pt 후보를 각각 Isaac Sim에서 재생
3. 선택본을 RL_walk.pt / RL_fall_after_walk.pt로 release 폴더에 복사
4. exporter로 같은 이름의 일반 JSON 두 개 생성
5. checkpoint hash와 JSON hash 일치 확인

[Windows]
6. release의 pt 2개 + JSON 2개를 학습 서버에서 내려받기
7. 로봇의 /home/robo04/sim2real_ws/models/로 네 파일 함께 전송

[로봇]
8. 기존 모델 백업
9. xm540_build_tensorrt --precision fp32 실행
10. engine_verified=true, deployment_contract_available=true 확인
11. publish_joint_goals=false preview와 전환 시험
12. robot_init과 토크·센서·단독 publisher 확인
13. preview 종료 후 publish_joint_goals=true로 재실행
14. /start 호출 후 작은 cmd_vel부터 시험
15. 종료 시 정책 /stop 후 torque OFF
```

## 23. 문제 해결

### `deployment_contract_available: false`

`models/`의 `.pt` 옆에 학습 서버가 만든 같은 이름의 일반 `.json`이 없다는 뜻이다.
올바른 JSON을 복사한 뒤 TensorRT 빌드 명령을 다시 실행한다.

### 엔진은 있는데 `.build.json`만 있음

학습 계약 JSON 없이 엔진만 만든 상태다. `.build.json`을 이름 변경하지 않는다.
학습 서버에서 JSON을 만들고 원본 `.pt` 옆에 놓은 뒤 다시 빌드한다.

### `Contract belongs to a different checkpoint`

`.pt`와 `.json`이 서로 다른 학습 결과다. 같은 release의 pair를 네 파일 모두 다시
복사한다.

### TensorRT 버전 변경 또는 engine deserialize 실패

해당 로봇에서 현재 TensorRT로 엔진을 다시 빌드한다. 다른 Jetson에서 만든 엔진을
그대로 복사하지 않는다.

### `Waiting for valid IMU and all 20 joint positions/velocities`

```bash
ros2 topic echo /imu/data --once
ros2 topic echo /joint_states --once
```

timestamp가 최신인지, 관절 이름이 20개인지, position과 velocity가 모두 있는지 확인한다.

### `Motor torque is off/unknown or stop button is pressed`

물리 STOP을 해제하고 전신 토크 서비스를 호출한 뒤 latched 토픽을 확인한다.

### `Hardware behavior status is active or stale`

`robot_init`, stand-up 또는 kick이 끝날 때까지 기다린다. 브리지의
`/u2d2/behavior_status`가 계속 발행되는지도 확인한다.

### `/joint_goals` publisher 충돌

```bash
ros2 topic info /joint_goals -v
```

기존 walking/get-up/kick runner, `fall_manager_node`, 목 제어기 등 다른 publisher를
종료한다.

### 직립인데 즉시 `RECOVERY`

IMU quaternion, 장착 방향 또는 `robot_params.yaml`의 roll/pitch 보정을 확인한다.
직립에서 projected gravity는 `[0, 0, -1]`에 가까워야 한다.

### 누운 상태에서 `RECOVERY → FAULT`

정상 동작이다. `fall_after_walk`는 완전 기상 정책이 아니며 preview에서는 모터 출력도
없다.

### `Recovery tilt limit or timeout reached`

설정된 정지 각도를 넘었거나 기본 8초 안에 복귀 조건을 만족하지 못했다. 로봇을 지지해 원인을
해결하고 명시적으로 `/start`를 다시 호출한다.

### 정책 `/stop` 후에도 로봇에 힘이 있음

정책 `/stop`은 목표 발행만 멈춘다. `/u2d2/torque_enable`에 `enable: false`를 호출한다.

### CUDA가 `False`

일반 PC용 pip PyTorch로 NVIDIA 패키지를 덮어쓰지 않는다. JetPack과 호환되는 NVIDIA
PyTorch/TensorRT 설치를 복구한다.

## 24. 현재 검증된 기준 모델

2026-09-21 기준 체크포인트 식별값:

| 모델 | SHA-256 |
|---|---|
| WALK | `9ac0d65d4c27e8d95c05f3e350ec39b0b322c21f345ca30bab26ad1a9dcdd1b8` |
| RECOVERY | `fdcb3485d025699dfeef7a80faa88b9f77bb874e12851e6edf46cbb104d9d2a8` |

로봇에서 FP32 TensorRT 변환과 97개 입력 parity 검사가 통과했다. 단독 추론은 두
모델 모두 약 0.21 ms 중앙값으로 측정됐다. 모터 출력이 없는 preview에서 다음 상태를
확인했다.

- 직립: `WALK`, `running: true`, 오류 없음
- 누움: `RECOVERY`, 자세 미복귀 시 제한 시간 후 `FAULT`

이 기록은 현재 모델의 식별과 소프트웨어 경로 검증 결과다. 새 모델을 학습하면 해시와
성능 수치를 새 release 기록으로 교체한다.

## 25. 2026-09-23 실물 시험 반영 재학습 설정

실물에서 영속도 명령인데 오른쪽으로 떨며 회전한 현상과 WALK에서 넘어지는 실제 관절
상태에서 RECOVERY가 복귀하지 못한 현상을 반영했다.

- WALK 영속도 환경 비율: `0.10 → 0.35`
- 영속도 몸체 xy 이동과 yaw 회전 직접 벌점
- 영속도 기본 자세 이탈과 좌우 거울 대칭 오차 벌점
- 몸통 질량 `±0.30 kg` 랜덤화 추가
- RECOVERY 초기 기울기: `0.26~0.90 rad`(약 15~52°)
- RECOVERY 초기 각속도: `0.0~1.8 rad/s`
- RECOVERY 초기 수평속도: 축별 `-0.35~0.35 m/s`로 실제 WALK 전환 상태를 근사
- RECOVERY 관절 위치 노이즈: `±0.20 rad`
- RECOVERY 관절 속도: `-1.5~1.5 rad/s`
- RECOVERY 학습 및 실물 제한 시간: 8초
- 실물 목표 변화 제한: WALK `0.04 rad/step`, RECOVERY `0.08 rad/step`

이 변경 뒤에는 기존 TensorRT 엔진을 재사용하지 않는다. WALK와 FALL_AFTER_WALK를 다시
학습하고 새 `.pt`와 계약 JSON을 내보낸 뒤 Jetson에서 엔진을 다시 생성한다. 학습 명령은
4장과 5장을 사용하고, 재생할 때 다음 세 고정 명령을 각각 확인한다.

```bash
export RL_PLAY_RANDOM_INITIAL_STATE=0
export RL_PLAY_RANDOM_FRICTION=0
export RL_PLAY_RANDOM_COMMANDS=0

# 정지 안정성
export RL_PLAY_VELOCITY_COMMAND=0.0,0.0,0.0

# 저속 전진
export RL_PLAY_VELOCITY_COMMAND=0.1,0.0,0.0

# 보통 전진
export RL_PLAY_VELOCITY_COMMAND=0.2,0.0,0.0
```

정지 시험에서는 제자리 회전과 좌우 이동이 없어야 하며, 전진 시험에서는 좌우 발의 보폭과
몸체 yaw 변화가 대칭이어야 한다.

## 26. 로봇에서 정책 직접 시작하기

다음 명령은 브리지와 `robot_init`, 토크 ON이 완료되고 로봇을 안전한 장소에 세운 뒤
실행한다. 새 터미널마다 ROS 환경 네 줄을 다시 적용해야 한다.

### 터미널 A: 기존 정책 정리 후 Live 정책 실행

```bash
cd /home/robo04/sim2real_ws
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

timeout 3 ros2 service call /xm540_dual_policy/stop std_srvs/srv/Trigger '{}' || true
pkill -INT -f '[x]m540_dual_policy' || true
sleep 3

MODEL_DIR=/home/robo04/sim2real_ws/models/tensorrt

ros2 launch humanoid_policy_runner xm540_dual_policy.launch.py \
  inference_backend:=tensorrt \
  walk_checkpoint:="$MODEL_DIR/RL_walk.engine" \
  recovery_checkpoint:="$MODEL_DIR/RL_fall_after_walk.engine" \
  walk_contract:="$MODEL_DIR/RL_walk.json" \
  recovery_contract:="$MODEL_DIR/RL_fall_after_walk.json" \
  enter_tilt_deg:=20.0 \
  exit_tilt_deg:=10.0 \
  settle_seconds:=0.5 \
  exit_angular_speed:=0.5 \
  exit_pose_error:=0.35 \
  max_recovery_seconds:=8.0 \
  stop_tilt_deg:=55.0 \
  startup_blend_seconds:=2.0 \
  max_goal_step_rad:=0.04 \
  recovery_max_goal_step_rad:=0.08 \
  publish_joint_goals:=true
```

이 터미널은 닫지 않는다. `waiting for ~/start`가 출력될 때까지 기다린다.

### 터미널 B: 정책 시작과 상태 확인

```bash
cd /home/robo04/sim2real_ws
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

ros2 service call /xm540_dual_policy/start std_srvs/srv/Trigger '{}'
ros2 topic echo /xm540_dual_policy/state
```

정상 시작 상태는 `mode: WALK`, `running: true`, `publish_joint_goals: true`이다.

### 터미널 C: 작은 전진 명령

```bash
cd /home/robo04/sim2real_ws
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

ros2 topic pub --rate 10 /cmd_vel geometry_msgs/msg/Twist \
  "{linear: {x: 0.10, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
```

`Ctrl+C`를 누르면 0.5초 뒤 정책 입력이 자동으로 영속도가 된다.

### 정상 종료

```bash
ros2 service call /xm540_dual_policy/stop std_srvs/srv/Trigger '{}'

ros2 service call /u2d2/torque_enable \
  humanoid_behavior_interfaces/srv/TorqueEnable \
  "{enable: false}"
```

정책이 `FAULT`가 되어도 토크가 자동으로 꺼진다고 가정하지 않는다. 물리 STOP을 누르거나
위 토크 OFF 서비스를 호출하고, 원인을 해결한 뒤 `robot_init`부터 다시 시작한다.

## 27. 새 RECOVERY 모델만 교체하기

이 절차는 WALK 모델은 그대로 두고 새 `fall_after_walk` 체크포인트만 로봇에 적용할 때
사용한다. 현재 선택한 체크포인트는 다음과 같다.

```text
/home/bami122/isaac_ws/robotmodel/XM540_robot/logs/rsl_rl/xm540_fall_after_walk/2026-09-23_15-25-48_0923_retraining_10000/model_9999.pt
```

### 27.1 학습 서버에서 경로 설정 및 확인

새 터미널에서는 셸 변수가 유지되지 않는다. 아래 설정 블록을 먼저 전부 실행한다. 변수가
비어 있으면 release 경로가 `/RL-Model-save`가 되거나 Isaac Lab 실행 경로가
`/isaaclab.sh`가 되어 실패한다.

```bash
cd /home/bami122/isaac_ws
conda activate env_isaaclab

export WORKSPACE=/home/bami122/isaac_ws
export PROJECT=/home/bami122/isaac_ws/robotmodel/XM540_robot
export ISAACLAB_PATH=/home/bami122/IsaacLab
export UNITREE_RL_LAB_DIR=/home/bami122/isaac_ws/unitree_rl_lab
export XM540_ASSET_DIR="$PROJECT/assets/robots/xm540"
export PYTHONPATH="$PROJECT/source/xm540_rl_lab:$UNITREE_RL_LAB_DIR/source/unitree_rl_lab:${PYTHONPATH:-}"
export PLAY="$ISAACLAB_PATH/scripts/reinforcement_learning/rsl_rl/play.py"

export RECOVERY_CKPT="$PROJECT/logs/rsl_rl/xm540_fall_after_walk/2026-09-23_15-25-48_0923_retraining_10000/model_9999.pt"
export RELEASE="$WORKSPACE/RL-Model-save/releases/0923_retraining_10000"
```

다섯 항목을 확인한다.

```bash
test -d "$WORKSPACE" && echo "WORKSPACE OK"
test -d "$PROJECT" && echo "PROJECT OK"
test -x "$ISAACLAB_PATH/isaaclab.sh" && echo "ISAACLAB OK"
test -f "$RECOVERY_CKPT" && echo "CHECKPOINT OK"
test -f "$PROJECT/scripts/export_sim2real_contract.py" && echo "EXPORTER OK"
```

`ISAACLAB OK`만 나오지 않으면 실제 설치 위치를 찾고 `ISAACLAB_PATH`를 그 상위 폴더로
다시 지정한다.

```bash
find /home/bami122 -maxdepth 4 -type f -name isaaclab.sh 2>/dev/null
```

### 27.2 시뮬레이션에서 새 RECOVERY 정책 확인

```bash
"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/launch_external.py" "$PLAY" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --checkpoint "$RECOVERY_CKPT" \
  --num_envs 1 \
  --device cuda:0 \
  --real-time
```

여러 초기 기울기에서 버티고 기본 자세로 돌아오는지 확인한 뒤 종료한다.

### 27.3 학습 서버에서 PT와 계약 JSON 준비

```bash
mkdir -p "$RELEASE"
cp -- "$RECOVERY_CKPT" "$RELEASE/RL_fall_after_walk.pt"

cd "$WORKSPACE"

"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/export_sim2real_contract.py" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --checkpoint "$RELEASE/RL_fall_after_walk.pt" \
  --output "$RELEASE/RL_fall_after_walk.json" \
  --headless
```

두 파일과 체크포인트 해시를 확인한다.

```bash
ls -lh \
  "$RELEASE/RL_fall_after_walk.pt" \
  "$RELEASE/RL_fall_after_walk.json"

sha256sum "$RELEASE/RL_fall_after_walk.pt"
```

Exporter가 `Exported .../RL_fall_after_walk.json`과 observation parity 오차를 출력해야 한다.
JSON을 수동으로 만들거나 이전 체크포인트의 JSON을 재사용하지 않는다.

### 27.4 Windows로 새 RECOVERY pair 가져오기

Windows PowerShell에서 실행한다.

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws

$server = 'bami122@163.180.145.122'
$serverRelease = '/home/bami122/isaac_ws/RL-Model-save/releases/0923_retraining_10000'
$localRelease = '.\RL-Model-save\releases\0923_retraining_10000'

New-Item -ItemType Directory -Force $localRelease | Out-Null

scp "${server}:${serverRelease}/RL_fall_after_walk.pt" $localRelease
scp "${server}:${serverRelease}/RL_fall_after_walk.json" $localRelease

Get-ChildItem $localRelease
Get-FileHash -Algorithm SHA256 "$localRelease\RL_fall_after_walk.pt"
```

### 27.5 Windows에서 로봇으로 전송

로봇의 정책과 브리지가 종료되고 물리 정지 상태인 것을 먼저 확인한다. 기존 RECOVERY
파일은 archive에 복사한 뒤 새 `.pt`와 같은 체크포인트에서 생성한 `.json`을 함께 보낸다.

```powershell
$robot = 'robo04@192.168.1.161'
$robotWs = '/home/robo04/sim2real_ws'

ssh $robot "mkdir -p $robotWs/models/archive/0923_retraining_10000"
ssh $robot "cp -a $robotWs/models/RL_fall_after_walk.pt $robotWs/models/RL_fall_after_walk.json $robotWs/models/tensorrt/RL_fall_after_walk.engine $robotWs/models/tensorrt/RL_fall_after_walk.json $robotWs/models/archive/0923_retraining_10000/ 2>/dev/null || true"

scp `
  "$localRelease\RL_fall_after_walk.pt" `
  "$localRelease\RL_fall_after_walk.json" `
  "${robot}:${robotWs}/models/"
```

### 27.6 Jetson에서 FP32 TensorRT 엔진 재생성

MobaXterm으로 로봇에 접속한 뒤 실행한다. 기존 `RL_walk.pt`와 `RL_walk.json`은 그대로
유지되어 있어야 한다.

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

ls -lh \
  models/RL_walk.pt \
  models/RL_walk.json \
  models/RL_fall_after_walk.pt \
  models/RL_fall_after_walk.json

python3 -m humanoid_policy_runner.xm540_build_tensorrt \
  --models /home/robo04/sim2real_ws/models \
  --precision fp32
```

빌더는 WALK와 RECOVERY 엔진을 모두 다시 검증하지만 기존 WALK 학습 파일은 변경하지
않는다. 성공한 후보 엔진만 `models/tensorrt`에 반영된다.

### 27.7 최종 검증

```bash
cd /home/robo04/sim2real_ws

ls -lh models/tensorrt/

grep -H \
  '"engine_verified"\|"deployment_contract_available"\|"observation_size"' \
  models/tensorrt/RL_fall_after_walk.build.json

test -f models/tensorrt/RL_fall_after_walk.engine && \
test -f models/tensorrt/RL_fall_after_walk.json && \
echo "새 RECOVERY 엔진 준비 완료"
```

RECOVERY 결과에 다음 값이 모두 있어야 한다.

```json
"engine_verified": true
"deployment_contract_available": true
"observation_size": 345
```

여기까지 완료한 뒤 26장의 정책 실행 절차로 이동한다. 브리지와 토크를 먼저 켜고 로봇을
안전한 위치에 세운 다음 센서 주기, 중복 노드, 토크와 초기 기울기를 확인하고 정책을
시작한다.

## 28. 모터 action 순서 검증과 22 ms 지연 학습

### 28.1 순서가 전달되는 방식

Isaac Sim의 articulation 순서는 모터 ID 순서와 다르다. 이것만으로 오류는 아니다.
Exporter가 simulator action index에 해당하는 관절 이름을 계약 JSON에 저장하고, 실물
러너는 그 이름으로 `/joint_states`를 재정렬한다. 출력도 같은 이름을 붙여
`/joint_goals`로 발행하며 serial bridge는 `servo_map.yaml`의 이름→ID 사전으로 변환한다.
따라서 전송 경로는 배열 위치가 아니라 관절 이름으로 연결된다.

현재 WALK와 RECOVERY 계약의 순서는 서로 같고 다음처럼 모터 ID로 연결된다.

| action | 관절 | 모터 ID |
|---:|---|---:|
| 0 | `l_pelvis_pitch_joint` | 11 |
| 1 | `l_shoulder_pitch_joint` | 13 |
| 2 | `neck_yaw_joint` | 19 |
| 3 | `r_pelvis_pitch_joint` | 12 |
| 4 | `r_shoulder_pitch_joint` | 14 |
| 5 | `l_pelvis_roll_joint` | 9 |
| 6 | `l_shoulder_roll_joint` | 15 |
| 7 | `neck_pitch_joint` | 20 |
| 8 | `r_pelvis_roll_joint` | 10 |
| 9 | `r_shoulder_roll_joint` | 16 |
| 10 | `l_pelvis_yaw_joint` | 7 |
| 11 | `l_elbow_pitch_joint` | 17 |
| 12 | `r_pelvis_yaw_joint` | 8 |
| 13 | `r_elbow_pitch_joint` | 18 |
| 14 | `l_knee_pitch_joint` | 5 |
| 15 | `r_knee_pitch_joint` | 6 |
| 16 | `l_ankle_pitch_joint` | 3 |
| 17 | `r_ankle_pitch_joint` | 4 |
| 18 | `l_ankle_roll_joint` | 1 |
| 19 | `r_ankle_roll_joint` | 2 |

학습 서버에서 Isaac Sim이 실제로 해석한 순서를 먼저 확인한다. 이 검사는 소스 파일의
작성 순서를 보는 것이 아니라 환경을 생성한 뒤 resolved 값을 읽는다.

```bash
cd /home/bami122/isaac_ws
conda activate env_isaaclab

export WORKSPACE=/home/bami122/isaac_ws
export PROJECT="$WORKSPACE/robotmodel/XM540_robot"
export ISAACLAB_PATH="${ISAACLAB_PATH:-$HOME/IsaacLab}"
export UNITREE_RL_LAB_DIR="$WORKSPACE/unitree_rl_lab"
export XM540_ASSET_DIR="$PROJECT/assets/robots/xm540"
export PYTHONPATH="$PROJECT/source/xm540_rl_lab:$UNITREE_RL_LAB_DIR/source/unitree_rl_lab:${PYTHONPATH:-}"

"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/debug_sim_joint_mapping.py" \
  --task Unitree-XM540-Velocity-Flat-v0 \
  --headless

"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/debug_sim_joint_mapping.py" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --headless
```

각 실행은 다음 다섯 경계를 검사한다.

1. USD articulation의 `robot.joint_names`
2. `JointPositionAction`이 해석한 action index와 joint ID
3. `joint_pos_rel` 관측의 관절 순서
4. `joint_vel_rel` 관측의 관절 순서
5. 각 관절이 속한 actuator 그룹과 지연 범위
6. action index를 하나씩 1로 만든 one-hot 입력이 정확히 하나의 관절 목표만 바꾸는지

모두 일치하면 마지막에 다음 문장이 나온다.

```text
ONE-HOT OK: every policy action changes exactly one processed joint target
ISAAC MAPPING OK: articulation, action, joint observations and actuator groups agree
```

이미 생성한 계약 JSON과도 비교하려면 `--contract`를 추가한다.

```bash
"$ISAACLAB_PATH/isaaclab.sh" -p \
  "$PROJECT/scripts/debug_sim_joint_mapping.py" \
  --task Unitree-XM540-Fall-After-Walk-v0 \
  --contract /절대/경로/RL_fall_after_walk.json \
  --headless
```

이 경우 `ISAAC MAPPING OK`와 `CONTRACT OK`가 모두 나와야 한다. 여기서 실패하면 새
학습을 시작하지 말고 USD 관절 순서, action selector 또는 observation selector를 먼저
수정한다.

로봇 코드를 갱신하고 `humanoid_policy_runner`를 빌드한 뒤 다음 검사를 실행한다.

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash
source /home/robo04/sim2real_ws/install/setup.bash

ros2 run humanoid_policy_runner xm540_verify_mapping
```

검사는 다음 조건이 모두 맞아야 `MAPPING OK`를 출력한다.

- WALK와 RECOVERY 계약의 action 순서가 완전히 동일함
- 계약의 20개 관절 이름과 `servo_map.yaml`의 이름 집합이 동일함
- 각 이름이 중복 없이 모터 ID 1~20에 연결됨
- 명령 및 피드백 방향값이 모든 관절에 있고 `+1` 또는 `-1`임

이 검사는 설정 파일의 연결을 검증한다. 실제 조립에서 모터 ID가 다른 관절에 지정됐거나
회전 방향·영점이 잘못된 경우까지 확인하지는 못한다. 설정 검사가 통과하는데 한 관절만
반대로 움직이면 action 순서보다 해당 모터의 실제 ID, `direction_control`,
`direction_display`와 영점을 관절별 저속 시험으로 확인한다.

### 28.2 약 22 ms action 지연 반영

실물에서 측정한 command-to-motor 지연은 약 22 ms이다. 학습 물리 간격은 5 ms이므로
정확히 22 ms를 정수 physics step으로 표현할 수 없다. 모든 XM540 actuator에
`DelayedPDActuatorCfg`를 사용하고, 환경이 reset될 때 지연을 4~5 physics step 중에서
선택하도록 설정했다.

```text
physics dt: 5 ms
minimum delay: 4 step = 20 ms
maximum delay: 5 step = 25 ms
measured delay: 약 22 ms, 학습 범위 안에 포함
```

이 지연은 WALK와 FALL_AFTER_WALK가 공유하는 로봇 asset에 들어가므로 두 학습 환경에
모두 적용된다. 새 계약 JSON에는 다음 항목이 기록된다.

```json
"physics_dt": 0.005,
"action_delay_steps": [4, 5],
"action_delay_seconds": [0.02, 0.025]
```

기존 체크포인트는 이 지연이 없는 동역학으로 학습된 모델이다. 지연 효과를 반영하려면
WALK와 FALL_AFTER_WALK를 새 설정으로 다시 학습하고, 새 체크포인트에서 계약 JSON과
TensorRT 엔진을 다시 생성해야 한다.
