# 영속도에서 다리 지지가 무너지는 문제 확인

2026-10-07 실물 기록 `walk_20261007_161217`에서는 속도 명령이 모두 0이어도
정책 시작 뒤 무릎이 비대칭으로 펴지고 기울기가 증가했다. 여기서는 다리 제어를
대조하며 목·팔의 기본 자세나 게인을 변경하지 않는다.

확인한 실물 조건:

- 정책 목표 출력은 약 50Hz이고 WALK 목표 변화 제한은 `0.04 rad/step`이다.
  이는 목표 변화 속도를 최대 2rad/s로 제한한다. 실제 모터 속도를 측정한 값은 아니다.
- 기존 WALK 학습 YAML의 모터 속도 제한은 4.5rad/s이다. 실물 목표 변화 제한과
  학습 모터 속도 제한은 서로 다른 종류의 제한이며 같은 설정으로 취급하지 않는다.
- WALK 중 왼쪽 무릎 목표는 step 제한에 9회, 왼쪽 발목 pitch는 10회,
  왼쪽 발목 roll은 12회 걸렸다. 넘어지기 전에도 다리 목표·실측 차이는 약 0.19rad였다.
- 실물 RECOVERY 전환은 약 2.08초, 기울기 제한에 의한 목표 출력 정지는 약 2.52초였다.
  기울기 정지 조건은 넘어짐의 근본 원인을 설명하지 않는다.
- 코드의 이름 기반 입력·출력 매핑은 일치한다. 실제 모터의 물리적 좌우 위치,
  축 방향, 영점이 올바른지는 별도의 관절별 확인이 필요하다.

## 같은 WALK 모델을 다섯 조건으로 재생

`diagnose_saved_walk.py`의 기존 매핑 검사를 유지하고, 12개 다리 관절 목표에만
실물 목표 처리와 물리 step 단위 지연을 선택적으로 적용한다. Actor의 원래 출력은
관측의 `last_action`에 유지한다. 원본 implicit actuator를 보존하므로 지연 비교를
위해 다른 종류의 PD actuator로 바꾸지 않는다.

이 분리는 Isaac Lab의 원래 action 처리와 물리 step 적용 경로에 맞춘다.
참고: [JointPositionAction 구현](https://github.com/isaac-sim/IsaacLab/blob/v2.2.0/source/isaaclab/isaaclab/envs/mdp/actions/joint_actions.py).

| 조건 | 2초 시작 blend + 0.04rad 목표 제한 | 추가 액션 지연 |
|---|---|---|
| baseline | 없음 | 없음 |
| robot_limits | 적용 | 없음 |
| delay20 | 없음 | 20ms |
| robot_limits_delay20 | 적용 | 20ms |
| robot_limits_delay25 | 적용 | 25ms |

물리 dt가 5ms이므로 22ms를 정확히 표현하는 대신 20ms와 25ms를 각각 시험한다.
`--action-delay-ms 22`를 직접 주면 실제 적용 지연은 25ms로 올림되며 보고서에
요청값과 실제값을 모두 기록한다. 지연은 정책 step(20ms)이 아닌 물리 step(5ms)으로 센다.

## Windows에서 학습 서버로 진단 코드 전송

PowerShell:

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws

scp `
  .\robotmodel\XM540_robot\scripts\diagnose_saved_walk.py `
  .\robotmodel\XM540_robot\scripts\walk_control_comparison.py `
  .\robotmodel\XM540_robot\scripts\saved_walk_support.py `
  .\robotmodel\XM540_robot\scripts\compare_saved_walk_controls.sh `
  bami122@163.180.145.122:/home/bami122/isaac_ws/robotmodel/XM540_robot/scripts/
```

## 학습 서버에서 실행

```bash
cd /home/bami122/isaac_ws
conda activate env_isaaclab

export ISAACLAB_PATH=/home/bami122/IsaacLab
export COMPARE_DEVICE=cpu
export COMPARE_SECONDS=10

bash /home/bami122/isaac_ws/robotmodel/XM540_robot/scripts/compare_saved_walk_controls.sh
```

기본 입력은 확인한 9월 2일 WALK 체크포인트, 같은 실행의 `params/env.yaml`,
기존 `RL_walk_diagnostic.json`이다. 입력이 없으면 실행 전에 절대경로를 출력하고
종료한다. 다른 계약을 사용할 경우 다음처럼 세 경로를 직접 지정한다.

```bash
cd /home/bami122/isaac_ws
conda activate env_isaaclab
export ISAACLAB_PATH=/home/bami122/IsaacLab

bash robotmodel/XM540_robot/scripts/compare_saved_walk_controls.sh \
  /절대경로/model_9999.pt \
  /절대경로/RL_walk.json \
  /같은학습실행/params/env.yaml
```

결과는 `/home/bami122/isaac_ws/walk_control_reports/날짜_시간/`에 조건별 JSON,
실행 로그, 초기화 추적 로그로 저장한다. 마지막에 최대 기울기, 종료 여부,
목표 제한 횟수를 비교하는 표가 출력된다. 종료 시 자동 reset으로 넘어짐 각도가
사라지지 않도록 reset 직전의 몸체·무릎 상태를 기록한다.

전체 실행 로그는 파일에 저장하고, 터미널에는 조건별 진행 상황과 마지막 표만
출력한다. 조건 하나가 실패하면 해당 로그의 마지막 40줄을 출력하고 종료한다.
이미 실행한 결과가 터미널에서 잘린 경우에는 재실행하지 않고 아래 명령으로
최신 결과 폴더의 요약을 확인한다. 아직 실행 중이면 완료된 조건만 표시된다.

```bash
cd /home/bami122/isaac_ws
python3 - <<'PY'
from pathlib import Path
import json
runs = sorted(p for p in Path('walk_control_reports').glob('*') if p.is_dir())
if not runs:
    raise SystemExit('저장된 비교 결과 폴더가 없습니다.')
latest = runs[-1]
print('결과 폴더:', latest)
for p in sorted(latest.glob('*.json')):
    d = json.loads(p.read_text())
    print(p.stem, '기울기:', round(d['max_tilt_deg'], 2),
          '종료:', d['terminated'], '진행:', round(d['duration_seconds'], 2), '초')
PY
```

## 결과에 따른 수정

- baseline부터 무너지면 기존 WALK 모델의 정지 균형과 원래 시뮬레이션 상태부터
  확인한다. 이미 추가된 정지 균형 보상으로 WALK도 재학습해야 한다.
- baseline은 버티고 robot_limits에서 무너지면 목표 blend·step 제한과 학습 사이의
  불일치를 먼저 수정한다. 더 큰 step 제한도 시뮬레이션에서 비교한 뒤 실물에 적용한다.
- 지연을 추가한 조건에서만 무너지면 액션 지연을 포함한 환경으로 WALK를 재학습한다.
- 다섯 조건이 모두 버티면 실물 관절별 축 방향·영점과 부하 상태의 목표 추종을
  점검한다. PD 게인이나 모터 번호를 추측해서 일괄 변경하지 않는다.

## 2026-10-07 비교 결과와 다음 점검

사용자가 학습 서버에서 실행한 비교 결과:

| 조건 | 최대 기울기 | terminated |
|---|---:|---|
| baseline | 3.92° | false |
| delay20 | 4.16° | false |
| robot_limits | 3.34° | false |
| robot_limits_delay20 | 3.46° | false |
| robot_limits_delay25 | 3.52° | false |

이번 시뮬레이션 시험에서는 목표 blend·step 제한과 20~25ms 액션 지연을 추가해도
실물의 넘어짐이 재현되지 않았다. 이 결과만으로 실제 전체 지연의 영향이나
실물 WALK 정책의 안정성을 확정하지 않는다. 실행 시간은 각 JSON의
`duration_seconds`로 확인한다.

정책과 하드웨어 behavior가 정지한 상태에서 `/u2d2/get_joint_limits`로 모터
20개의 EEPROM 위치 제한도 읽었다. 다리의 모터 설정 범위가 WALK 계약의
관절 범위를 좁게 막는 경우는 없었다. pelvis pitch와 ankle pitch의 일부 범위는
모터 설정이 더 넓다. 이 조회는 물리적인 축 방향·영점·장착 위치를 검증하지 않는다.

다음 시험은 아래 순서로 진행한다.

1. 사용자가 브리지·토크와 기본 자세를 준비하고 로봇을 세운 뒤 준비 상태를 알린다.
   당시 원격 조회에서는 토크 ON, 정책 IDLE, IMU 기울기 약 108°였으므로
   그 자세에서 정책이나 관절 이동 시험을 시작하지 않는다.
2. 정책 출력을 멈춘 상태에서 다리 관절을 하나씩 작은 각도로 움직여 실제 움직인
   관절의 좌우·축과 시뮬레이션의 양의 회전 방향을 비교한다. 이름→ID 매핑과
   피드백 값이 일치하더라도 실제 기구가 맞는지는 눈으로 확인해야 한다.
3. 기본 자세의 실제 무릎·발목·골반 각도와 시뮬레이션 자세를 비교해 영점을 확인한다.
4. 매핑·방향·영점이 맞으면 다리 목표와 실제 각도, 전류를 함께 기록해 부하 상태의
   추종 차이를 확인한다. 차이가 확인된 부분을 시뮬레이션에 반영한 뒤 WALK를
   재학습한다.

현재 학습 코드에는 이미 4~5 물리 step(20~25ms) 액션 지연과 정지 균형 보상이 있다.
그러나 실물 WALK는 9월 2일 체크포인트이므로 새 코드의 변경이 그 가중치에
소급 적용되지 않는다. RECOVERY만 재학습해서 교체하는 것으로 WALK의 다리 지지
문제가 해결되었다고 판단하지 않는다.

이 비교는 실제 모터의 PD 응답, 접촉, 질량, 센서 지연 전체를 재현하는 것은 아니다.
최대 10초 동안 버티는 결과도 실물 보행 성공이나 외란 복구 성공을 보장하지 않는다.
