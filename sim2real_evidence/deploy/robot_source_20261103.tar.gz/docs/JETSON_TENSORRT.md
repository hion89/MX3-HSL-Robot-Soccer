# 로봇에서 XM540 체크포인트를 TensorRT 10 엔진으로 직접 변환

확인된 로봇 환경: Jetson Linux R36.4.0, Python 3.10.12,
NVIDIA PyTorch 2.5.0a0 계열, TensorRT 10.3.0.
로봇 워크스페이스: `/home/robo04/sim2real_ws`.

두 체크포인트는 512→256→128→20 Linear/ELU Actor로 확인됐다.
이 구조에 한해 TensorRT MatrixMultiply + bias + ELU 네트워크를 직접 만든다.
**ONNX/ONNX Runtime/PyCUDA 설치가 필요하지 않다.** 일반적인 임의의 .pt 변환기는 아니다.
구조나 정규화 방식이 바뀐 체크포인트는 거부한다.
TensorRT 10의 이름 기반 텐서 주소와 execute_async_v3 API를 사용한다.
참고: [NVIDIA TensorRT 10.3 Python 예제](https://github.com/NVIDIA/TensorRT/tree/release/10.3/samples/python).

## 1. Windows에서 로봇 실행 파일 갱신

Windows PowerShell:

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws
$policyFiles = @(
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_policy.py',
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_dual_policy_node.py',
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_tensorrt.py',
  '.\sim2real_ws\src\humanoid_policy_runner\humanoid_policy_runner\xm540_build_tensorrt.py'
)
scp $policyFiles robo04@192.168.1.161:/home/robo04/sim2real_ws/src/humanoid_policy_runner/humanoid_policy_runner/
```

로봇 MobaXterm 터미널:

```bash
cd /home/robo04/sim2real_ws
source /opt/ros/humble/setup.bash
colcon build --symlink-install --packages-up-to humanoid_policy_runner
source install/setup.bash
python3 -c 'import torch, tensorrt; print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0)); print(tensorrt.__version__)'
```

CUDA 확인이 실패하면 기존 NVIDIA PyTorch 설치를 점검한다. 일반 pip torch/tensorrt로
기존 NVIDIA 패키지를 교체하지 않는다. ONNX 미설치는 이 경로와 무관하다.

## 2. 로봇에서 한 명령으로 두 모델 변환

정책 실행기를 정지한 상태에서 다음을 실행한다. 이 명령은 모터를 제어하지 않는다.

```bash
python3 -m humanoid_policy_runner.xm540_build_tensorrt \
  --models /home/robo04/sim2real_ws/models \
  --precision fp32
```

입력: `models/RL_walk.pt`, `models/RL_fall_after_walk.pt`.
출력은 별도 `models/tensorrt/`에 저장하며 원본 .pt와 기존 ONNX는 유지한다.

```text
models/tensorrt/
├── RL_walk.engine
├── RL_walk.build.json
├── RL_walk.json                  # 학습 계약이 있을 때 생성되는 실행 계약
├── RL_fall_after_walk.engine
├── RL_fall_after_walk.build.json
└── RL_fall_after_walk.json       # 학습 계약이 있을 때 생성되는 실행 계약
```

검증할 내용:

- 각 모델 97개 입력에서 원본 PyTorch Actor와 엔진 출력 비교.
- FP32는 TF32를 비활성화하고 atol=rtol=1e-4로 비교.
- 20회 워밍업 후 200회 CPU→GPU→CPU 왕복 추론의 p50/p99/max 지연 기록.
- 출력 비교를 통과한 엔진만 최종 경로에 반영. 실패하면 기존 파일 유지.
- 20ms 초과 시 경고. 이 단독 측정은 ROS 센서 처리까지 포함한 50Hz 보장이 아니다.

추가 최적화가 필요할 때 `--precision fp16`으로 다시 빌드할 수 있다.
FP16 비교 허용치는 atol=5e-3, rtol=2e-3이다. 이 수치 통과만으로 동작 안정성을
보장하지 않는다. FP32로 먼저 실행을 확인하고 FP16은 별도 시뮬레이션·지지 시험으로 검증한다.
같은 출력 이름을 사용하므로 FP16 재빌드 후에는 생성된 JSON도 함께 사용한다.

## 3. 규격 JSON은 별도 학습 정보

엔진 생성은 로봇에서 가능하지만 관절 순서·기본 자세·관측 이력은 가중치에 없다.
학습 서버에서 기존 `export_sim2real_contract.py`를 `--onnx-output` 없이 실행해
JSON만 생성할 수 있다. 이 경우 서버에도 ONNX 도구가 필요하지 않다.
입력 체크포인트는 로봇의 .pt와 동일해야 한다.

학습 JSON을 아래 경로에 넣고 **2번 변환 명령을 다시 실행**한다.

```text
/home/robo04/sim2real_ws/models/RL_walk.json
/home/robo04/sim2real_ws/models/RL_fall_after_walk.json
```

그러면 `models/tensorrt/` 아래에 엔진 해시와 검증 정보를 담은 같은 이름의
`RL_walk.json`, `RL_fall_after_walk.json`이 추가된다.
`.build.json`은 벤치마크 보고서일 뿐, 로봇 제어용 JSON의 대체물이 아니다.
학습 JSON이 없으면 엔진은 생성되어도 실제 정책 실행은 준비 완료가 아니다.

## 4. TensorRT로 추론 확인

하드웨어 센서 실행은 기존 [적용 매뉴얼](XM540_WALK_RECOVERY.md)을 따른다.
아래는 로봇에 새 목표를 보내지 않는 모드다.

```bash
MODEL_DIR=/home/robo04/sim2real_ws/models/tensorrt
ros2 launch humanoid_policy_runner xm540_dual_policy.launch.py \
  inference_backend:=tensorrt \
  walk_checkpoint:="$MODEL_DIR/RL_walk.engine" \
  recovery_checkpoint:="$MODEL_DIR/RL_fall_after_walk.engine" \
  walk_contract:="$MODEL_DIR/RL_walk.json" \
  recovery_contract:="$MODEL_DIR/RL_fall_after_walk.json" \
  publish_joint_goals:=false
```

다른 로봇 터미널에서 ROS 환경을 source한 뒤:

```bash
ros2 service call /xm540_dual_policy/start std_srvs/srv/Trigger '{}'
ros2 topic echo /xm540_dual_policy/state
```

엔진 추론에서는 TensorRT가 신경망을 실행하고, 기존 PyTorch는 CUDA 메모리·스트림을
제공한다. PyTorch Actor 자체는 ROS 실행기에서 로드하지 않는다.
TensorRT 버전 변경 시 로봇에서 엔진을 다시 빌드해야 한다.

2026-09-21 로봇에서 FP32 TensorRT 빌드, 97개 입력 수치 비교와 CUDA 스트림 왕복을
검증했다. WALK와 RECOVERY 모두 `engine_verified=true`였고 단독 추론 중앙값은 약
0.21ms였다. ROS 2 preview에서 직립 시 WALK, 누움 시 RECOVERY와 timeout FAULT를
확인했다. 실제 모터 출력 시험은 [통합 매뉴얼](XM540_END_TO_END_MANUAL.md)의 live 절차를
따른다.
