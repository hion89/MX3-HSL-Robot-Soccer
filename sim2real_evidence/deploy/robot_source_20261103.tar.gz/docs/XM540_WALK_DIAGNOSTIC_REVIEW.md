# WALK 초기화 및 관절 매핑 점검 — 2026-10-06

## 범위와 한계

Windows 워크스페이스의 XM540 자산 설정, task 등록, 학습·재생 진입점,
저장 YAML 복원 스크립트, 배포 JSON, 정책 관측·목표 생성, 브리지의 이름→ID
변환과 servo_map.yaml을 점검했다. 사용자 첨부의 학습 당시 env.yaml과
학습 서버의 Isaac/GDB 로그도 대조했다.

Windows에는 실행 가능한 Isaac 환경이 없다. 서버에 설치된 Isaac Lab/Sim
파일과 현재 실행 상태를 직접 조사하지 않았으므로 초기화 정지의 정확한
함수를 확정하거나 수정 후 서버 실행 성공을 주장할 수 없다.

## 확인된 코드 오류와 수정

0. 서버의 직접 기록에서 `CommandManager.__init__`의
   `self.cfg.debug_vis = False`가 `AttributeError: 'dict' object has no
   attribute 'debug_vis'`를 발생시킨 것이 확인됐다. 진단 코드가
   `cfg.commands`를 dict로 교체한 것이 원인이다. 기존 typed CommandsCfg를
   유지하고 `base_velocity` term만 교체하도록 수정했다. 정책 실행 전의
   환경 초기화 오류이며 학습 모델이나 모터 ID 오류의 증거가 아니다.
   후속 실행에서 ActionManager도 같은 `debug_vis` 속성을 요구해
   `cfg.actions` dict가 실패했다. 관측·이벤트·보상·종료·curriculum을
   포함한 모든 manager container는 typed cfg를 유지하고 term만 교체한다.
   초기화 예외 후 Kit 종료가 원문을 가리지 않도록 실패 시 오류를 기록하고
   해당 진단 프로세스를 즉시 종료하도록 수정했다.
   서버에서는 curriculum이 None으로 비활성화되어 있었다. 빈 term을
   적용하는 경우에는 None을 유지하도록 수정했다.
1. 진단 코드가 `action_term._scale[0]`을 사용했다. Isaac의 숫자 scale은
   scalar로 보존될 수 있어 이 접근은 실패한다. 숫자와 텐서를 모두 관절
   개수에 맞게 broadcast해서 검사하도록 수정했다. 이 검사는 환경 생성
   이후에 수행되므로 지금의 초기화 정지 원인으로 단정하지 않는다.
2. 저장 YAML의 물리 설정 일부만 복원해서 현재 설정이 섞일 수 있었다.
   PhysX, 중력, Fabric, 물리 재질, 장면 플래그, 로봇 강체·articulation 속성을
   복원한다. 설치 버전에 없는 필드는 초기화 전에 명확히 실패시킨다.
3. 일반 숫자를 모두 float로 변환했다. solver 종류와 반복 횟수 등 정수
   필드를 int로 유지한다.
4. 별도 관절 디버그 도구가 모든 actuator에 delay 필드가 있다고 가정했다.
   ImplicitActuator에는 해당 필드가 없을 수 있어 기본 0으로 처리한다.
5. 초기화 추적을 콘솔에만 의존했다. `walk_init_python.log`에 2초 간격의
   Python 호출 위치와 30초 간격의 faulthandler 출력을 직접 기록한다.
   Python profiler에 제어가 돌아오는 경우 초기화 90초 초과 시 진단
   프로세스만 종료 코드 124로 종료한다. 반환하지 않는 native 호출까지
   강제로 중단하는 보편적인 watchdog은 아니다.

## 매핑 대조 결과

학습 서버의 articulation 로그 이름 순서는 배포 RL_walk.json과 일치한다.
actor 출력 차원은 20이며 정책 관측은 71차원×이력 5 = 355차원이다.
물리 dt는 5ms, policy dt는 20ms, 저장 gait period는 0.8초이다.
관측 이름 순서와 dt를 첨부 YAML에 대해 로컬에서 확인했다.

| 정책 인덱스 | 관절 | 로컬 servo_map 모터 ID |
|---:|---|---:|
| 0 | l_pelvis_pitch_joint | 11 |
| 1 | l_shoulder_pitch_joint | 13 |
| 2 | neck_yaw_joint | 19 |
| 3 | r_pelvis_pitch_joint | 12 |
| 4 | r_shoulder_pitch_joint | 14 |
| 5 | l_pelvis_roll_joint | 9 |
| 6 | l_shoulder_roll_joint | 15 |
| 7 | neck_pitch_joint | 20 |
| 8 | r_pelvis_roll_joint | 10 |
| 9 | r_shoulder_roll_joint | 16 |
| 10 | l_pelvis_yaw_joint | 7 |
| 11 | l_elbow_pitch_joint | 17 |
| 12 | r_pelvis_yaw_joint | 8 |
| 13 | r_elbow_pitch_joint | 18 |
| 14 | l_knee_pitch_joint | 5 |
| 15 | r_knee_pitch_joint | 6 |
| 16 | l_ankle_pitch_joint | 3 |
| 17 | r_ankle_pitch_joint | 4 |
| 18 | l_ankle_roll_joint | 1 |
| 19 | r_ankle_roll_joint | 2 |

정책 인덱스와 모터 ID가 다른 것은 정상이다. `on_joints`는 메시지의 name으로
피드백을 정책 순서로 정렬한다. 목표에는 정책 순서의 name을 붙이고,
`cb_goals`는 name/position을 dict로 만들며 `send_goals`는 이름으로 ID를
조회한다. 로컬 이름 20개와 ID 20개 모두 중복이 없다. 실제 조립된 모터의
EEPROM ID, 회전 방향, 영점이 이 파일과 일치하는지는 별도 실물 검증 사항이다.

## 초기화 정지의 확인된 오류와 잔여 검증

후속 `walk_init_python.log`에서 simulation start가 끝난 뒤 CommandManager
초기화의 dict 오류가 확인됐다. 위 0번 수정으로 해당 오류를 제거했다.
서버에서 재실행해 이후 초기화와 정책 rollout이 완료되는지는 확인해야 한다.
아래는 이 traceback이 나오기 전 로그의 한계이며, timeline 반복 후보가
실제 실행됐다고 확인된 것은 아니다.

articulation과 implicit actuator 초기화는 끝났지만 environment constructor가
반환하지 않는다. GPU와 CPU 모두 재현되었다는 사용자 보고가 있다.
GDB 주 스레드에는 Python frame 실행이 잡혔으나 Python 함수 이름이 없다.
이 증거는 GPU 메모리 부족, motor ID 문제, tendon 경고 어느 것도 정지
원인으로 확정하지 못한다.

공식 Isaac Lab SimulationContext에는 timeline이 재생되지 않을 때 render를
반복하는 경로가 있다. headless render는 아무 작업도 하지 않을 수 있다.
이는 Python에서 CPU를 소비하며 출력 없이 반복되는 현상의 후보이나,
서버의 호출 위치가 해당 함수라는 증거는 아직 없다.
참고: https://github.com/isaac-sim/IsaacLab/blob/v2.2.0/source/isaaclab/isaaclab/sim/simulation_context.py

## 검증

설정 타입 보존, 중첩 cfg 복원, 버전 필드 오류, 초기화 예외 기록,
Python loop timeout 기록, typed manager container 유지와 dict 거부에 대한
비활성화된 None 설정 처리까지 포함한 9개 로컬 단위 테스트를 통과했다.
진단 및 매핑 스크립트 구문 검사를 통과했다.
실제 Isaac 관절 action/observation 선택과 one-hot 변환은 서버 실행이
초기화를 통과한 후 자동 검사한다. 현재 USD와 함수 코드가 학습 당시와
동일하다는 증명은 아직 없으며 제어 설정 복원과 구분해야 한다.
