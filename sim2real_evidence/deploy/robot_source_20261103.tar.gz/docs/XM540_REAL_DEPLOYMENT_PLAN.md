# XM540 기존 학습 결과의 실물 적용 계획

기준일: 2026-10-29. 사용자가 2026-10-07 시험이 최신 실패라고 확인했다.

2026-11-03 진행 순서 변경: 사용자가 현재 로컬 로봇 소스로 Jetson의 기존 빌드를
교체하기로 했다. [소스 교체·재빌드 절차](XM540_ROBOT_REBUILD.md)에 따라 소스 전송 →
기존 소스/빌드 백업 → 전체 9개 ROS 패키지 재빌드 → 설치 경로/설정/모델 재검사를 먼저 진행한다.
로봇의 모델·실패 bag·정책 NumPy 환경은 보존한다. 로봇 빌드 결과는 아직 받지 않았으며
WALK 속도 범위 수정 적용 결과도 미확인이다. 이후 관절/IMU와 부하 시험 단계로 돌아간다.

## 작업 우선순위와 완료 조건

최우선 작업은 기존 학습 결과의 실물 적용이다. 외부 보행 엔진 도입이나 상위 인식·전략
기능 확장은 이번 실패의 원인을 분리하는 데 필요한 경우에만 진행한다.

지금은 기존 WALK를 고정하고 영속도에서 다리 지지가 무너지는 원인을 확인한다.
원인 식별 전에는 새 보상·게인·중력 오프셋·목표 제한·모델을 한꺼번에 바꾸지 않는다.
기존 모델이 실측 구동계 조건에서 실패한다면, 그 조건을 반영한 재학습으로 이어간다.
기존 가중치를 무조건 유지하는 것이 성공 조건은 아니다.

단계별 목표는 다음과 같다. 아래 시간·반복 횟수는 이번 작업의 제안 시험 기준이며
기존 모델의 검증된 성능이나 모든 기체에 적용되는 안전 한계가 아니다.

1. 모델·규격·엔진·실행 코드의 동일성을 확인한다.
2. 다리의 실제 장착 위치·축 방향·영점을 확인한다.
3. 지지 상태에서 기본 자세와 작은 목표 변화를 추종한다.
4. 영속도 WALK를 1초 → 3초 → 10초 → 30초로 늘려 시험한다.
5. 보조 지지가 개입하지 않는 정지 시험과 저속 이동·정지를 각각 반복한다.
6. 그 후에 작은 외란에서 WALK/RECOVERY 전환을 검증한다.

모델/설정 고정 상태에서 같은 시험을 최소 3회 반복해 결과와 중단 원인을 기록한다.
하네스가 체중을 받거나 사람이 자세를 보정한 시험은 자유 균형 성공으로 세지 않는다.

## 1. 실패 기록에서 확인된 사실과 남은 가설

| 항목 | 현재 근거 | 판단과 다음 작업 |
|---|---|---|
| 추론 시작 실패 | NumPy 2.2.6과 NVIDIA PyTorch의 변환 호환 오류 | 물리적 넘어짐과 별개. 정책 전용 NumPy 환경을 먼저 재확인 |
| 추론 실행 자체 | 10월 7일 두 엔진 영벡터 추론 통과, 중앙 시간 약 0.3ms 기록 | 현재 엔진·실제 관측·실제 부하에서 다시 확인해야 함 |
| 실물 실패 | 영속도에서도 무릎 비대칭·기울기 증가, 목표/실측 차이 약 0.19rad 기록 | 관절 변환과 부하 추종을 우선 조사. 0.19rad 전체를 백래시로 해석하지 않음 |
| 제한·지연 가설 | baseline 및 목표 제한/20~25ms 추가 지연 조건에서 최대 기울기 3.34~4.16°, 종료 없음 | 시험한 조건만으로 실물 넘어짐을 재현하지 못함. 전체 센서·통신·구동기 지연을 배제하지 않음 |
| 코드 매핑 | 이름 기반 매핑 일치, EEPROM 범위가 다리를 좁게 막지 않았다는 기록 | 실제 조립 위치·방향·영점은 미검증 |
| 학습 조건 변화 | 기존 WALK와 현재 소스의 구동기 방식·정지 보상이 다름 | 현재 코드로 과거 학습을 재현했다고 간주하지 않음 |
| FAULT/전환 | 기울기 증가 뒤 RECOVERY 및 출력 정지 | 이 시점만으로 최초 원인을 설명할 수 없음 |

원문: [다리 제어 비교](XM540_LEG_CONTROL_COMPARISON.md),
[NumPy 호환성 기록](XM540_POLICY_NUMPY.md),
[진단 검토](XM540_WALK_DIAGNOSTIC_REVIEW.md).

계획 초안 작성 시에는 로컬에 원본 실패 rosbag/CSV와 서버의 조건별 결과 JSON이 없었다.
이후 사용자가 실패 bag을 복사하여 원본을 분석했다. 최신 결과는
[원본 분석 보고서](XM540_FAILURE_20261007_ANALYSIS.md)와 아래 진행 기록을 따른다.

## 2. 로컬에서 확인한 기준 모델

| 모델 | SHA-256 | 관측 | 정책 간격 |
|---|---|---:|---:|
| `RL-Model-save/RL_walk.pt` | `9ac0d65d4c27e8d95c05f3e350ec39b0b322c21f345ca30bab26ad1a9dcdd1b8` | 355 | 20ms |
| `RL-Model-save/RL_fall_after_walk.pt` | `fdcb3485d025699dfeef7a80faa88b9f77bb874e12851e6edf46cbb104d9d2a8` | 345 | 20ms |

두 체크포인트와 각 JSON의 해시가 일치한다.
이름에서 모터 ID로 연결하는 기존 매핑 테스트도 2개 통과했다.

위 확인은 Windows의 파일에 한정된다. 로봇에서 현재 로드한 엔진의 원본 체크포인트가
동일한지는 실행 경로와 TensorRT 계약 JSON으로 별도 확인한다. JSON의
`source = resolved current task; use original training source/assets` 문구는
학습 당시 소스·자산의 provenance를 보장하지 않는다.

## 3. 1차 작업: 원본 증거와 배포 상태 고정

다음 파일을 시험별 폴더에 보관한다. 실행 중 파일을 덮어쓰지 않는다.

- 서버: 선택한 원본 `model_N.pt`, 같은 run의 `params/env.yaml`, `params/agent.yaml`,
  학습 코드 커밋 및 미커밋 변경, 실제 USD/참조 자산, Isaac Lab/Sim 버전.
- 서버: 10월 7일 `walk_control_reports/`의 조건별 JSON과 로그.
- 로봇: 실패 `walk_20261007_161217`의 원본 기록, 당시 launch 명령과 parameter dump,
  실제 `.engine`/계약/빌드 보고서, 모터 설정과 IMU 보정값.
- 새 시험: 기체, 바닥, 배터리 전압, 온도, 지지 방법, 모델 해시, 시험 시간 및 중단 원인.

이미 동일 조건의 원본 결과가 있으면 먼저 읽는다. 재현 필요성이 있을 때만 다시 시험한다.
원본 학습 소스·자산을 찾지 못한 경우 그 한계를 남기고 현재 소스에서 뽑은 규격을
과거 학습 규격으로 확정하지 않는다.

### 로봇의 모든 ROS 터미널에서 통일할 환경

다음은 기존 시험 환경의 값이다. 현재 브리지가 다른 domain에서 실행 중이면 먼저 확인해
그 환경과 통일한다. 이 설정은 같은 Jetson 내부 통신을 전제로 한다.

```bash
cd /home/robo04/sim2real_ws
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
source /opt/ros/humble/setup.bash
source install/setup.bash
```

정책/TensorRT 터미널에만 기존 전용 NumPy 경로를 추가한다. 카메라 터미널에는 추가하지 않는다.

```bash
export PYTHONPATH="/home/robo04/sim2real_ws/.policy-python/numpy1:${PYTHONPATH:-}"
python3 - <<'PY'
import numpy as np
import torch
print('NumPy:', np.__version__, np.__file__)
print('PyTorch:', torch.__version__)
assert np.__version__ == '1.26.4'
assert torch.from_numpy(np.zeros(1, dtype=np.float32)).numpy().shape == (1,)
print('Torch/NumPy conversion OK')
PY
```

경로가 없다면 [기존 호환성 절차](XM540_POLICY_NUMPY.md)를 사용한다. 시스템 전체 NumPy나
JetPack을 이번 진단과 동시에 변경하지 않는다.

### 실제 로드 경로와 파일 확인

```bash
ros2 node list
ros2 param dump /xm540_dual_policy
ros2 param dump /body_motor_controller
ros2 param dump /imu_parser
ros2 topic info /joint_goals --verbose
```

노드 이름이 다르면 `ros2 node list`의 실제 이름을 사용한다. 정책 노드가 없으면
launch 명령과 선택한 네 개 경로를 기록한 후 Preview를 준비한다.

`walk_checkpoint/recovery_checkpoint`가 `.engine`이면 `walk_contract/recovery_contract`도
그 엔진 해시가 들어간 배포 계약이어야 한다. `.build.json`은 계약을 대체하지 않는다.

```bash
python3 - <<'PY'
from pathlib import Path
import hashlib, json
root = Path('/home/robo04/sim2real_ws/models')
for stem, size in [('RL_walk', 355), ('RL_fall_after_walk', 345)]:
    pt = root / (stem + '.pt')
    source = json.loads((root / (stem + '.json')).read_text())
    deployed = json.loads((root / 'tensorrt' / (stem + '.json')).read_text())
    report = json.loads((root / 'tensorrt' / (stem + '.build.json')).read_text())
    engine = root / 'tensorrt' / (stem + '.engine')
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    assert sha(pt) == source['checkpoint_sha256'] == deployed['checkpoint_sha256']
    assert sha(engine) == deployed['engine_sha256'] == report['engine_sha256']
    assert report['checkpoint_sha256'] == source['checkpoint_sha256']
    assert report['engine_verified'] and report['deployment_contract_available']
    assert source['observation_size'] == deployed['observation_size'] == size
    assert source['step_dt'] == deployed['step_dt'] == 0.02
    print(stem, 'hash chain OK', sha(pt), sha(engine))
PY
```

이 예제는 기존 표준 파일 배치를 사용한다. 파라미터가 다른 위치를 가리키면 그 실제 파일을
대상으로 검사한다. 해시 검사를 통과해도 학습 당시 source/assets의 일치나 실물 안정성을
증명하는 것은 아니다.

## 4. 2차 작업: 센서·관절 변환 확인

정책 출력을 멈추고 기체를 지지한 상태에서 수행한다. 현재 실물 준비 상태를 확인하기
전에는 원격에서 토크·초기 자세·관절 이동 명령을 실행하지 않는다.

### 센서 읽기

```bash
ros2 topic hz /joint_states
ros2 topic hz /imu/data
ros2 topic echo /joint_states --once
ros2 topic echo /imu/data --once
ros2 topic echo /u2d2/behavior_status --once
```

확인 항목:

- 서로 다른 관절 20개에 position/velocity가 모두 있고 값이 유한한가.
- 수신률뿐 아니라 센서 timestamp의 나이와 IMU/관절 사이 시각 차이를 확인했는가.
- 수평 기준에서 gyro가 0 부근인지, 중력 방향이 `[0,0,-1]` 부근인지 확인했는가.
- 몸체를 앞/뒤/좌/우로 기울일 때 sim과 같은 중력 방향 변화가 나타나는가.
- yaw 방향으로 돌렸을 때 gyro 부호와 rad/s 단위가 맞는가.

정자세 오차는 수평 기준물과 반복 측정으로 판단한다. 기울어진 로봇에서 0이 나오도록
`grav_offset`을 조절하는 방식으로 확인하지 않는다.

### 파일상의 이름/ID 검사

```bash
python3 -m humanoid_policy_runner.xm540_verify_mapping \
  --walk-contract /home/robo04/sim2real_ws/models/tensorrt/RL_walk.json \
  --recovery-contract /home/robo04/sim2real_ws/models/tensorrt/RL_fall_after_walk.json \
  --servo-map /home/robo04/sim2real_ws/src/humanoid_serial_bridge/config/servo_map.yaml
```

이 모듈이 로봇에 아직 배포되지 않았다면 저장소의 같은 이름 스크립트를 명시적 경로로 실행한다.

### 실물 확인표

| 관절 | 실제 ID/위치 | sim의 +방향과 일치 | 기준 자세/영점 | 무부하 추종 | 부하 추종 |
|---|---|---|---|---|---|
| 좌우 pelvis pitch/roll/yaw | 미확인 | 미확인 | 미확인 | 미확인 | 미확인 |
| 좌우 knee pitch | 미확인 | 미확인 | 미확인 | 미확인 | 미확인 |
| 좌우 ankle pitch/roll | 미확인 | 미확인 | 미확인 | 미확인 | 미확인 |

기준 자세 주변에서 다리 한 관절씩 작은 양/음 방향 이동을 비교한다. 예를 들어
0.02~0.05rad(약 1.1~2.9도)의 느린 변화부터 검토하되, 실제 가동 여유·간섭·지지 상태에
맞춰 범위를 정한다. 이 숫자는 모든 관절에서 이동을 허용한다는 의미가 아니다.

판정: 다른 관절이 움직이거나 실제 방향이 반대면 즉시 그 단계에서 멈춘다. 방향/영점이
틀렸다면 해당 기체 변환만 수정하고 같은 시험을 반복한다. 게인 변경으로 보상하지 않는다.

## 5. 3차 작업: 정책 없는 부하 추종 시험

`robot_init`의 다리 기본 자세는 WALK 계약과 같은 값이다. 다만 어깨 pitch는 ±0.2rad,
팔꿈치는 ±3.04rad, 목은 아래를 보는 자세로 초기화되어 계약의 기본 자세와 차이가 있다.
현재 시작 허용 오차 0.35rad와 목 검사 제외는 정확한 전신 자세 일치를 보장하지 않는다.
머리·팔 자세 및 실제 유지 방식을 기록하되, 이번 다리 진단에서 함께 변경하지 않는다.

1. 정책 없는 상태에서 다리 기준 자세를 유지한다.
2. 보조 지지의 하중을 구분하여 무부하와 체중 부하에서 기록한다.
3. 무릎·발목·골반별 작은 느린 목표 변화와 실측 응답을 비교한다.
4. 지연, 목표/실측 RMSE, 정상상태 처짐, 진동, 전류·PWM·전압·온도를 확인한다.

| 관측 결과 | 우선 조사할 항목 |
|---|---|
| 정책 없이도 다리가 처짐 | 토크/PWM/전류 제한, 모터 PID·프로파일의 실제 적용값, 전압, 기구 마찰 |
| 무부하는 맞고 하중에서만 처짐 | 유효 강성·토크 여유·열/전원 조건 |
| 방향 전환에서만 큰 오차 | 유격·정지 마찰·기구 간섭 |
| 일정 시간 차이 후 잘 추종 | 명령/센서 지연과 프로파일. 오차 전체를 영점으로 보정하지 않음 |
| 체중 부하에서 비대칭 | 좌우 영점·기구·구동기 응답·하중 배분 |

게인·모터 프로파일은 YAML뿐 아니라 실제 장치에서 읽은 값도 확인한다. 직접 시리얼을
여는 `khuber_dxl_dump`류 도구는 U2D2 브리지와 같은 포트를 동시에 사용하지 않는다.
정지·지지 상태에서 버스 소유자를 하나로 유지한 별도 점검으로 수행한다.

기본 진단 전류는 2Hz이므로 빠른 순간 토크 포화를 확정하는 용도로 부족할 수 있다.
장치 내부 목표 프로파일은 현재 `/joint_goals`에 포함되지 않는다. 필요한 경우 추가
계측하되 기존 데이터만으로 명령 지연과 모터 동특성을 완전히 분리했다고 주장하지 않는다.

## 6. 4차 작업: Preview와 실제 관측의 수치 검증

실행 명령/환경은 [통합 매뉴얼](XM540_END_TO_END_MANUAL.md)의 Preview 절차를 사용한다.
단, 오래된 예제는 전환각 30/12/75도를 사용하고 현재 launch 기본값은 20/10/55도이다.
이번 비교에서는 아래 값을 명시하여 섞이지 않게 하고 실제 parameter dump를 보관한다.

```text
enter_tilt_deg=20.0
exit_tilt_deg=10.0
stop_tilt_deg=55.0
settle_seconds=0.5
max_recovery_seconds=8.0
startup_blend_seconds=2.0
max_goal_step_rad=0.04
recovery_max_goal_step_rad=0.08
```

위 값은 현재 설정을 고정하기 위한 값이며 이번에 새로 안전성을 검증한 임계값이 아니다.
실패를 재현하려고 정지 각도를 높이지 않는다.

```bash
MODEL_DIR=/home/robo04/sim2real_ws/models/tensorrt
ros2 launch humanoid_policy_runner xm540_dual_policy.launch.py \
  inference_backend:=tensorrt \
  walk_checkpoint:="$MODEL_DIR/RL_walk.engine" \
  recovery_checkpoint:="$MODEL_DIR/RL_fall_after_walk.engine" \
  walk_contract:="$MODEL_DIR/RL_walk.json" \
  recovery_contract:="$MODEL_DIR/RL_fall_after_walk.json" \
  enter_tilt_deg:=20.0 exit_tilt_deg:=10.0 stop_tilt_deg:=55.0 \
  settle_seconds:=0.5 max_recovery_seconds:=8.0 \
  startup_blend_seconds:=2.0 max_goal_step_rad:=0.04 \
  recovery_max_goal_step_rad:=0.08 publish_joint_goals:=false
```

다른 터미널에서도 같은 ROS 환경을 설정하고 다음을 실행한다.

```bash
ros2 service call /xm540_dual_policy/start std_srvs/srv/Trigger '{}'
ros2 topic echo /xm540_dual_policy/state
ros2 topic hz /xm540_dual_policy/preview_joint_goals
```

Preview는 모터 목표를 발행하지 않는다. 다른 노드의 `/joint_goals` 발행 여부는 별도 확인한다.

판정:

- WALK/RECOVERY 관측 크기 355/345, 출력 20개, 50Hz, 유한값.
- 센서 누락, NaN, timeout, 추론/제어 주기 초과가 없음.
- 같은 센서 기록으로 만든 관측을 원본 Actor와 TensorRT에 주고 action을 비교한다.
  현재 FP32 빌더 기준은 `atol=rtol=1e-4`다. 무작위 97개 입력의 빌드 검증만으로 실제
  관측 분포 전체에서의 일치를 증명했다고 취급하지 않는다.
- 학습 관측과의 대조에는 joint order, term-major 5개 이력, scale, 위상 시작점,
  last_action, reset 규칙이 포함된다. 20ms, 0.8초 주기, `q_target=q_default+0.2*action`.
- 모터가 움직이지 않는 Preview의 목표 변화는 폐루프 안정성 시험이 아니다.

실제 관측 export/재추론은 현재 dual runner에 저장 기능이 없어 아직 구현되지 않았다.
필요한 추가는 진단용 관측·raw action·제한 전 목표 기록으로 한정하고 제어 수식은 바꾸지 않는다.

## 7. 5차 작업: 짧은 영속도 Live 시험

센서·변환·부하 추종·Preview가 통과한 뒤 수행한다. 하드웨어 준비와 토크/초기자세는
[통합 매뉴얼](XM540_END_TO_END_MANUAL.md)의 지지 상태 절차를 사용한다.
`robot_init started`는 완료가 아니다. behavior가 idle인지와 실제 자세 도달을 확인한다.

Live에서는 기존 보행/기상/킥/목/fall manager 등 경쟁 제어기를 함께 실행하지 않는다.
하드웨어 launch의 `use_neck_control:=false`와 `/joint_goals` 단독 발행을 확인한다.

Preview를 종료하고 위 launch의 `publish_joint_goals:=true`만 바꿔 재실행한다.
시작 전에 rosbag을 기록하고 영속도 명령을 명시적으로 발행한다.

```bash
ros2 bag record -o walk_zero_YYYYMMDD_HHMMSS \
  /joint_states /imu/data /cmd_vel /joint_goals /motor_diagnostics \
  /xm540_dual_policy/preview_joint_goals /xm540_dual_policy/state \
  /u2d2/behavior_status /u2d2/torque_enabled /buttons/stop_pressed
```

```bash
ros2 topic pub --rate 10 /cmd_vel geometry_msgs/msg/Twist \
  '{linear: {x: 0.0, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}'
```

기체가 준비된 뒤 명시적으로 `/xm540_dual_policy/start`를 호출한다.
첫 시험은 1초, 다음은 3초/10초/30초로 늘린다. 각 시험은 초기화 조건을 되돌리고 기록한다.
무릎 지지 붕괴, 기울기 지속 증가, 큰 비대칭 추종이 보이면 55도 FAULT까지 기다리지 않는다.
RECOVERY에 들어간 시험은 정지 WALK 통과로 세지 않는다.

정책 정지:

```bash
ros2 service call /xm540_dual_policy/stop std_srvs/srv/Trigger '{}'
```

`/stop`·FAULT·Ctrl+C는 토크 해제를 보장하지 않는다. 기존 브리지가 마지막 목표를
유지할 수 있으므로 기체를 지지한 뒤 토크 해제 절차를 별도로 수행한다.
물리 STOP의 실제 동작도 지지 상태에서 사전에 확인한다.

관절 오차의 단일 보편 통과값은 아직 없다. 기구 정합 검사와 부하 시험에서 확인한 범위,
같은 입력의 sim 응답을 기준으로 정한다. 기존 0.35rad 시작 허용값을 추종 합격값으로 쓰지 않는다.

## 8. 결과별 수정 경로

| 실패가 처음 나타난 단계 | 다음 변경 |
|---|---|
| 해시/규격 확인 | 올바른 release로 pair를 복원. 현재 source로 JSON을 임의 생성해 우회하지 않음 |
| 추론/관측 수치 비교 | 환경·변환기·history/scale/위상 구현 수정. 그 전까지 모터 정책 시험 보류 |
| 실제 관절 방향/영점 | 기체 변환/조립 보정, 같은 관절 재시험 |
| 정책 없는 부하 시험 | 제한·전원·게인 적용 여부·모터 응답 식별. 실측을 sim에 반영 |
| 영속도 WALK만 실패 | 첫 목표 변화, 제한 개입, 관측과 하중 응답을 원본 sim과 비교 |
| 실측 동특성을 넣은 sim에서도 실패 | WALK를 그 조건으로 재학습/이어학습하고 같은 시험으로 재평가 |
| 정지 통과, 이동/정지 전환만 실패 | 명령 시퀀스·가감속·접촉·제동 응답을 고정하여 비교 |
| WALK는 통과, 회복만 실패 | 회복 정책·팔 가동 능력·전환/handoff를 별도 시험 |

최근 소스의 DelayedPD, 정지 보상은 이전 가중치에 소급 적용되지 않는다.
기존 implicit actuator 기반 비교와 새 explicit DelayedPD 학습을 구분한다.
재학습 여부는 위 시험으로 정하며 RECOVERY만 교체해서 WALK 지지 붕괴가 해결됐다고 판단하지 않는다.

추종 식별은 동일한 목표 입력으로 sim/real의 시간 응답을 맞추는 작업이다.
지연 정렬 전후 오차와 지연값을 함께 남긴다. 정렬로 사라진 오차도 제어 성능 평가에서는
사라진 것으로 취급하지 않는다. 추정한 지연에 기계적 응답까지 포함되어 있으면 이를 통신
지연과 actuator 모델 양쪽에 중복 반영하지 않는다.

## 9. 저속 이동과 회복으로 확장

영속도 시험을 반복 통과한 뒤, 같은 바닥에서 짧은 전진→영속도 정지 시퀀스를 수행한다.
예를 들어 0.05m/s는 초기 후보 명령이며, 그 값에서 실제 걷기가 가능한지는 sim과 실물에서 확인한다.
작은 값이면 무조건 안정적이거나 유효한 명령이라는 뜻은 아니다.

입력/지속 시간을 고정하고 외부 영상·마커 등 독립 측정으로 실제 이동량을 비교한다.
cmd_vel을 적분한 odometry를 실제 이동 속도의 정답으로 사용하지 않는다.
전진/정지 통과 후 후진·횡이동·회전을 분리해 범위를 넓힌다.

그 뒤에 지지 장치를 갖추고 작은 기울기/외란에서 RECOVERY를 평가한다.
완전히 누운 상태의 get-up은 `fall_after_walk`의 목적이 아니므로 별도 절차로 다룬다.

## 10. 기록해 둘 외부 참고 소스와 당장 필요한 보강

RoboÉireann 2026 소스는 참고 후보로 유지한다. 실물 실패 해결보다 앞서 전체 보행 엔진을
이식하지 않는다. 검토 커밋은 `2e81de97423d1e4023bc71c3010712751eff651f`이다.

- [JointPlayProvider](https://github.com/roboeireann/RoboEireannCodeRelease/blob/2e81de97423d1e4023bc71c3010712751eff651f/Src/Modules/Sensing/JointPlayProvider/JointPlayProvider.cpp):
  과거 명령 버퍼를 이용한 관절 추종 진단. 지연/정상값/고장 점수는 그대로 가져오지 않음.
- [ReplayWalkRequestProvider](https://github.com/roboeireann/RoboEireannCodeRelease/blob/2e81de97423d1e4023bc71c3010712751eff651f/Src/Modules/MotionControl/WalkingEngine/WalkGenerators/ReplayWalkRequestProvider.cpp):
  시작 조건이 있는 반복 시험. 현재 구조에서는 cmd_vel 시퀀스 시험기로 재구현할 후보.

현 단계에서 필요한 추가 계측은 (1) 센서/목표 timestamp 보존, (2) 실제 관측과 raw action,
제한 전후 목표 저장, (3) 지연 정렬 전후 추종 지표이다. 이 기능들은 아직 구현하지 않았다.
기존 rosbag 수집만으로 확보할 수 있는 원본 데이터를 먼저 확보한다.

공식 참고:

- [NumPy 호환 오류](https://numpy.org/doc/stable/user/troubleshooting-importerror.html)
- [TensorRT 엔진 호환성](https://docs.nvidia.com/deeplearning/tensorrt/latest/inference-library/engine-compatibility.html)
- [Isaac Sim 시스템 식별 절차](https://docs.isaacsim.omniverse.nvidia.com/latest/robot_setup/ext_isaacsim_robot_setup_sysid.html)
  — 설치된 기존 Isaac 버전에 해당 확장이 있다고 가정하지 않는다. 명령·응답을 측정하고
  모델을 맞춘 뒤 별도 입력으로 검증하는 절차를 참고한다.

## 11. 현재 진행 상태

- 완료: 최신 실패 확인, 로컬 해시·매핑 테스트, 로봇 파일 해시 연결과 현재 단독 추론 확인,
  실패 원본 bag 확보·1차 시간축 분석, 실행 절차 정리.
- 미완료: 당시 실행/학습 설정과 모델 동일성의 연결, 지지 조건 확인, 실제 방향·영점 및
  부하 추종, 실관측 parity, 영속도/저속 이동/회복 시험.
- 현재 Windows Python 3.12 환경에는 NumPy가 없어 정책 수치 테스트를 이번에 실행하지 않았다.
  매핑 테스트 통과를 정책 수치 검증이나 실물 성공으로 확대 해석하지 않는다.

## 12. 한 단계씩 진행하는 작업표

사용자 요청에 따라 각 작업 결과를 확인할 때마다 다음 형식으로 보고한다.

1. 이번에 완료한 작업과 확인 근거
2. 통과/실패/미확인 및 그 의미
3. 바로 다음에 진행할 작업
4. 아직 남은 단계

명령 전달만으로 완료 처리하지 않는다. 실행 결과를 확인하고 해당 단계의 통과 조건이
충족된 뒤 다음 단계로 넘어간다. 문제가 발견되면 현재 단계에서 수정·재확인한다.
현재 조회와 기록 작업을 먼저 진행하며 실제 움직임 시험은 기체 준비 상태 확인 후 진행한다.

| 단계 | 작업 | 상태 |
|---|---|---|
| 사전 조사 | 최신 실패 확인, 로컬 파일 해시·이름/ID 매핑, 실행 계획 | 완료 |
| 1 | 로봇의 현재 ROS 환경·노드·배포 파일·목표 발행자 조회 | 조회 완료 |
| 2 | 실제 실행 모델/규격/엔진 해시 및 학습 원본·실패 로그 대조 | 로봇 범위 불일치 확정, 수정 도구 검증 완료·적용 결과 대기 |
| 3 | 관절 실제 방향·영점 및 IMU 좌표 확인 | 미진행 |
| 4 | 정책 없는 기본 자세 유지 및 부하 추종 시험 | 미진행 |
| 5 | Preview, 실제 관측/추론 비교, 기록 준비 | 미진행 |
| 6 | 짧은 영속도 Live에서 정지 균형 반복 확인 | 미진행 |
| 7 | 저속 이동·정지 후 작은 외란/회복 시험 | 미진행 |

1단계에서는 로봇 Jetson의 기존 터미널에서 ROS setup을 읽은 뒤 환경 변수,
`ros2 node list`, `models/tensorrt/` 파일 목록, `/joint_goals` 발행자를 확인한다.
노드나 파일이 없는 결과도 그대로 기록한다. 없다는 이유로 하드웨어/정책 노드를
자동 실행하지 않는다. ROS domain이 기존 실행 환경과 일치하는지도 먼저 확인한다.

### 사용자 제공 1단계 결과

- Jetson 작업 경로: `/home/robo04/sim2real_ws`.
- `ROS_DOMAIN_ID=42`, `ROS_LOCALHOST_ONLY=1`.
- `ros2 node list` 출력 없음. 해당 터미널의 ROS 검색 범위에서는 노드를 발견하지 못했다.
- `models/tensorrt/`에 WALK/RECOVERY 각각 `.engine`, `.json`, `.build.json` 총 6개 존재.
  표시된 수정 시각은 모두 9월 28일 12:49. 수정 시각은 모델 동일성이나 검증 통과의 증거가 아니다.
- `/joint_goals`: `Unknown topic`. 노드 미발견 결과와 일치한다. 다른 domain/프로세스의
  제어 여부나 실제 모터 토크 상태가 확인된 것은 아니다.
- 다음: ROS 노드를 실행하지 않고 원본 `.pt`와 source JSON, 엔진과 배포 JSON/빌드 보고서의
  해시 연결을 검사한다. 이후 실행 환경/실패 원본 기록을 대조한 뒤 2단계를 완료 판정한다.

### 사용자 제공 2-1단계 결과와 로컬 대조

- WALK/RECOVERY 모두 체크포인트 해시 연결, 엔진 해시 연결, 역할/관측 크기,
  20ms 정책 간격, 검증 flag 검사 통과.
- 로봇 WALK SHA-256은 로컬 기본 WALK와 일치:
  `9ac0d65d4c27e8d95c05f3e350ec39b0b322c21f345ca30bab26ad1a9dcdd1b8`.
- 로봇 RECOVERY SHA-256:
  `eb348928966aa4e9bc54191df4d4e58c6d07a79defc595bae870b3146b85b79c`.
  로컬 `RL-Model-save/releases/0923_retraining_10000/RL_fall_after_walk.pt`를 직접
  해시 계산하여 동일함을 확인했다. 로컬 기본 RECOVERY(`fdcb...`)와는 다른 파일이다.
  따라서 현재 실물 기준 조합은 기본 WALK + `0923_retraining_10000` RECOVERY로 기록한다.
  이번 진단에서 RECOVERY를 로컬 기본 파일로 덮어쓰지 않는다.
- 두 엔진의 기록상 TensorRT는 10.3.0, GPU는 Orin.
- 빌드 보고서의 p99 시간은 WALK 약 0.2374ms, RECOVERY 약 0.2329ms.
  저장된 측정값이며 현재 환경에서 새로 측정한 결과가 아니다.
- 다음: 기존 정책 전용 NumPy 경로에서 Torch/NumPy 변환과 현재 TensorRT 버전을 확인하고,
  ROS 노드/모터 출력 없이 두 엔진의 영벡터 단독 추론을 실행한다. 그 뒤 원본 학습 설정과
  실패 시계열의 가용성을 확인한다.

### 사용자 제공 2-2단계 결과

- 2026-10-29 로봇 출력: Python 3.10.12, 전용 NumPy 1.26.4,
  PyTorch `2.5.0a0+872d972e41.nv24.08`, TensorRT 10.3.0, GPU Orin.
- Torch/NumPy 변환, CUDA 사용, 계약 검사, 엔진 로드 및 엔진별 영벡터 20회 추론 통과.
- WALK 중앙/최대: 0.3389/0.3495ms. RECOVERY 중앙/최대: 0.3358/0.3554ms.
- 두 엔진에서 모두 다른 장치 모델용 plan 사용 가능성을 알리는 TensorRT 경고가 발생했다.
  로드/영벡터 추론의 제한된 통과이며 장치 호환성 전체가 검증된 것은 아니다.
- 이번 검사는 실제 센서 관측, 원본 Actor 대비 출력 일치, 부하 상태의 50Hz 전체 루프,
  실물 균형을 검증하지 않는다. 기존 NumPy 시작 실패는 현재 이 터미널에서 재현되지 않았다.
- 장치 경고는 실물 넘어짐의 확정 원인으로 취급하지 않는다. Live 전에 현재 장치에서의
  빌드 조건과 실제 관측 parity를 확인하고, 필요하면 원본을 보존한 별도 후보 경로에서
  엔진을 재생성·검증한다.
- 다음은 2-3: 로봇의 10월 7일 실패 원본 로그를 날짜/실험명으로 찾아 목록을 확보한다.
  원본이 없으면 검색 범위와 미확보 상태를 기록한 뒤 새 시험의 기록 준비로 이어간다.

### 사용자 제공 2-3단계: 실패 원본 위치 확인

Jetson의 `/home/robo04/sim2real_ws/debug_bags/`에서 다음 5개 rosbag 디렉터리의
`.db3`와 `metadata.yaml`이 확인됐다.

- `walk_20261007_161217` — 기존 실패 분석 문서에서 인용한 우선 분석 대상.
- `zero_walk_20261007_155556`
- `walk_20261007_160134`
- `walk_20261007_155219`
- `walk_20261007_161045`

`/home/robo04/.ros/log/`에도 10월 7일 15:51~16:12 launch 로그 7개가 발견됐다.
디렉터리 시각만으로 특정 bag과 실행 설정의 연결을 확정하지 않는다.
`odom_experiments` 디렉터리는 없었지만 위 원본 bag이 발견되어 해당 경로의 부재를
기록 유실로 해석하지 않는다.

다음 조회는 `ros2 bag info .../walk_20261007_161217`이다. 기록 시간과 토픽/메시지형/
메시지 수를 확인한 뒤, 실제 기록된 필드로 목표·실측·IMU·정책 상태의 시계열을 추출한다.
bag의 내용과 원본 학습 설정은 아직 분석하지 않았다. 원본 bag은 재기록하거나 덮어쓰지 않는다.

### 사용자 제공 2-3단계: rosbag 메타데이터

`walk_20261007_161217`: sqlite3, 55.3MiB, 422.145327413초,
2026-10-07 16:12:17.876~16:19:20.021, 메시지 120364개.

| 토픽 | 메시지 수 |
|---|---:|
| `/joint_goals` | 126 |
| `/xm540_dual_policy/preview_joint_goals` | 126 |
| `/joint_states` | 20257 |
| `/imu/data` | 84367 |
| `/cmd_vel` | 4127 |
| `/xm540_dual_policy/state` | 2071 |
| `/motor_diagnostics` | 845 |
| `/u2d2/behavior_status` | 8442 |
| `/u2d2/torque_enabled` | 2 |
| `/buttons/stop_pressed` | 1 |

전체 시간 대비 목표 메시지 평균을 정책 실행 주기로 해석하지 않는다. 목표 발행이 실제로
이루어진 구간과 간격을 DB timestamp/header timestamp로 확인한다. 현재 코드상 preview와
실제 목표는 모두 limiter 이후 값이므로 이 bag만으로 raw action/제한 전 목표를 직접 알 수 없다.
정책 상태는 약 5Hz, 진단은 약 2Hz로 기록되어 사건의 정확한 순간/빠른 전류 변화에는
해상도 한계가 있다. 현재 배포 모델의 해시가 과거 시험 당시 모델과 같다는 확인은 별도로 필요하다.

현재 도구 환경에서 Jetson SSH의 비대화형 공개키 인증이 되지 않아 원본을 직접 읽지 못했다.
사용자 Windows에서 DB와 metadata를 공유 작업 폴더 바깥쪽의
`C:/Users/jes/Desktop/isaac_ws/sim2real_evidence/walk_20261007_161217/`로 복사한 뒤
SQLite 읽기 전용 분석을 진행한다. 내용 분석 결과는 아직 없다.

### 2-3 원본 분석 진행 결과

사용자 복사 후 로컬에서 DB를 읽기 전용으로 분석했다.
[원본 분석 보고서](XM540_FAILURE_20261007_ANALYSIS.md)에 수치·방법·한계·자료 위치를 기록했다.

- 목표 126개는 약 2.499초 구간, 간격 중앙 19.976ms/최대 20.776ms.
- 영속도 명령 중 목표 변화와 추종 차이가 관측되며 기울기는 1.005초에 5도,
  1.335초에 10도를 처음 초과했다.
- RECOVERY/FAULT 최초 상태 보고는 2.239/2.638초. FAULT 문자열은 회복 제한 관련이다.
  상태는 5Hz이므로 정확한 내부 전환 시각은 아니다.
- 최초 2초에 오른 무릎 0.185rad, 왼 발목 pitch 0.188rad 최대 동시각 추종 차이.
- 당시 모터 behavior 활성화·토크 OFF·물리 STOP 기록은 실패 구간에서 발견되지 않았다.
- bag만으로 지지 여부, 실제 기구 영점, raw action, 당시 파라미터·모델 파일 동일성을
  확정할 수 없다. 다음은 당시 launch 로그/학습 설정과 실물 지지 조건 대조다.

### 2026-11-02 사용자 확인: 지지 조건

- 정책 시작 무렵 보조 지지를 놓았다는 답변을 받았다. 정확한 지지 제거 시각과 하중은 미확인.
- 시작 전 일정한 자세를 자립/체중 부하 유지 성공의 근거로 쓰지 않는다.
- 관절/IMU 정합 다음에 정책 없는 부하 유지, 그다음 이미 하중을 받는 상태에서의 정책 시작을
  분리해 시험한다. 기체 준비와 넘어짐 방지 조건은 실제 시험 전에 확인한다.
- 원본 분석 보고서에 이 조건과 해석 한계를 추가했다.
- `sim2real_evidence/launch_logs_20261007`은 현재 로컬에 발견되지 않았다.
  다음 작업은 이전에 안내한 당시 launch 로그 복사/확인으로 유지한다.

### 2026-11-02 launch 로그 확인 후 다음 작업

- 위 로그 미확보 상태는 이후 사용자 복사로 해소됐다. 로그 7개를 직접 읽었다.
- 시작 직후 실패한 앞선 실행과 실제 목표 발행을 한 마지막 실행을 구분했다.
- 마지막 실행 로그에는 파라미터 값/엔진 경로가 없다. 과거 설정은 미확인으로 남기고
  추가 추정으로 수정하지 않는다. 상세한 판단은 원본 분석 보고서 6절을 따른다.
- 다음 수집 파일은 9월 2일 후보 학습 run의 `model_9999.pt`, `params/env.yaml`,
  `params/agent.yaml`이다. 로컬 목적지는
  `C:/Users/jes/Desktop/isaac_ws/sim2real_evidence/training_walk_0902/`.
- 원본 checkpoint를 함께 가져와 로봇 WALK의 `9ac0...` 해시와 일치하는지 확인한 뒤
  actuator 방식·게인/제한·dt·기본 자세·관측/위상·학습 설정을 대조한다.

### 2026-11-02 학습 원본 대조 완료

- `training_walk_0902/model_9999.pt` 해시가 로봇 WALK와 정확히 같았다.
- 당시 saved YAML의 제어 주기, action scale/default offset, 관측 순서/배율/이력/위상 period,
  activation/normalization, 명시된 관절 기본각을 로컬 계약과 대조했다.
- 구동기는 당시 Implicit였으며 현재 소스의 지연 PD와 다르다. 정지 학습 비율도 당시 0.1,
  현재 소스 0.35이며 현재 stationary 보상은 기존 가중치에 들어 있지 않다.
- 로컬 JSON command_limits는 학습 YAML보다 2배 넓었다. 로봇의 source/deployed JSON 필드는
  아직 직접 출력되지 않았으므로 실제 로봇 적용 여부는 다음 조회에서 확인한다.
- 0 명령 실패의 직접 원인으로 범위 불일치를 단정하지 않는다. 이동 시험 전 해결할 항목이다.
- 원본/모델/엔진/로봇 계약은 수정하지 않았다. 세부 수치와 미확인 항목은 원본 분석 보고서 7절,
  구조화된 비교 결과는 `sim2real_evidence/training_walk_0902/training_contract_audit.json`에 있다.
- 다음은 로봇 command_limits 한 번 조회 후 관절·IMU 정합 단계다. 당시 USD 내용/실행 파라미터
  완전 복원은 미확인으로 남기고, 새 시험에서는 실행 조건과 관측을 명시적으로 기록한다.

### 로봇 command_limits 확인 후 수정 준비

- 사용자 출력으로 로봇 source/deployed WALK JSON 모두 학습의 2배 범위임을 확인했다.
- `scripts/repair_xm540_walk_limits.py`를 작성하고 6개 테스트를 통과했다.
- 수정 범위는 현재 0902 WALK의 두 JSON command_limits뿐이다. 백업·해시 검사·프로세스
  중지 검사·재조회·예외 원복을 포함한다. 로봇 적용 결과는 아직 받지 않았다.
- Windows PowerShell에서 파일을 SSH 표준입력으로 전달해 별도 설치 없이 실행할 수 있다.

```powershell
cd C:\Users\jes\Desktop\isaac_ws\isaac_ws
Get-Content -Raw .\sim2real_ws\scripts\repair_xm540_walk_limits.py | ssh robo04@192.168.1.161 "python3 - --models /home/robo04/sim2real_ws/models --apply"
```

`REPAIRED_AND_VERIFIED` 또는 `ALREADY_CORRECT`와 최종 범위를 확인한 뒤 3단계 관절·IMU
조회로 넘어간다. 정책이 실행 중이거나 입력 검사가 실패하면 원인을 확인한 뒤 재실행하며,
이 도구 자체는 모터 명령·토크·정책 시작/정지 서비스를 호출하지 않는다.
