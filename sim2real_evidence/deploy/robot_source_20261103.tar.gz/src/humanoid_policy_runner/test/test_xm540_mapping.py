"""Checks for the name-based simulator-to-servo mapping."""

from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from humanoid_policy_runner.xm540_verify_mapping import verify_mapping


REPO_ROOT = Path(__file__).resolve().parents[4]
WALK = REPO_ROOT / "RL-Model-save" / "RL_walk.json"
RECOVERY = REPO_ROOT / "RL-Model-save" / "RL_fall_after_walk.json"
SERVO_MAP = (
    REPO_ROOT
    / "sim2real_ws"
    / "src"
    / "humanoid_serial_bridge"
    / "config"
    / "servo_map.yaml"
)


class XM540MappingTests(unittest.TestCase):
    def test_current_contracts_map_every_action_to_one_servo(self) -> None:
        rows = verify_mapping(WALK, RECOVERY, SERVO_MAP)
        self.assertEqual(len(rows), 20)
        self.assertEqual({row[2] for row in rows}, set(range(1, 21)))
        self.assertEqual(rows[0][1], "l_pelvis_pitch_joint")
        self.assertEqual(rows[0][2], 11)

    def test_different_policy_orders_are_rejected(self) -> None:
        recovery = json.loads(RECOVERY.read_text(encoding="utf-8"))
        recovery["joint_names"] = list(reversed(recovery["joint_names"]))
        with tempfile.TemporaryDirectory() as directory:
            changed = Path(directory) / "recovery.json"
            changed.write_text(json.dumps(recovery), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "action orders differ"):
                verify_mapping(WALK, changed, SERVO_MAP)


if __name__ == "__main__":
    unittest.main()
