"""Numerical policy history, handoff and real-checkpoint regression tests."""

import hashlib
import json
import math
from pathlib import Path
import sys
import subprocess
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from humanoid_policy_runner.xm540_policy import (
    CheckpointActor, DualPolicy, GoalSafetyLimiter, ObservationHistory, PolicySwitch, SwitchConfig,
    load_contract, projected_gravity,
)


def contract(walk=True):
    names = [f"leg_{i}" for i in range(12)] + [f"shoulder_{i}" for i in range(6)] + ["neck_yaw_joint", "neck_pitch_joint"]
    specs = [("base_ang_vel", 3, .2), ("projected_gravity", 3, 1.), ("velocity_commands", 3, 1.),
             ("joint_pos_rel", 20, 1.), ("joint_vel_rel", 20, .05), ("last_action", 20, 1.)]
    if walk:
        specs.append(("gait_phase", 2, 1.))
    return {
        "joint_names": names, "default_joint_pos": [0.] * 20, "action_scale": [.2] * 20,
        "step_dt": .02, "gait_period": .8, "action_clip": None,
        "lower_limits": [-2.] * 20, "upper_limits": [2.] * 20,
        "terms": [{"name": n, "size": s, "scale": scale, "clip": None, "history_length": 5} for n, s, scale in specs],
    }


class PolicyTests(unittest.TestCase):
    def test_checkpoint_contract_identity_and_parity_required(self):
        with tempfile.TemporaryDirectory() as directory:
            checkpoint = Path(directory) / "model.pt"
            metadata = Path(directory) / "model.json"
            checkpoint.write_bytes(b"checkpoint identity fixture")
            c = contract()
            c.update(schema_version=1, role="walk", observation_size=355,
                     history_layout="term_major_oldest_first", observation_parity_max_error=0.,
                     command_limits=[[-.3, .7], [-.2, .2], [-.3, .3]],
                     checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest())
            metadata.write_text(json.dumps(c), encoding="utf-8")
            self.assertEqual(load_contract(metadata, checkpoint)["observation_size"], 355)
            c["observation_parity_max_error"] = 1.
            metadata.write_text(json.dumps(c), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "parity"):
                load_contract(metadata, checkpoint)
            checkpoint.write_bytes(b"different checkpoint")
            with self.assertRaisesRegex(ValueError, "different checkpoint"):
                load_contract(metadata, checkpoint)

    def test_history_is_term_major_oldest_first_with_repeat_reset(self):
        c = {"terms": [{"name": n, "size": 1, "scale": 1., "clip": None, "history_length": 3} for n in ("a", "b")]}
        h = ObservationHistory(c)
        np.testing.assert_array_equal(h.append({"a": [1], "b": [10]}), [1, 1, 1, 10, 10, 10])
        np.testing.assert_array_equal(h.append({"a": [2], "b": [20]}), [1, 1, 2, 10, 10, 20])
        h.reset()
        np.testing.assert_array_equal(h.append({"a": [3], "b": [30]}), [3, 3, 3, 30, 30, 30])

    def test_clip_before_scale(self):
        c = {"terms": [{"name": "a", "size": 1, "scale": .2, "clip": [-1, 1], "history_length": 1}]}
        np.testing.assert_allclose(ObservationHistory(c).append({"a": [3]}), [.2])

    def test_quaternion_tilt_including_upside_down(self):
        np.testing.assert_allclose(projected_gravity([0, 0, 0, 2]), [0, 0, -1])
        np.testing.assert_allclose(projected_gravity([1, 0, 0, 0]), [0, 0, 1])
        np.testing.assert_allclose(projected_gravity([math.sin(math.pi/12), 0, 0, math.cos(math.pi/12)]), [0, -.5, -math.sqrt(3)/2])
        with self.assertRaises(ValueError):
            projected_gravity([0, 0, 0, 0])

    def test_hysteresis_and_settle_reset(self):
        switch = PolicySwitch(SwitchConfig())
        self.assertEqual(switch.update(0, 29, 0, 0), "WALK")
        self.assertEqual(switch.update(.1, 30, 0, 0), "RECOVERY")
        self.assertEqual(switch.update(.2, 11, 0, 0), "RECOVERY")
        self.assertEqual(switch.update(.6, 13, 0, 0), "RECOVERY")
        self.assertEqual(switch.update(.7, 11, 0, 0), "RECOVERY")
        self.assertEqual(switch.update(1.21, 11, 0, 0), "WALK")

    def test_motion_or_pose_blocks_return(self):
        for gyro, error in [(1., 0.), (0., .6)]:
            s = PolicySwitch(SwitchConfig())
            s.update(0, 30, 0, 0)
            s.update(.1, 0, gyro, error)
            self.assertEqual(s.update(1, 0, gyro, error), "RECOVERY")

    def test_fault_is_latched_and_timeout_is_bounded(self):
        s = PolicySwitch(SwitchConfig())
        self.assertEqual(s.update(0, 180, 0, 0), "FAULT")
        self.assertEqual(s.update(1, 0, 0, 0), "FAULT")
        s.reset()
        s.update(0, 40, 0, 0)
        self.assertEqual(s.update(6, 40, 0, 0), "FAULT")

    def test_invalid_thresholds(self):
        for values in ({"exit_deg": 35}, {"enter_deg": float("nan")}, {"settle_s": -1}):
            with self.assertRaises(ValueError):
                SwitchConfig(**values)

    def test_goal_safety_limiter_blends_and_limits_steps(self):
        limiter = GoalSafetyLimiter(blend_seconds=2.0, max_step_rad=.04)
        start = np.linspace(-1, 1, 20, dtype=np.float32)
        limiter.reset(start, 10.0)
        np.testing.assert_allclose(limiter.apply(start + 1, 10.0), start)
        first = limiter.apply(start + 1, 10.5)
        np.testing.assert_allclose(first, start + .04, atol=1e-7)
        second = limiter.apply(start + 1, 10.52)
        np.testing.assert_allclose(second, start + .08, atol=1e-7)
        recovery = limiter.apply(start + 1, 10.54, max_step_rad=.08)
        np.testing.assert_allclose(recovery, start + .16, atol=1e-7)
        with self.assertRaisesRegex(ValueError, "positive"):
            GoalSafetyLimiter(blend_seconds=0)

    def test_separate_dimensions_zero_recovery_command_and_selected_action(self):
        seen = {}
        def actor(mode, action):
            def infer(obs):
                seen[mode] = obs.copy()
                return np.full(20, action, dtype=np.float32)
            return infer
        policy = DualPolicy(contract(), contract(False), actor("WALK", 1), actor("RECOVERY", 2), SwitchConfig())
        state = (np.zeros(20), np.zeros(20), np.zeros(3))
        mode, goals, _ = policy.step(0, *state, [0, 0, -1], [.2, 0, 0])
        self.assertEqual(seen["WALK"].shape, (355,))
        np.testing.assert_allclose(goals[:12], .2)
        np.testing.assert_allclose(goals[12:], 0)
        mode, goals, _ = policy.step(.02, *state, [0, .6, -.8], [.2, 0, 0])
        self.assertEqual(mode, "RECOVERY")
        self.assertEqual(seen["RECOVERY"].shape, (345,))
        np.testing.assert_array_equal(seen["RECOVERY"][30:45], 0)  # command history
        np.testing.assert_array_equal(seen["RECOVERY"][-20:], 1)  # previous WALK action
        np.testing.assert_allclose(goals[:18], .4)
        np.testing.assert_allclose(goals[18:], 0)

    def test_contract_mismatch_rejected(self):
        recovery = contract(False)
        recovery["joint_names"] = list(reversed(recovery["joint_names"]))
        with self.assertRaises(ValueError):
            DualPolicy(contract(), recovery, None, None, SwitchConfig())

    def test_provided_checkpoints_match_independent_functional_forward(self):
        import torch
        workspace = Path(__file__).resolve().parents[4]
        for filename, dim in (("RL_walk.pt", 355), ("RL_fall_after_walk.pt", 345)):
            path = workspace / "RL-Model-save" / filename
            if not path.exists():
                self.skipTest("Local user checkpoints not present")
            actor = CheckpointActor(path, dim)
            state = torch.load(path, map_location="cpu", weights_only=True)["model_state_dict"]
            observation = np.random.default_rng(42).normal(0, .2, dim).astype(np.float32)
            x = torch.from_numpy(observation)
            for index in (0, 2, 4, 6):
                x = torch.nn.functional.linear(x, state[f"actor.{index}.weight"], state[f"actor.{index}.bias"])
                if index != 6:
                    x = torch.nn.functional.elu(x)
            np.testing.assert_allclose(actor(observation), x.numpy(), atol=2e-6, rtol=2e-5)
            with self.assertRaises(ValueError):
                CheckpointActor(path, 345 if dim == 355 else 355)

    def test_onnx_export_and_inference_without_torch_import(self):
        from humanoid_policy_runner.xm540_export_onnx import export_actor
        from humanoid_policy_runner.xm540_policy import OnnxActor
        workspace = Path(__file__).resolve().parents[4]
        with tempfile.TemporaryDirectory() as directory:
            for filename, size in (("RL_walk.pt", 355), ("RL_fall_after_walk.pt", 345)):
                checkpoint = workspace / "RL-Model-save" / filename
                if not checkpoint.exists():
                    self.skipTest("Local user checkpoints not present")
                output = Path(directory) / (filename + ".onnx")
                report = export_actor(checkpoint, output, size)
                self.assertEqual(report["onnx_parity_samples"], 49)
                self.assertLess(report["onnx_parity_max_error"], 2e-5)
                with self.assertRaises(ValueError):
                    OnnxActor(output, 345 if size == 355 else 355)
                program = (
                    "import sys; sys.path.insert(0, sys.argv[1]); "
                    "import numpy as np; "
                    "from humanoid_policy_runner.xm540_policy import OnnxActor; "
                    "actor=OnnxActor(sys.argv[2], int(sys.argv[3])); "
                    "assert actor(np.zeros(int(sys.argv[3]), dtype=np.float32)).shape == (20,); "
                    "assert 'torch' not in sys.modules"
                )
                subprocess.run([sys.executable, "-c", program, str(Path(__file__).resolve().parents[1]),
                                str(output), str(size)], check=True)


if __name__ == "__main__":
    unittest.main()
