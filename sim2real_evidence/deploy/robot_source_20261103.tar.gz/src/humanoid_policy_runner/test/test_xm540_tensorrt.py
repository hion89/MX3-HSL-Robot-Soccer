"""CPU checks for direct TensorRT graph wiring; actual GPU tests run on Jetson."""

from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from humanoid_policy_runner.xm540_policy import CheckpointActor
from humanoid_policy_runner.xm540_tensorrt import build_engine, require_tensorrt10
from humanoid_policy_runner.xm540_build_tensorrt import verify_engine


class Tensor:
    def __init__(self, evaluate):
        self.evaluate = evaluate


class Layer:
    def __init__(self, evaluate):
        self.tensor = Tensor(evaluate)
        self.alpha = 1.0

    def get_output(self, index):
        return self.tensor


class Network:
    def add_input(self, *args):
        return Tensor(lambda x: x)

    def add_constant(self, shape, values):
        return Layer(lambda x: values)

    def add_matrix_multiply(self, a, op_a, b, op_b):
        if (op_a, op_b) != ("NONE", "TRANSPOSE"):
            raise AssertionError("Invalid matrix transpose convention")
        return Layer(lambda x: a.evaluate(x) @ b.evaluate(x).T)

    def add_elementwise(self, a, b, op):
        if op != "SUM":
            raise AssertionError("Invalid bias operation")
        return Layer(lambda x: a.evaluate(x) + b.evaluate(x))

    def add_activation(self, a, op):
        if op != "ELU":
            raise AssertionError("Invalid actor activation")
        layer = Layer(lambda x: np.maximum(a.evaluate(x), 0) +
                      layer.alpha * np.expm1(np.minimum(a.evaluate(x), 0)))
        return layer

    def mark_output(self, output):
        self.output = output


class TRTTests(unittest.TestCase):
    def test_only_target_api_major_is_accepted(self):
        require_tensorrt10(SimpleNamespace(__version__="10.3.0"))
        for version in ("8.6.1", "11.0.0"):
            with self.assertRaises(RuntimeError):
                require_tensorrt10(SimpleNamespace(__version__=version))

    def test_bad_engine_outputs_fail_validation(self):
        reference = lambda x: np.zeros(20)
        for output in (np.ones(20), np.full(20, np.nan)):
            with self.assertRaises((AssertionError, ValueError)):
                verify_engine(reference, lambda x: output, 355, "fp32")

    def test_direct_graph_matches_both_checkpoint_actors(self):
        workspace = Path(__file__).resolve().parents[4]
        for name, size in (("RL_walk", 355), ("RL_fall_after_walk", 345)):
            checkpoint = workspace / "RL-Model-save" / (name + ".pt")
            if not checkpoint.exists():
                self.skipTest("User checkpoints not available")
            actor = CheckpointActor(checkpoint, size)
            graph = Network()
            flags = []
            config = SimpleNamespace(set_memory_pool_limit=lambda *a: None,
                                     clear_flag=lambda flag: flags.append(("clear", flag)),
                                     set_flag=lambda flag: flags.append(("set", flag)))
            builder = SimpleNamespace(create_network=lambda _: graph, create_builder_config=lambda: config,
                                      build_serialized_network=lambda *a: b"test-plan", platform_has_fast_fp16=True)
            class Logger:
                WARNING = 1
                def __init__(self, *args):
                    pass
            trt = SimpleNamespace(__version__="10.3.0", Logger=Logger, Builder=lambda _: builder,
                                  float32="float32", MemoryPoolType=SimpleNamespace(WORKSPACE=1),
                                  BuilderFlag=SimpleNamespace(TF32="tf32", FP16="fp16"),
                                  MatrixOperation=SimpleNamespace(NONE="NONE", TRANSPOSE="TRANSPOSE"),
                                  ElementWiseOperation=SimpleNamespace(SUM="SUM"),
                                  ActivationType=SimpleNamespace(ELU="ELU"))
            with tempfile.TemporaryDirectory() as directory, patch.dict(sys.modules, tensorrt=trt), \
                 patch.object(actor.torch.cuda, "is_available", return_value=True), \
                 patch.object(actor.torch.cuda, "set_device"):
                output = Path(directory) / "model.engine"
                build_engine(actor, output)
                self.assertEqual(output.read_bytes(), b"test-plan")
            self.assertIn(("clear", "tf32"), flags)
            rng = np.random.default_rng(12)
            for _ in range(8):
                observation = rng.normal(0, .5, size).astype(np.float32)
                np.testing.assert_allclose(graph.output.evaluate(observation[None])[0], actor(observation),
                                           atol=2e-5, rtol=2e-5)


if __name__ == "__main__":
    unittest.main()
