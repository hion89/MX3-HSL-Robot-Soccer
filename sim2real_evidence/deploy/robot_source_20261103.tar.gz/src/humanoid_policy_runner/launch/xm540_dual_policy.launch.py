"""Standalone XM540 policy owner; hardware is started separately."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    paths = ("walk_checkpoint", "recovery_checkpoint", "walk_contract", "recovery_contract")
    numeric = {
        "enter_tilt_deg": "20.0", "exit_tilt_deg": "10.0", "settle_seconds": "0.5",
        "exit_angular_speed": "0.5", "exit_pose_error": "0.35",
        "max_recovery_seconds": "8.0", "stop_tilt_deg": "55.0",
        "startup_blend_seconds": "2.0", "max_goal_step_rad": "0.04",
        "recovery_max_goal_step_rad": "0.08",
    }
    arguments = [DeclareLaunchArgument(p) for p in paths]
    arguments.append(DeclareLaunchArgument("inference_backend", default_value="onnx"))
    arguments += [DeclareLaunchArgument(k, default_value=v) for k, v in numeric.items()]
    arguments.append(DeclareLaunchArgument("publish_joint_goals", default_value="false"))
    params = {p: ParameterValue(LaunchConfiguration(p), value_type=str) for p in paths}
    params["inference_backend"] = ParameterValue(LaunchConfiguration("inference_backend"), value_type=str)
    params.update({p: ParameterValue(LaunchConfiguration(p), value_type=float) for p in numeric})
    params["publish_joint_goals"] = ParameterValue(LaunchConfiguration("publish_joint_goals"), value_type=bool)
    return LaunchDescription(arguments + [Node(
        package="humanoid_policy_runner", executable="xm540_dual_policy",
        name="xm540_dual_policy", parameters=[params], output="screen",
    )])
