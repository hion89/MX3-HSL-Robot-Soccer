"""Verify that XM540 policy action indices resolve to the intended motor IDs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys


def _load_contract(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    names = data.get("joint_names")
    if not isinstance(names, list) or len(names) != 20 or len(set(names)) != 20:
        raise ValueError(f"{path}: expected 20 unique joint_names")
    return data


def _load_servo_sections(path: Path) -> tuple[dict, dict, dict]:
    """Read the integer mapping sections without adding a runtime YAML dependency."""
    sections = {"joint_map": {}, "direction_control": {}, "direction_display": {}}
    top_level = None
    active = None
    entry = re.compile(r"^([A-Za-z0-9_]+)\s*:\s*(-?\d+)\s*$")
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip())
        text = line.strip()
        if indent == 0 and text.endswith(":"):
            top_level = text[:-1]
            active = "joint_map" if top_level == "joint_map" else None
            continue
        if top_level == "limits" and indent == 2 and text.endswith(":"):
            name = text[:-1]
            active = name if name in ("direction_control", "direction_display") else None
            continue
        expected_indent = 2 if active == "joint_map" else 4
        match = entry.match(text) if active is not None and indent == expected_indent else None
        if match:
            sections[active][match.group(1)] = int(match.group(2))
    if any(not values for values in sections.values()):
        raise ValueError(f"{path}: required servo mapping section is empty")
    return sections["joint_map"], sections["direction_control"], sections["direction_display"]


def verify_mapping(walk_path: Path, recovery_path: Path, servo_map_path: Path) -> list[tuple]:
    walk = _load_contract(walk_path)
    recovery = _load_contract(recovery_path)
    if walk.get("role") != "walk" or recovery.get("role") != "recovery":
        raise ValueError("contracts must have walk and recovery roles")

    names = walk["joint_names"]
    if recovery["joint_names"] != names:
        raise ValueError("WALK and RECOVERY action orders differ")

    joint_map, control, display = _load_servo_sections(servo_map_path)

    expected, configured = set(names), set(joint_map)
    if expected != configured:
        missing = sorted(expected - configured)
        extra = sorted(configured - expected)
        raise ValueError(f"servo_map joint mismatch; missing={missing}, extra={extra}")
    ids = [int(joint_map[name]) for name in names]
    if len(set(ids)) != 20 or set(ids) != set(range(1, 21)):
        raise ValueError(f"servo IDs must be unique 1..20; got {sorted(ids)}")
    if set(control) != configured or set(display) != configured:
        raise ValueError("direction_control/direction_display must cover exactly the mapped joints")
    if any(control[name] not in (-1, 1) or display[name] not in (-1, 1) for name in names):
        raise ValueError("all joint direction values must be +1 or -1")

    return [
        (index, name, int(joint_map[name]), int(control[name]), int(display[name]))
        for index, name in enumerate(names)
    ]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Compare simulator-exported action order with the robot name-to-servo map."
    )
    parser.add_argument(
        "--walk-contract",
        type=Path,
        default=Path("/home/robo04/sim2real_ws/models/tensorrt/RL_walk.json"),
    )
    parser.add_argument(
        "--recovery-contract",
        type=Path,
        default=Path("/home/robo04/sim2real_ws/models/tensorrt/RL_fall_after_walk.json"),
    )
    parser.add_argument(
        "--servo-map",
        type=Path,
        default=Path(
            "/home/robo04/sim2real_ws/src/humanoid_serial_bridge/config/servo_map.yaml"
        ),
    )
    args = parser.parse_args(argv)

    try:
        rows = verify_mapping(args.walk_contract, args.recovery_contract, args.servo_map)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"MAPPING ERROR: {exc}", file=sys.stderr)
        return 1

    print("action  joint_name                      motor_id  cmd_sign  feedback_sign")
    for index, name, motor_id, control, display in rows:
        print(f"{index:>6}  {name:<30} {motor_id:>8} {control:>9} {display:>14}")
    print("MAPPING OK: contracts share one 20-joint order and every name maps to one servo ID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
