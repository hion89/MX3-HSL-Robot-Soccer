"""Build both XM540 engines locally on Jetson, then verify outputs and timing."""

import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import time

import numpy as np

from .xm540_policy import CheckpointActor, load_contract
from .xm540_tensorrt import TensorRTActor, build_engine


def verify_engine(reference, runtime, size, precision):
    rng = np.random.default_rng(42)
    probes = [np.zeros(size, dtype=np.float32)]
    probes.extend(rng.normal(0, scale, size).astype(np.float32)
                  for scale in (0.1, 1.0, 3.0) for _ in range(32))
    atol, rtol = (1e-4, 1e-4) if precision == "fp32" else (5e-3, 2e-3)
    maximum = 0.0
    for observation in probes:
        actual, expected = runtime(observation), reference(observation)
        if not np.isfinite(actual).all():
            raise ValueError("Non-finite engine output")
        np.testing.assert_allclose(actual, expected, atol=atol, rtol=rtol)
        maximum = max(maximum, float(np.max(np.abs(actual - expected))))
    for _ in range(20):
        runtime(probes[0])
    durations = []
    for _ in range(200):
        start = time.perf_counter()
        runtime(probes[0])
        durations.append((time.perf_counter() - start) * 1000)
    return {"engine_parity_samples": len(probes), "engine_parity_max_error": maximum,
            "engine_parity_atol": atol, "engine_parity_rtol": rtol,
            "inference_ms_p50": float(np.percentile(durations, 50)),
            "inference_ms_p99": float(np.percentile(durations, 99)),
            "inference_ms_max": max(durations)}


def build_one(model_dir, name, size, precision):
    import torch
    import tensorrt as trt

    checkpoint = model_dir / (name + ".pt")
    source_json = model_dir / (name + ".json")
    destination = model_dir / "tensorrt"
    destination.mkdir(parents=True, exist_ok=True)
    contract = load_contract(source_json, checkpoint) if source_json.exists() else None
    if contract is not None and (contract["observation_size"] != size or contract["activation"] != "elu"):
        raise ValueError("Training contract differs from the supported actor")
    actor = CheckpointActor(checkpoint, size)
    torch.set_num_threads(1)
    with tempfile.TemporaryDirectory(dir=destination) as temp:
        candidate = Path(temp) / (name + ".engine")
        build_engine(actor, candidate, precision)
        runtime = TensorRTActor(candidate, size)
        report = verify_engine(actor, runtime, size, precision)
        del runtime
        report.update({
            "checkpoint_sha256": hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
            "engine_sha256": hashlib.sha256(candidate.read_bytes()).hexdigest(),
            "engine_precision": precision, "tensorrt_version": trt.__version__,
            "engine_verified": True,
            "cuda_version": torch.version.cuda, "gpu_name": torch.cuda.get_device_name(0),
            "observation_size": size, "deployment_contract_available": contract is not None,
        })
        # Only publish a candidate that passed numerical validation.
        candidate.replace(destination / (name + ".engine"))
    report_path = destination / (name + ".build.json")
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if contract is not None:
        contract.update(report)
        (destination / (name + ".json")).write_text(json.dumps(contract, indent=2) + "\n", encoding="utf-8")
    print(f"{name}: {json.dumps(report, indent=2)}", flush=True)
    if contract is None:
        print("Engine built, but not ready for robot control: training contract JSON is missing. "
              "Add the original contract beside the .pt and rerun this command. "
              "The .build.json report is NOT a deployment contract.", flush=True)
    if report["inference_ms_max"] >= 20:
        print("WARNING: standalone inference exceeded 20 ms; investigate before robot control.", flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--models", type=Path, default=Path("/home/robo04/sim2real_ws/models"))
    parser.add_argument("--precision", choices=("fp32", "fp16"), default="fp32")
    args = parser.parse_args()
    for name, size in (("RL_walk", 355), ("RL_fall_after_walk", 345)):
        build_one(args.models.resolve(), name, size, args.precision)


if __name__ == "__main__":
    main()
