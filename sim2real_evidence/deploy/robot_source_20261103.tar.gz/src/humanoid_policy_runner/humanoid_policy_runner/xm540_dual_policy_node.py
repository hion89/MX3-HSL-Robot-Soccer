"""Explicitly started, single-owner WALK/RECOVERY policy runner for XM540."""

import json
import math
import time

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data, QoSProfile, DurabilityPolicy, ReliabilityPolicy
from rcl_interfaces.msg import SetParametersResult
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Imu, JointState
from std_msgs.msg import String, Bool
from std_srvs.srv import Trigger

from .xm540_policy import (
    CheckpointActor, GoalSafetyLimiter, OnnxActor, DualPolicy, SwitchConfig,
    load_contract, projected_gravity,
)


SWITCH_PARAMS = {
    "enter_tilt_deg": "enter_deg", "exit_tilt_deg": "exit_deg",
    "settle_seconds": "settle_s", "exit_angular_speed": "exit_angular_speed",
    "exit_pose_error": "exit_pose_error", "max_recovery_seconds": "max_recovery_s",
    "stop_tilt_deg": "stop_deg",
}


class XM540DualPolicyNode(Node):
    def __init__(self):
        super().__init__("xm540_dual_policy")
        defaults = {
            "inference_backend": "onnx",
            "walk_checkpoint": "", "recovery_checkpoint": "",
            "walk_contract": "", "recovery_contract": "",
            "publish_joint_goals": False, "sensor_timeout": 0.2, "command_timeout": 0.5,
            "enter_tilt_deg": 20.0, "exit_tilt_deg": 10.0, "settle_seconds": 0.5,
            "exit_angular_speed": 0.5, "exit_pose_error": 0.35,
            "max_recovery_seconds": 8.0, "stop_tilt_deg": 55.0,
            "startup_blend_seconds": 2.0, "max_goal_step_rad": 0.04,
            "recovery_max_goal_step_rad": 0.08,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        p = lambda name: self.get_parameter(name).value
        self.live = p("publish_joint_goals")
        self.sensor_timeout = float(p("sensor_timeout"))
        self.command_timeout = float(p("command_timeout"))
        if not all(math.isfinite(v) and v > 0 for v in (self.sensor_timeout, self.command_timeout)):
            raise ValueError("Timeouts must be positive and finite")
        contracts, actors = [], []
        backend = p("inference_backend")
        if backend not in ("onnx", "pytorch", "tensorrt"):
            raise ValueError("inference_backend must be onnx, pytorch or tensorrt")
        if backend in ("pytorch", "tensorrt"):
            import torch
            torch.set_num_threads(1)
        for role in ("walk", "recovery"):
            contract = load_contract(p(f"{role}_contract"), p(f"{role}_checkpoint"), backend)
            if contract["role"] != role:
                raise ValueError(f"Wrong contract role: {role}")
            contracts.append(contract)
            if backend == "onnx":
                actors.append(OnnxActor(p(f"{role}_checkpoint"), contract["observation_size"]))
            elif backend == "tensorrt":
                import tensorrt as trt
                from .xm540_tensorrt import TensorRTActor
                if contract.get("tensorrt_version") != trt.__version__:
                    raise ValueError("TensorRT version changed; rebuild the engines on this robot")
                actors.append(TensorRTActor(p(f"{role}_checkpoint"), contract["observation_size"]))
            else:
                actors.append(CheckpointActor(p(f"{role}_checkpoint"), contract["observation_size"], contract["activation"]))
        for actor, contract in zip(actors, contracts):
            actor(np.zeros(contract["observation_size"], dtype=np.float32))
        self.policy = DualPolicy(*contracts, *actors, SwitchConfig(**{v: float(p(k)) for k, v in SWITCH_PARAMS.items()}))
        self.names = contracts[0]["joint_names"]
        self.command_limits = np.asarray(contracts[0]["command_limits"])
        self.dt = contracts[0]["step_dt"]
        self.goal_limiter = GoalSafetyLimiter(
            p("startup_blend_seconds"), p("max_goal_step_rad"))
        self.recovery_max_goal_step_rad = float(p("recovery_max_goal_step_rad"))
        if not math.isfinite(self.recovery_max_goal_step_rad) or self.recovery_max_goal_step_rad <= 0:
            raise ValueError("recovery_max_goal_step_rad must be positive and finite")
        self.imu = self.joints = None
        self.command = np.zeros(3)
        self.command_at = -math.inf
        self.behavior_idle_at = -math.inf
        self.torque_enabled = False
        self.stop_pressed = False
        self.running = False
        self.last_tick = None
        self.error = ""
        self.last_mode = "IDLE"
        self.preview = self.create_publisher(JointState, "~/preview_joint_goals", 10)
        self.goals = self.create_publisher(JointState, "/joint_goals", 10) if self.live else None
        self.state = self.create_publisher(String, "~/state", 10)
        self.create_subscription(Imu, "/imu/data", self.on_imu, qos_profile_sensor_data)
        self.create_subscription(JointState, "/joint_states", self.on_joints, qos_profile_sensor_data)
        self.create_subscription(Twist, "/cmd_vel", self.on_command, 10)
        self.create_subscription(String, "/u2d2/behavior_status", self.on_behavior, 10)
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                             reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(Bool, "/u2d2/torque_enabled", self.on_torque, latched)
        self.create_subscription(Bool, "/buttons/stop_pressed", self.on_stop_button, latched)
        self.create_service(Trigger, "~/start", self.start)
        self.create_service(Trigger, "~/stop", self.stop)
        self.add_on_set_parameters_callback(self.update_parameters)
        self.create_timer(self.dt, self.tick)
        self.create_timer(0.2, self.publish_state)
        self.get_logger().info(f"Loaded WALK={contracts[0]['observation_size']}, RECOVERY={contracts[1]['observation_size']}; "
                               f"{'motor goal output enabled' if self.live else 'preview only'}; waiting for ~/start")

    def update_parameters(self, parameters):
        values = vars(self.policy.switch.config).copy()
        try:
            for param in parameters:
                if param.name not in SWITCH_PARAMS:
                    raise ValueError(f"{param.name} requires node restart")
                values[SWITCH_PARAMS[param.name]] = float(param.value)
            self.policy.switch.config = SwitchConfig(**values)
            return SetParametersResult(successful=True)
        except (ValueError, TypeError) as exc:
            return SetParametersResult(successful=False, reason=str(exc))

    def stamp_valid(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        age = self.get_clock().now().nanoseconds * 1e-9 - stamp
        return -0.05 <= age <= self.sensor_timeout

    def on_imu(self, msg):
        try:
            if not self.stamp_valid(msg) or msg.orientation_covariance[0] == -1 or msg.angular_velocity_covariance[0] == -1:
                raise ValueError("IMU timestamp/orientation unavailable")
            q, w = msg.orientation, msg.angular_velocity
            gravity = projected_gravity([q.x, q.y, q.z, q.w])
            gyro = np.array([w.x, w.y, w.z])
            if not np.isfinite(gyro).all():
                raise ValueError("Invalid IMU gyro")
            self.imu = (time.monotonic(), gyro, gravity)
        except ValueError:
            self.imu = None

    def on_joints(self, msg):
        try:
            if not self.stamp_valid(msg) or len(set(msg.name)) != len(msg.name):
                raise ValueError("Invalid joint timestamp or duplicate names")
            indices = {name: i for i, name in enumerate(msg.name)}
            pos = np.array([msg.position[indices[n]] for n in self.names])
            vel = np.array([msg.velocity[indices[n]] for n in self.names])
            if not np.isfinite(pos).all() or not np.isfinite(vel).all():
                raise ValueError("Invalid joint feedback")
            self.joints = (time.monotonic(), pos, vel)
        except (KeyError, IndexError, ValueError):
            self.joints = None

    def on_command(self, msg):
        command = np.array([msg.linear.x, msg.linear.y, msg.angular.z])
        if np.isfinite(command).all():
            self.command = np.clip(command, self.command_limits[:, 0], self.command_limits[:, 1])
            self.command_at = time.monotonic()
        else:
            self.command = np.zeros(3)

    def on_behavior(self, msg):
        try:
            idle = json.loads(msg.data)["active"] is False
        except (ValueError, KeyError, TypeError):
            idle = False
        self.behavior_idle_at = time.monotonic() if idle else -math.inf
        if self.live and not idle and self.running:
            self.fail("Hardware behavior took control")

    def on_torque(self, msg):
        self.torque_enabled = msg.data
        if self.live and not msg.data and self.running:
            self.fail("Motor torque disabled; explicit restart required")

    def on_stop_button(self, msg):
        self.stop_pressed = msg.data
        if self.live and msg.data and self.running:
            self.fail("Stop button pressed; explicit restart required")

    def ready(self, now):
        if self.imu is None or self.joints is None:
            raise ValueError("Waiting for valid IMU and all 20 joint positions/velocities")
        if max(now - self.imu[0], now - self.joints[0]) > self.sensor_timeout:
            raise ValueError("Sensor timeout")
        if self.live:
            if not self.torque_enabled or self.stop_pressed:
                raise ValueError("Motor torque is off/unknown or stop button is pressed")
            if now - self.behavior_idle_at > self.sensor_timeout:
                raise ValueError("Hardware behavior status is active or stale")
            if self.count_publishers("/joint_goals") != 1:
                raise ValueError("Another /joint_goals publisher exists; use this runner alone")

    def start(self, request, response):
        try:
            if self.running:
                raise ValueError("Already running")
            self.ready(time.monotonic())
            if self.live:
                tilt = math.degrees(math.acos(float(np.clip(-self.imu[2][2], -1, 1))))
                if tilt > self.policy.switch.config.exit_deg:
                    raise ValueError(
                        f"Start requires an upright supported robot: "
                        f"tilt={tilt:.1f}deg > {self.policy.switch.config.exit_deg:.1f}deg"
                    )
                # Neck pose is excluded from the recovery handoff check because
                # robot_init deliberately points the camera down while both RL
                # policies use a neutral neck action.  Apply the same rule at
                # startup and use the configured handoff threshold rather than
                # a second hard-coded value.
                errors = np.abs(self.joints[1] - self.policy.default)
                pose_ids = self.policy.pose_ids
                worst_id = max(pose_ids, key=lambda index: errors[index])
                worst_error = float(errors[worst_id])
                allowed = self.policy.switch.config.exit_pose_error
                if worst_error > allowed:
                    raise ValueError(
                        "Start requires joints near the exported default pose: "
                        f"{self.names[worst_id]} error={worst_error:.3f}rad > {allowed:.3f}rad"
                    )
            self.policy.reset()
            self.goal_limiter.reset(self.joints[1], time.monotonic())
            self.error, self.last_tick = "", None
            self.running = True
            response.success, response.message = True, "Started"
        except ValueError as exc:
            response.success, response.message = False, str(exc)
        return response

    def stop(self, request, response):
        self.running = False
        self.last_mode = "IDLE"
        response.success, response.message = True, "Goal publishing stopped; motor torque is unchanged"
        return response

    def fail(self, message):
        self.running = False
        self.error, self.last_mode = message, "FAULT"
        self.get_logger().error(message)

    def tick(self):
        if not self.running:
            return
        now = time.monotonic()
        try:
            self.ready(now)
            if self.last_tick is not None and now - self.last_tick > 3 * self.dt:
                raise RuntimeError("Policy timer missed its control deadline")
            self.last_tick = now
            command = self.command if now - self.command_at <= self.command_timeout else np.zeros(3)
            mode, targets, _ = self.policy.step(now, *self.joints[1:], *self.imu[1:], command)
            step_limit = self.recovery_max_goal_step_rad if mode == "RECOVERY" else None
            targets = self.goal_limiter.apply(targets, now, max_step_rad=step_limit)
            if time.monotonic() - now > self.dt:
                raise RuntimeError("Inference exceeded the policy timestep")
            if mode != self.last_mode:
                self.get_logger().info(f"{self.last_mode} -> {mode}")
            self.last_mode = mode
            msg = JointState()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.name, msg.position = self.names, targets.tolist()
            self.preview.publish(msg)
            if self.goals is not None:
                self.goals.publish(msg)
        except Exception as exc:
            self.fail(str(exc))

    def publish_state(self):
        msg = String()
        msg.data = json.dumps({"mode": self.last_mode, "running": self.running,
                               "publish_joint_goals": self.live, "error": self.error})
        self.state.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = XM540DualPolicyNode()
        rclpy.spin(node)
    finally:
        if node is not None:
            node.destroy_node()
        rclpy.shutdown()
