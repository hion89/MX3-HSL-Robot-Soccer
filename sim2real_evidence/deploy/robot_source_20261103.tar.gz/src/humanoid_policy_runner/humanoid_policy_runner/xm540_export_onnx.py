"""Export the supported XM540 ELU actor on a training/development PC."""

import argparse
import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np

from .xm540_policy import CheckpointActor, OnnxActor, load_contract


def export_actor(checkpoint, output, observation_size, contract_path=None, output_contract=None):
    """Create Gemm/Elu opset-11, IR-6 ONNX and verify against the checkpoint.

    Build the known MLP explicitly to avoid new exporter ops unsupported by
    older Jetson runtimes. Never infer joint metadata from network weights.
    """
    import onnx
    from onnx import helper, numpy_helper, TensorProto

    contract = None
    if contract_path is not None:
        contract = load_contract(contract_path, checkpoint)
        if contract["observation_size"] != observation_size or contract["activation"] != "elu":
            raise ValueError("Contract does not match requested actor")
        if output_contract is None:
            raise ValueError("output_contract is required with contract_path")
    actor = CheckpointActor(checkpoint, observation_size)
    nodes, initializers = [], []
    value = "observation"
    for index in (0, 2, 4, 6):
        layer = actor.model[index]
        w, b = f"weight_{index}", f"bias_{index}"
        initializers.extend([
            numpy_helper.from_array(layer.weight.detach().numpy(), w),
            numpy_helper.from_array(layer.bias.detach().numpy(), b),
        ])
        linear = "action" if index == 6 else f"linear_{index}"
        nodes.append(helper.make_node("Gemm", [value, w, b], [linear], transB=1))
        value = linear
        if index != 6:
            value = f"elu_{index}"
            nodes.append(helper.make_node("Elu", [linear], [value], alpha=1.0))
    graph = helper.make_graph(nodes, "xm540_actor",
                              [helper.make_tensor_value_info("observation", TensorProto.FLOAT, [1, observation_size])],
                              [helper.make_tensor_value_info("action", TensorProto.FLOAT, [1, 20])], initializers)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 11)])
    model.ir_version = 6
    onnx.checker.check_model(model)
    output = Path(output)
    if output.resolve() == Path(checkpoint).resolve():
        raise ValueError("ONNX output must not overwrite the training checkpoint")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temp:
        candidate = Path(temp) / "actor.onnx"
        onnx.save(model, candidate)
        runtime = OnnxActor(candidate, observation_size)
        rng = np.random.default_rng(42)
        probes = [np.zeros(observation_size, dtype=np.float32)]
        probes.extend(rng.normal(0, scale, observation_size).astype(np.float32)
                      for scale in (0.1, 1.0, 3.0) for _ in range(16))
        error = 0.0
        for observation in probes:
            reference, actual = actor(observation), runtime(observation)
            np.testing.assert_allclose(actual, reference, atol=2e-5, rtol=2e-5)
            error = max(error, float(np.max(np.abs(actual - reference))))
        candidate.replace(output)
    report = {"onnx_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
              "onnx_opset": 11, "onnx_ir_version": 6, "onnx_parity_max_error": error,
              "onnx_parity_samples": len(probes)}
    if contract is not None:
        contract.update(report)
        destination = Path(output_contract)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(contract, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--observation-size", required=True, type=int, choices=[345, 355])
    parser.add_argument("--contract")
    parser.add_argument("--output-contract")
    args = parser.parse_args()
    print(json.dumps(export_actor(args.checkpoint, args.output, args.observation_size,
                                 args.contract, args.output_contract), indent=2))


if __name__ == "__main__":
    main()
