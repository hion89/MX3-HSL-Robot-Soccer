"""TensorRT 10.x fixed-shape actor using the installed PyTorch CUDA allocator.

No ONNX, ONNX Runtime or PyCUDA dependency. Use on the target Jetson.
"""

from pathlib import Path

import numpy as np


def require_tensorrt10(trt):
    if trt.__version__.split(".")[0] != "10":
        raise RuntimeError("This adapter targets TensorRT 10.x (robot: 10.3.0)")


class TensorRTActor:
    """Single-threaded batch-one inference with persistent CUDA buffers."""

    def __init__(self, path, observation_size):
        import tensorrt as trt
        import torch

        require_tensorrt10(trt)
        if not torch.cuda.is_available():
            raise RuntimeError("The installed NVIDIA PyTorch cannot access CUDA")
        torch.cuda.set_device(0)
        torch.cuda.init()
        self.torch = torch
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
        self.engine = self.runtime.deserialize_cuda_engine(Path(path).read_bytes())
        if self.engine is None:
            raise RuntimeError("Cannot load engine: rebuild on this Jetson with its TensorRT version")
        names = [self.engine.get_tensor_name(i) for i in range(self.engine.num_io_tensors)]
        inputs = [n for n in names if self.engine.get_tensor_mode(n) == trt.TensorIOMode.INPUT]
        outputs = [n for n in names if self.engine.get_tensor_mode(n) == trt.TensorIOMode.OUTPUT]
        if len(inputs) != 1 or len(outputs) != 1:
            raise ValueError("Expected one observation input and one action output")
        for name, shape in ((inputs[0], (1, observation_size)), (outputs[0], (1, 20))):
            if tuple(self.engine.get_tensor_shape(name)) != shape:
                raise ValueError("Engine shape differs from policy contract")
            if self.engine.get_tensor_dtype(name) != trt.float32:
                raise ValueError("Engine I/O must be FP32, including FP16 internal builds")
            if self.engine.get_tensor_location(name) != trt.TensorLocation.DEVICE:
                raise ValueError("Expected CUDA device tensors")
        self.context = self.engine.create_execution_context()
        if self.context is None:
            raise RuntimeError("Cannot create TensorRT execution context")
        self.observation_size = observation_size
        self.stream = torch.cuda.Stream(device=0)
        with torch.cuda.stream(self.stream):
            self.input = torch.empty((1, observation_size), dtype=torch.float32, device="cuda:0")
            self.output = torch.empty((1, 20), dtype=torch.float32, device="cuda:0")
        self.host_input = torch.empty((1, observation_size), dtype=torch.float32, pin_memory=True)
        self.host_output = torch.empty((1, 20), dtype=torch.float32, pin_memory=True)
        if not self.context.set_tensor_address(inputs[0], self.input.data_ptr()):
            raise RuntimeError("Failed to bind observation buffer")
        if not self.context.set_tensor_address(outputs[0], self.output.data_ptr()):
            raise RuntimeError("Failed to bind action buffer")

    def __call__(self, observation):
        observation = np.asarray(observation, dtype=np.float32)
        if observation.shape != (self.observation_size,) or not np.isfinite(observation).all():
            raise ValueError("Invalid TensorRT observation")
        np.copyto(self.host_input.numpy()[0], observation)
        # H2D, TensorRT execution, D2H share the same non-default CUDA stream.
        # Synchronize before reading CPU output or reusing either buffer.
        with self.torch.cuda.stream(self.stream):
            self.input.copy_(self.host_input, non_blocking=True)
            if not self.context.execute_async_v3(stream_handle=self.stream.cuda_stream):
                self.stream.synchronize()
                raise RuntimeError("TensorRT inference failed")
            self.host_output.copy_(self.output, non_blocking=True)
        self.stream.synchronize()
        result = self.host_output.numpy()[0].copy()
        if not np.isfinite(result).all():
            raise ValueError("Non-finite TensorRT action")
        return result


def build_engine(actor, output, precision="fp32"):
    """Directly populate the supported ELU MLP from validated checkpoint weights."""
    import tensorrt as trt

    require_tensorrt10(trt)
    if precision not in ("fp32", "fp16"):
        raise ValueError("precision must be fp32 or fp16")
    if not actor.torch.cuda.is_available():
        raise RuntimeError("Build this engine on the target Jetson with CUDA available")
    actor.torch.cuda.set_device(0)
    logger = trt.Logger(trt.Logger.WARNING)
    builder = trt.Builder(logger)
    network = builder.create_network(0)
    config = builder.create_builder_config()
    config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 256 * 1024 * 1024)
    config.clear_flag(trt.BuilderFlag.TF32)
    if precision == "fp16":
        if not builder.platform_has_fast_fp16:
            raise RuntimeError("Device does not report fast FP16 support")
        config.set_flag(trt.BuilderFlag.FP16)
    value = network.add_input("observation", trt.float32, (1, actor.observation_size))
    weights = []  # Keep host arrays alive until the builder has consumed them.
    for index in (0, 2, 4, 6):
        layer = actor.model[index]
        weight = np.ascontiguousarray(layer.weight.detach().cpu().numpy())
        bias = np.ascontiguousarray(layer.bias.detach().cpu().numpy().reshape(1, -1))
        weights.extend((weight, bias))
        w = network.add_constant(weight.shape, weight).get_output(0)
        b = network.add_constant(bias.shape, bias).get_output(0)
        product = network.add_matrix_multiply(value, trt.MatrixOperation.NONE,
                                              w, trt.MatrixOperation.TRANSPOSE).get_output(0)
        value = network.add_elementwise(product, b, trt.ElementWiseOperation.SUM).get_output(0)
        if index != 6:
            activation = network.add_activation(value, trt.ActivationType.ELU)
            activation.alpha = 1.0
            value = activation.get_output(0)
    value.name = "action"
    network.mark_output(value)
    # TensorRT only honors setType for network I/O tensors.  Mark the tensor
    # first so TensorRT 10 does not emit the misleading "non I/O tensor"
    # warning even though the serialized engine output is FP32.
    value.dtype = trt.float32
    plan = builder.build_serialized_network(network, config)
    if plan is None:
        raise RuntimeError("TensorRT engine build failed")
    Path(output).write_bytes(bytes(plan))
