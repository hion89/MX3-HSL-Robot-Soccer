"""ROS-independent XM540 checkpoint inference and walking/recovery handoff."""

from collections import deque
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path

import numpy as np


def load_contract(path, checkpoint, model_format="pytorch"):
    """Require a contract exported from the resolved Isaac Lab environment."""
    contract = json.loads(Path(path).read_text(encoding="utf-8"))
    if contract["schema_version"] != 1:
        raise ValueError("Unsupported XM540 contract version")
    digest = hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest()
    if model_format == "onnx":
        expected_hash = contract.get("onnx_sha256")
    elif model_format == "tensorrt":
        expected_hash = contract.get("engine_sha256")
        if contract.get("engine_verified") is not True:
            raise ValueError("Engine has not passed checkpoint output validation")
    elif model_format == "pytorch":
        expected_hash = contract["checkpoint_sha256"]
    else:
        raise ValueError("Unsupported model format")
    if expected_hash != digest:
        raise ValueError("Contract belongs to a different checkpoint or exported model")
    names = contract["joint_names"]
    if len(names) != 20 or len(set(names)) != 20:
        raise ValueError("Expected 20 unique XM540 joints in resolved simulator order")
    if contract["history_layout"] != "term_major_oldest_first":
        raise ValueError("Unsupported observation history layout")
    for key in ("default_joint_pos", "action_scale", "lower_limits", "upper_limits"):
        value = np.asarray(contract[key], dtype=np.float32)
        if value.shape != (20,) or not np.isfinite(value).all():
            raise ValueError(f"Invalid {key}")
    if not np.all(np.asarray(contract["lower_limits"]) < contract["upper_limits"]):
        raise ValueError("Invalid joint limits")
    if not 0 < contract["step_dt"] <= 0.1:
        raise ValueError("Invalid policy timestep")
    expected = [("base_ang_vel", 3), ("projected_gravity", 3), ("velocity_commands", 3),
                ("joint_pos_rel", 20), ("joint_vel_rel", 20), ("last_action", 20)]
    if contract["role"] == "walk":
        expected.append(("gait_phase", 2))
    elif contract["role"] != "recovery":
        raise ValueError("Invalid policy role")
    if [(t["name"], t["size"]) for t in contract["terms"]] != expected:
        raise ValueError("Unexpected policy observation terms or ordering")
    if any(t["history_length"] != 5 for t in contract["terms"]):
        raise ValueError("Expected five-step observation histories")
    if contract["observation_size"] != sum(size * 5 for _, size in expected):
        raise ValueError("Invalid observation size")
    if not math.isfinite(contract["gait_period"]) or contract["gait_period"] <= 0:
        raise ValueError("Invalid gait period")
    if not math.isfinite(contract["observation_parity_max_error"]) or contract["observation_parity_max_error"] > 1e-3:
        raise ValueError("Contract has not passed simulator observation parity")
    limits = np.asarray(contract["command_limits"])
    if limits.shape != (3, 2) or not np.isfinite(limits).all() or np.any(limits[:, 0] > limits[:, 1]):
        raise ValueError("Invalid command limits")
    return contract


class CheckpointActor:
    """Load the deterministic ELU MLP from an RSL-RL checkpoint, on CPU."""

    def __init__(self, path, observation_size, activation="elu"):
        import torch

        if activation != "elu":
            raise ValueError("Only the XM540 ELU actor is supported")
        saved = torch.load(path, map_location="cpu", weights_only=True)
        state = saved["model_state_dict"]
        if any("normalizer." in key for key in state):
            raise ValueError("Normalized checkpoints require a normalizer-aware exporter")
        layers = []
        expected = set()
        previous = observation_size
        for index, width in zip((0, 2, 4, 6), (512, 256, 128, 20)):
            weight, bias = f"actor.{index}.weight", f"actor.{index}.bias"
            expected.update((weight, bias))
            if tuple(state[weight].shape) != (width, previous):
                raise ValueError(f"Unexpected actor layer shape: {weight}")
            layers.append(torch.nn.Linear(previous, width))
            if index != 6:
                layers.append(torch.nn.ELU())
            previous = width
        if {k for k in state if k.startswith("actor.")} != expected:
            raise ValueError("Unsupported actor architecture")
        self.model = torch.nn.Sequential(*layers).eval()
        self.model.load_state_dict({k.removeprefix("actor."): state[k] for k in expected})
        self.observation_size = observation_size
        self.torch = torch

    def __call__(self, observation):
        observation = np.asarray(observation, dtype=np.float32)
        if observation.shape != (self.observation_size,) or not np.isfinite(observation).all():
            raise ValueError("Invalid policy observation")
        with self.torch.inference_mode():
            result = self.model(self.torch.from_numpy(observation).unsqueeze(0))[0].numpy()
        if result.shape != (20,) or not np.isfinite(result).all():
            raise ValueError("Invalid policy action")
        return result


class OnnxActor:
    """Fixed-batch FP32 ONNX actor; no PyTorch dependency on the robot."""

    def __init__(self, path, observation_size):
        import onnxruntime as ort

        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        options.inter_op_num_threads = 1
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        self.session = ort.InferenceSession(str(path), sess_options=options,
                                           providers=["CPUExecutionProvider"])
        inputs, outputs = self.session.get_inputs(), self.session.get_outputs()
        if len(inputs) != 1 or len(outputs) != 1:
            raise ValueError("Expected a single observation input and action output")
        if inputs[0].shape != [1, observation_size] or outputs[0].shape != [1, 20]:
            raise ValueError("ONNX observation/action dimensions do not match contract")
        if inputs[0].type != "tensor(float)" or outputs[0].type != "tensor(float)":
            raise ValueError("Expected FP32 ONNX inputs and outputs")
        self.input_name, self.output_name = inputs[0].name, outputs[0].name
        self.observation_size = observation_size

    def __call__(self, observation):
        observation = np.asarray(observation, dtype=np.float32)
        if observation.shape != (self.observation_size,) or not np.isfinite(observation).all():
            raise ValueError("Invalid policy observation")
        result = self.session.run([self.output_name], {self.input_name: observation[None, :]})[0]
        if result.shape != (1, 20) or not np.isfinite(result).all():
            raise ValueError("Invalid ONNX action")
        return result[0]


class ObservationHistory:
    """Isaac Lab stores each term's history before concatenating the terms."""

    def __init__(self, contract):
        self.contract = contract
        self.buffers = {t["name"]: deque(maxlen=t["history_length"]) for t in contract["terms"]}

    def reset(self):
        for buffer in self.buffers.values():
            buffer.clear()

    def append(self, values):
        chunks = []
        for term in self.contract["terms"]:
            value = np.asarray(values[term["name"]], dtype=np.float32)
            if value.shape != (term["size"],) or not np.isfinite(value).all():
                raise ValueError(f"Invalid observation term {term['name']}")
            if term["clip"] is not None:
                value = np.clip(value, *term["clip"])
            value = value * np.asarray(term["scale"], dtype=np.float32)
            buffer = self.buffers[term["name"]]
            if not buffer:
                buffer.extend(value.copy() for _ in range(buffer.maxlen))
            else:
                buffer.append(value.copy())
            chunks.append(np.concatenate(tuple(buffer)))
        return np.concatenate(chunks).astype(np.float32)


def projected_gravity(quaternion_xyzw):
    q = np.asarray(quaternion_xyzw, dtype=np.float64)
    if q.shape != (4,) or not np.isfinite(q).all() or np.linalg.norm(q) < 1e-6:
        raise ValueError("Invalid IMU quaternion")
    x, y, z, w = q / np.linalg.norm(q)
    return np.array([2 * (w*y - x*z), -2 * (w*x + y*z), -(1 - 2*(x*x + y*y))])


@dataclass
class SwitchConfig:
    enter_deg: float = 30.0
    exit_deg: float = 12.0
    settle_s: float = 0.5
    exit_angular_speed: float = 0.5
    exit_pose_error: float = 0.35
    max_recovery_s: float = 6.0
    stop_deg: float = 75.0

    def __post_init__(self):
        if not all(math.isfinite(v) for v in vars(self).values()):
            raise ValueError("Switch parameters must be finite")
        if not 0 < self.exit_deg < self.enter_deg < self.stop_deg < 180:
            raise ValueError("Require 0 < exit < enter < stop < 180 degrees")
        if min(self.settle_s, self.exit_angular_speed, self.exit_pose_error) <= 0:
            raise ValueError("Recovery settling parameters must be positive")
        if self.max_recovery_s <= self.settle_s:
            raise ValueError("Recovery timeout must exceed settling time")


class PolicySwitch:
    """Immediate recovery entry; sustained upright stability before walking."""

    def __init__(self, config):
        self.config = config
        self.reset()

    def reset(self):
        self.mode = "WALK"
        self.entered_at = None
        self.stable_since = None

    def update(self, now, tilt_deg, angular_speed, pose_error):
        c = self.config
        if not all(math.isfinite(v) for v in (now, tilt_deg, angular_speed, pose_error)):
            raise ValueError("Non-finite switching state")
        if self.mode == "FAULT":
            return self.mode
        if tilt_deg >= c.stop_deg:
            self.mode = "FAULT"
        elif self.mode == "WALK" and tilt_deg >= c.enter_deg:
            self.mode, self.entered_at = "RECOVERY", now
            self.stable_since = None
        elif self.mode == "RECOVERY":
            if now - self.entered_at >= c.max_recovery_s:
                self.mode = "FAULT"
            elif tilt_deg <= c.exit_deg and angular_speed <= c.exit_angular_speed and pose_error <= c.exit_pose_error:
                if self.stable_since is None:
                    self.stable_since = now
                if now - self.stable_since >= c.settle_s:
                    self.mode = "WALK"
            else:
                self.stable_since = None
        return self.mode


class GoalSafetyLimiter:
    """Blend from the measured start pose and reject abrupt target jumps."""

    def __init__(self, blend_seconds=2.0, max_step_rad=0.04):
        self.blend_seconds = float(blend_seconds)
        self.max_step_rad = float(max_step_rad)
        if not (math.isfinite(self.blend_seconds) and self.blend_seconds > 0):
            raise ValueError("startup_blend_seconds must be positive and finite")
        if not (math.isfinite(self.max_step_rad) and self.max_step_rad > 0):
            raise ValueError("max_goal_step_rad must be positive and finite")
        self.started_at = None
        self.start_pose = None
        self.last_target = None

    def reset(self, position, now):
        position = np.asarray(position, dtype=np.float32)
        if position.shape != (20,) or not np.isfinite(position).all():
            raise ValueError("Expected 20 finite start joint positions")
        if not math.isfinite(now):
            raise ValueError("Invalid safety limiter start time")
        self.started_at = float(now)
        self.start_pose = position.copy()
        self.last_target = position.copy()

    def apply(self, target, now, max_step_rad=None):
        if self.started_at is None:
            raise ValueError("Goal safety limiter has not been reset")
        target = np.asarray(target, dtype=np.float32)
        if target.shape != (20,) or not np.isfinite(target).all() or not math.isfinite(now):
            raise ValueError("Invalid joint target")
        step_limit = self.max_step_rad if max_step_rad is None else float(max_step_rad)
        if not (math.isfinite(step_limit) and step_limit > 0):
            raise ValueError("max_step_rad override must be positive and finite")
        alpha = float(np.clip((now - self.started_at) / self.blend_seconds, 0.0, 1.0))
        blended = self.start_pose + alpha * (target - self.start_pose)
        delta = np.clip(blended - self.last_target, -step_limit, step_limit)
        self.last_target = (self.last_target + delta).astype(np.float32)
        return self.last_target.copy()


class DualPolicy:
    """Shared executed-action history with separate clock and command terms."""

    def __init__(self, walk_contract, recovery_contract, walk_actor, recovery_actor, switch_config):
        for key in ("joint_names", "default_joint_pos", "action_scale", "step_dt", "lower_limits", "upper_limits", "action_clip"):
            if walk_contract[key] != recovery_contract[key]:
                raise ValueError(f"Policy contracts disagree on {key}")
        self.contracts = {"WALK": walk_contract, "RECOVERY": recovery_contract}
        self.actors = {"WALK": walk_actor, "RECOVERY": recovery_actor}
        self.histories = {k: ObservationHistory(c) for k, c in self.contracts.items()}
        self.switch = PolicySwitch(switch_config)
        self.default = np.asarray(walk_contract["default_joint_pos"], dtype=np.float32)
        self.scale = np.asarray(walk_contract["action_scale"], dtype=np.float32)
        self.pose_ids = [i for i, n in enumerate(walk_contract["joint_names"]) if not n.startswith("neck_")]
        self.reset()

    def reset(self):
        self.last_action = np.zeros(20, dtype=np.float32)
        self.step_count = 0
        self.switch.reset()
        for history in self.histories.values():
            history.reset()

    def step(self, now, position, velocity, gyro, gravity, command):
        c = self.contracts["WALK"]
        position, velocity = np.asarray(position), np.asarray(velocity)
        if position.shape != (20,) or velocity.shape != (20,):
            raise ValueError("Expected all 20 measured joint positions and velocities")
        tilt = math.degrees(math.acos(float(np.clip(-gravity[2], -1, 1))))
        pose_error = float(np.max(np.abs((position - self.default)[self.pose_ids])))
        mode = self.switch.update(now, tilt, float(np.linalg.norm(gyro)), pose_error)
        if mode == "FAULT":
            raise RuntimeError("Recovery tilt limit or timeout reached; explicit restart required")
        values = {
            "base_ang_vel": gyro, "projected_gravity": gravity,
            "joint_pos_rel": position - self.default, "joint_vel_rel": velocity,
            "last_action": self.last_action,
        }
        observations = {}
        # Both histories run continuously: previous actions are those selected
        # by the supervisor, never counterfactual outputs of an inactive actor.
        for key, contract in self.contracts.items():
            phase = 2 * math.pi * self.step_count * contract["step_dt"] / contract["gait_period"]
            values["gait_phase"] = [math.sin(phase), math.cos(phase)]
            values["velocity_commands"] = command if key == "WALK" and mode == "WALK" else np.zeros(3)
            observations[key] = self.histories[key].append(values)
        action = self.actors[mode](observations[mode])
        if c["action_clip"] is not None:
            action = np.clip(action, -c["action_clip"], c["action_clip"])
        target = self.default + self.scale * action
        # These actuators had zero stiffness during training. Do not turn their
        # unconstrained actor outputs into active hardware position commands.
        for i, name in enumerate(c["joint_names"]):
            if name.startswith("neck_") or (mode == "WALK" and ("shoulder" in name or "elbow" in name)):
                target[i] = position[i]
        target = np.clip(target, c["lower_limits"], c["upper_limits"])
        self.last_action = action.copy()
        self.step_count += 1
        return mode, target, observations[mode]
