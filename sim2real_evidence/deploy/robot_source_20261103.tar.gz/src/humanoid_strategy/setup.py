import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'humanoid_strategy'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # launch / config 폴더를 share 로 설치.
        #   ※ data_files 항목이 바뀌면(파일 추가/이름변경) --symlink-install 이어도
        #     반드시 colcon build 를 다시 해야 install 트리에 반영된다(노드 재시작만으론 X).
        (os.path.join('share', package_name, 'launch'),
            glob(os.path.join('launch', '*launch.py'))),
        (os.path.join('share', package_name, 'config'),
            glob(os.path.join('config', '*.yaml'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jace',
    maintainer_email='qkrguswo2946@khu.ac.kr',
    description='KHUBER 경기 전략 레이어 — 역할 배정 + 전략 FSM(예정)',
    license='TODO: License declaration',
    extras_require={
        'test': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            # 역할 배정(관찰 전용) → /strategy/role + /strategy/role_markers
            'role_assigner = humanoid_strategy.role_assigner_node:main',
            # 전략 FSM(step2: READY 포지셔닝) → /strategy/state + NavigateToPose
            'strategy_fsm = humanoid_strategy.strategy_fsm_node:main',
            # 팀 통신(step4) → /team_comm/state (자세/공/넘어짐+역할 공유 + 거리중재)
            'team_comm = humanoid_strategy.team_comm_node:main',
        ],
    },
)
