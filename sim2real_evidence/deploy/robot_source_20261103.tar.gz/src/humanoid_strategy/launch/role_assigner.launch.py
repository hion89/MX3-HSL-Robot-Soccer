#!/usr/bin/env python3
# ==========================================================================
# role_assigner.launch.py
# --------------------------------------------------------------------------
# 전략 step1 — 역할 배정(관찰 전용) 노드 1개를 띄운다.
#   role_assigner_node : /game_state + /robot_state → /strategy/role + 마커
#
# [player_number 자동 결정]  ← game_controller.launch.py 와 동일 규칙
#   - robot 인자가 비면 hostname 앞부분 사용 (robo04-desktop → robo04)
#   - humanoid_bringup/config/robot_params.yaml 의 <robot> 섹션에서 player_number 읽음
#   - 우선순위: launch 인자(player_number:=) > robot_params.yaml > strategy.yaml 기본값
#
# [실행 예]
#   ros2 launch humanoid_strategy role_assigner.launch.py            # 전부 자동
#   ros2 launch humanoid_strategy role_assigner.launch.py robot:=robo03
#   ros2 launch humanoid_strategy role_assigner.launch.py player_number:=2
#
# [확인]
#   ros2 topic echo /strategy/role
#   RViz: Fixed Frame=map, Add → MarkerArray → /strategy/role_markers
#   GameController(없어도 됨) penalty 를 바꿔가며 포메이션/역할 변화 관찰.
# ==========================================================================
import os
import socket
import yaml

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch.logging import get_logger
from launch_ros.actions import Node


def _resolve_robot_name(name: str) -> str:
    """robot 인자가 비면 hostname 앞부분으로 (robo04-desktop → robo04)."""
    name = (name or "").strip()
    if name:
        return name
    host = socket.gethostname()
    return host.split("-")[0].split(".")[0]


def _load_merged_params(robot: str):
    """robot_params.yaml 에서 common + <robot> 병합본 반환(robot 우선)."""
    cfg = os.path.join(
        get_package_share_directory("humanoid_bringup"),
        "config", "robot_params.yaml")
    data = {}
    if os.path.isfile(cfg):
        with open(cfg, "r") as f:
            data = yaml.safe_load(f) or {}
    merged = dict(data.get("common", {}) or {})
    merged.update(data.get(robot, {}) or {})
    return merged, cfg


def _resolve_int(arg_val: str, merged: dict, key: str, default):
    """우선순위: launch 인자(명시) > robot_params.yaml > 기본값(None 이면 미설정)."""
    arg_val = (arg_val or "").strip()
    if arg_val:
        return int(arg_val), "launch 인자"
    if key in merged:
        return int(merged[key]), "robot_params.yaml"
    return default, "기본값(strategy.yaml)"


def _setup(context, *args, **kwargs):
    log = get_logger("role_assigner.launch")

    robot = _resolve_robot_name(LaunchConfiguration("robot").perform(context))
    merged, cfg = _load_merged_params(robot)

    # player_number: 인자 > robot_params.yaml > (None → strategy.yaml 기본값 사용)
    player_number, pn_src = _resolve_int(
        LaunchConfiguration("player_number").perform(context),
        merged, "player_number", None)

    # strategy.yaml 경로
    strategy_yaml = os.path.join(
        get_package_share_directory("humanoid_strategy"),
        "config", "strategy.yaml")

    # 파라미터: yaml 파일 먼저, 그 위에 player_number override(있을 때만).
    params = [strategy_yaml]
    if player_number is not None:
        params.append({"player_number": player_number})

    log.info(
        f"[role_assigner] robot='{robot}' "
        f"player_number={player_number}({pn_src})  yaml={strategy_yaml}")

    return [
        Node(
            package="humanoid_strategy",
            executable="role_assigner",
            name="role_assigner_node",
            output="screen",
            parameters=params,
        ),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            "robot", default_value="",
            description="robot_params.yaml 섹션 선택. 비면 hostname 앞부분(robo04 등)"),
        DeclareLaunchArgument(
            "player_number", default_value="",
            description="이 로봇 선수 번호. 비면 robot_params.yaml > strategy.yaml 기본값"),
        OpaqueFunction(function=_setup),
    ])
