#!/usr/bin/env python3
# ==========================================================================
# team_comm.launch.py
# --------------------------------------------------------------------------
# 팀 통신 노드(team_comm) 단독 브링업.
#   · 자세/공/넘어짐 + 역할/단계/공거리를 UDP broadcast(포트 10000+team_number)로
#     주고받아 /team_comm/state 로 묶는다(거리중재 owner 포함).
#
# [team_number / player_number 자동 결정]  ← game_controller.launch.py 와 동일 규칙
#   - robot 인자가 비면 hostname 앞부분 (robo04-desktop → robo04)
#   - humanoid_bringup/config/robot_params.yaml 에서:
#       · team_number   : common 섹션
#       · player_number : <robot> 섹션
#   우선순위: launch 인자(명시) > robot_params.yaml > 기본값(team 35 / player 1)
#
# [실행 예]
#   ros2 launch humanoid_strategy team_comm.launch.py                 # 전부 자동
#   ros2 launch humanoid_strategy team_comm.launch.py robot:=robo03
#   ros2 launch humanoid_strategy team_comm.launch.py send_rate_hz:=2.0
# ==========================================================================
import os
import socket
import yaml

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch.logging import get_logger
from launch_ros.actions import Node


def _resolve_robot_name(name: str) -> str:
    name = (name or "").strip()
    if name:
        return name
    host = socket.gethostname()
    return host.split("-")[0].split(".")[0]


def _load_merged_params(robot: str):
    cfg = os.path.join(
        get_package_share_directory("humanoid_bringup"),
        "config", "robot_params.yaml")
    data = {}
    if os.path.isfile(cfg):
        with open(cfg, "r") as f:
            data = yaml.safe_load(f) or {}
    merged = dict(data.get("common", {}) or {})
    merged.update(data.get(robot, {}) or {})
    return merged, cfg


def _resolve_int(arg_val: str, merged: dict, key: str, default: int):
    arg_val = (arg_val or "").strip()
    if arg_val:
        return int(arg_val), f"launch 인자({key}:=)"
    if key in merged:
        return int(merged[key]), "robot_params.yaml"
    return default, f"기본값({default})"


def _setup(context, *args, **kwargs):
    log = get_logger("team_comm.launch")
    robot = _resolve_robot_name(LaunchConfiguration("robot").perform(context))
    merged, cfg = _load_merged_params(robot)

    team_number, team_src = _resolve_int(
        LaunchConfiguration("team_number").perform(context), merged, "team_number", 35)
    player_number, pn_src = _resolve_int(
        LaunchConfiguration("player_number").perform(context), merged, "player_number", 1)

    # ── zone 경계(공 owner 선출용) — ★strategy.yaml 과 반드시 동기 ──
    #   team_comm 은 이 값으로 "공이 어느 역할 zone 인가"를 판정해 owner 를 선출한다.
    #   strategy.yaml 의 role_assigner_node/strategy_fsm_node 의 defense_line_x/
    #   wing_split_y 와 값이 다르면, 경계밴드에 온 공의 zone 주인을 서로 다르게 봐서
    #   owner 가 엉킨다(수비수가 공격영역으로 끌려나가는 등). team_comm_node 코드
    #   기본값은 -0.30 이라, 여기서 명시적으로 안 넘기면 strategy 의 -0.70 과 어긋난다.
    #   float 캐스팅: declare_parameter 가 double 로 선언돼 문자열을 넣으면 타입 에러.
    defense_line_x = float(
        LaunchConfiguration("defense_line_x").perform(context))
    wing_split_y = float(
        LaunchConfiguration("wing_split_y").perform(context))

    log.info(
        f"[team_comm] robot='{robot}' "
        f"team_number={team_number}({team_src}) "
        f"player_number={player_number}({pn_src}) "
        f"zone(dl={defense_line_x}, wy={wing_split_y})  [{cfg}]")

    return [
        Node(
            package="humanoid_strategy",
            executable="team_comm",
            name="team_comm",
            output="screen",
            parameters=[{
                "team_number": team_number,
                "player_number": player_number,
                "send_rate_hz": LaunchConfiguration("send_rate_hz"),
                "broadcast_address": LaunchConfiguration("broadcast_address"),
                # ★zone 경계 — strategy.yaml 의 값과 동일하게 주입(위 주석 참조).
                "defense_line_x": defense_line_x,
                "wing_split_y": wing_split_y,
            }],
        ),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            "robot", default_value="",
            description="robot_params.yaml 섹션 선택. 비면 hostname 앞부분(robo04 등)"),
        DeclareLaunchArgument(
            "team_number", default_value="",
            description="우리 팀 번호. 비면 robot_params.yaml common 에서 자동(기본 35)"),
        DeclareLaunchArgument(
            "player_number", default_value="",
            description="이 로봇 선수 번호. 비면 robot_params.yaml 에서 자동 결정"),
        DeclareLaunchArgument(
            "send_rate_hz", default_value="2.0",
            description="팀 통신 송신 주기(Hz). 게임당 12000개 예산 내에서 조정"),
        DeclareLaunchArgument(
            "broadcast_address", default_value="255.255.255.255",
            description="UDP broadcast 대상 주소(서브넷 브로드캐스트로 바꿔도 됨)"),
        # ★zone 경계 — strategy.yaml 의 defense_line_x/wing_split_y 와 반드시 같은 값.
        #   기본값을 strategy.yaml 과 동일(-0.70 / 0.0)하게 맞춰 둔다. 값 바꿀 땐 양쪽 동시에.
        DeclareLaunchArgument(
            "defense_line_x", default_value="0.0",
            description="zone 경계 x[m]. ★strategy.yaml 의 defense_line_x 와 동일값 유지 (수비형: 0.0)"),
        DeclareLaunchArgument(
            "wing_split_y", default_value="0.0",
            description="윙 분리선 y[m]. ★strategy.yaml 의 wing_split_y 와 동일값 유지"),
        OpaqueFunction(function=_setup),
    ])
