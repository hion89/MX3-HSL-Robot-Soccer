#!/usr/bin/env python3
# ==========================================================================
# strategy.launch.py
# --------------------------------------------------------------------------
# 전략 스택 bring-up (step1 + step2):
#   1) role_assigner_node : /game_state + /robot_state → /strategy/role + 마커
#   2) strategy_fsm_node  : /strategy/role + /game_state → READY 포지셔닝(/pose_goal)
#
# [player_number 자동 결정]  ← game_controller.launch.py 와 동일 규칙
#   - robot 인자가 비면 hostname 앞부분 (robo04-desktop → robo04)
#   - humanoid_bringup/config/robot_params.yaml 의 <robot> 섹션에서 player_number
#   - 우선순위: launch 인자(player_number:=) > robot_params.yaml > strategy.yaml 기본값
#   결정된 player_number 는 두 노드에 동일하게 주입한다.
#
# [실행 예]
#   ros2 launch humanoid_strategy strategy.launch.py                 # 전부 자동
#   ros2 launch humanoid_strategy strategy.launch.py robot:=robo03
#   ros2 launch humanoid_strategy strategy.launch.py player_number:=2
#
# [★ field_profile — 경기장 규격에 따른 좌표 자동 축척 (2026-08-18 추가)]
#   strategy.yaml 의 좌표는 전부 S-Field(9x6) 기준으로 적혀 있다. 연습장
#   (3.9x2.6)에서 그대로 쓰면 로봇이 필드 밖 좌표(x=±4.5, 실제 골라인은
#   ±1.95)를 목표로 잡아 포지셔닝이 전부 어긋난다.
#
#   그래서 field_profile 인자를 받아, humanoid_localization 의
#   field_geometry(= localization 과 '같은' 단일 진실원)에서 두 프로파일의
#   길이 비를 구해 좌표계 파라미터만 자동으로 곱한다.
#     scale = geom(target).length_m / geom("s_field").length_m
#     practice → 3.9/9.0 = 0.4333  (폭도 2.6/6.0 = 0.4333 로 동일 배율)
#
#   ※ 축척 대상은 "필드 좌표"뿐이다. 로봇/공 크기를 기준으로 정한 값
#     (ball_clearance_m, outside_margin_m, out_kick_band_m)과 각도(*_deg)는
#     필드가 줄어도 그대로여야 하므로 건드리지 않는다.
#
#   ※ strategy.yaml 헤더에 적힌 대로 home_/ready_ 좌표는 원래 연습장에서
#     검증한 배치를 x2.3077 로 확대한 값이다. 즉 practice 로 축척하면
#     원래 검증했던 그 배치로 정확히 되돌아간다.
#
#   [실행 예]
#     ros2 launch humanoid_strategy strategy.launch.py field_profile:=practice
#
# [전제 — strategy_fsm 이 실제로 걸어가려면 아래가 떠 있어야 함]
#   - GameController 수신: humanoid_game_controller game_controller.launch.py
#   - 로컬라이제이션(map→base_link TF): humanoid_localization ekf_localization 런치
#   - 위치이동 컨트롤러: humanoid_localization pose_goal.launch.py
#     (READY/SUPPORT 도 pose_goal_controller 로 걸어감 — Nav2 불필요)
#   - 공 추격/킥: ball_follow.launch.py + vision_servo.launch.py
#   - 보행 파이프라인: humanoid_bringup control.launch.py
# ==========================================================================
import os
import socket
import yaml

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch.logging import get_logger
from launch_ros.actions import Node


# ── 좌표 축척 대상 ────────────────────────────────────────────────────────
# strategy.yaml 값이 어느 규격으로 적혀 있는지. 여기 기준으로 비율을 낸다.
YAML_BASE_PROFILE = "s_field"

# 스칼라 좌표 키(필드 좌표계 값). 노드 구분 없이 이름으로 매칭한다.
#   ※ *_deg(각도), *_band_m/*_margin_m/*_clearance_m(로봇·공 크기 기준)은
#     필드가 줄어도 변하면 안 되므로 일부러 제외했다.
SCALED_SCALAR_KEYS = (
    "own_goal_x",
    "attack_goal_x",
    "field_x_max",
    "field_y_max",
    "defense_line_x",
    "wing_split_y",
    "field_half_length_x",
    "field_half_width_y",
)

# [x, y] 좌표쌍 키의 접두사. home_*/ready_* 포메이션 전부가 대상이다.
SCALED_LIST_PREFIXES = ("home_", "ready_")

# 접두사에 걸리지만 좌표가 아닌 키(각도 등)는 여기서 제외한다.
SCALED_LIST_EXCLUDE = ("ready_yaw_deg",)


def _resolve_robot_name(name: str) -> str:
    name = (name or "").strip()
    if name:
        return name
    host = socket.gethostname()
    return host.split("-")[0].split(".")[0]


def _field_scale(profile: str, log):
    """target 프로파일 / YAML_BASE_PROFILE 의 길이 비를 구한다.

    localization 의 field_geometry 를 그대로 import 해서, 경기장 치수의
    단일 진실원을 유지한다(여기에 숫자를 복사해 두면 나중에 규격이 바뀔 때
    두 곳을 고쳐야 하고, 한쪽만 고치면 조용히 어긋난다).

    import 이 실패하면(패키지 미빌드 등) 축척 없이 1.0 을 쓰되 경고한다.
    """
    profile = (profile or "").strip().lower()
    if not profile or profile == YAML_BASE_PROFILE:
        return 1.0, YAML_BASE_PROFILE
    try:
        from humanoid_localization.vision.field_geometry import (
            field_geometry_for_profile)
    except Exception as e:                                  # noqa: BLE001
        log.warn(
            f"[strategy] field_geometry import 실패({e}) → 좌표 축척을 "
            f"건너뜁니다. strategy.yaml 의 {YAML_BASE_PROFILE} 좌표가 "
            "그대로 쓰입니다.")
        return 1.0, YAML_BASE_PROFILE

    base = field_geometry_for_profile(YAML_BASE_PROFILE)
    tgt = field_geometry_for_profile(profile)
    sx = tgt.length_m / base.length_m
    sy = tgt.width_m / base.width_m
    # 두 축 배율이 다르면 단일 스칼라로 축척할 수 없다. 형태가 찌그러지므로
    # 조용히 진행하지 않고 크게 경고한다(x 배율만 적용).
    if abs(sx - sy) > 1e-6:
        log.warn(
            f"[strategy] 프로파일 '{profile}' 의 x/y 배율이 다릅니다 "
            f"(x={sx:.4f}, y={sy:.4f}). 포메이션 형태가 왜곡됩니다. "
            "x 배율만 적용하니 좌표를 직접 검토하세요.")
    return sx, profile


def _scale_params(params: dict, scale: float) -> dict:
    """좌표계 파라미터만 scale 배 한다. 그 외 키는 손대지 않는다."""
    if abs(scale - 1.0) < 1e-9:
        return {}

    # 소수 4자리(0.1mm)면 충분하고, 부동소수점 잔여 자릿수
    # (1.9500000000000002 같은)가 로그에 그대로 찍히는 것을 막는다.
    def _s(x):
        return round(float(x) * scale, 4)

    out = {}
    for k, v in params.items():
        if k in SCALED_SCALAR_KEYS and isinstance(v, (int, float)):
            out[k] = _s(v)
        elif (k.startswith(SCALED_LIST_PREFIXES)
                and k not in SCALED_LIST_EXCLUDE
                and isinstance(v, list) and len(v) == 2
                and all(isinstance(x, (int, float)) for x in v)):
            out[k] = [_s(v[0]), _s(v[1])]
    return out


def _load_merged_params(robot: str):
    cfg = os.path.join(
        get_package_share_directory("humanoid_bringup"),
        "config", "robot_params.yaml")
    data = {}
    if os.path.isfile(cfg):
        with open(cfg, "r") as f:
            data = yaml.safe_load(f) or {}
    merged = dict(data.get("common", {}) or {})
    merged.update(data.get(robot, {}) or {})
    return merged


def _resolve_int(arg_val: str, merged: dict, key: str, default):
    arg_val = (arg_val or "").strip()
    if arg_val:
        return int(arg_val), "launch 인자"
    if key in merged:
        return int(merged[key]), "robot_params.yaml"
    return default, "기본값(strategy.yaml)"


def _setup(context, *args, **kwargs):
    log = get_logger("strategy.launch")

    robot = _resolve_robot_name(LaunchConfiguration("robot").perform(context))
    merged = _load_merged_params(robot)
    player_number, pn_src = _resolve_int(
        LaunchConfiguration("player_number").perform(context),
        merged, "player_number", None)

    strategy_yaml = os.path.join(
        get_package_share_directory("humanoid_strategy"),
        "config", "strategy.yaml")

    # ── 경기장 규격에 따른 좌표 축척 ──
    profile_arg = LaunchConfiguration("field_profile").perform(context)
    scale, profile_used = _field_scale(profile_arg, log)

    # yaml 을 직접 읽어 축척할 키를 골라낸다. ROS 파라미터는 last-wins 라,
    # [yaml, {override}] 순으로 주면 override 가 이긴다.
    with open(strategy_yaml, "r") as f:
        ydata = yaml.safe_load(f) or {}

    def _node_overrides(node_name: str) -> dict:
        body = (ydata.get(node_name, {}) or {}).get("ros__parameters", {}) or {}
        return _scale_params(body, scale)

    ra_scaled = _node_overrides("role_assigner_node")
    fsm_scaled = _node_overrides("strategy_fsm_node")

    # 공통 파라미터: yaml 먼저, player_number override(있을 때만).
    common = [strategy_yaml]
    if player_number is not None:
        common.append({"player_number": player_number})

    log.info(
        f"[strategy] robot='{robot}' player_number={player_number}({pn_src}) "
        f"yaml={strategy_yaml}")
    if abs(scale - 1.0) < 1e-9:
        log.info(
            f"[strategy] field_profile='{profile_used}' — 좌표 축척 없음 "
            f"(strategy.yaml 원값 사용)")
    else:
        log.info(
            f"[strategy] field_profile='{profile_used}' — 좌표 축척 "
            f"x{scale:.4f} 적용 (role_assigner {len(ra_scaled)}개 / "
            f"strategy_fsm {len(fsm_scaled)}개 키)")
        # 대표값 몇 개를 찍어 눈으로 검증할 수 있게 한다.
        for k in ("own_goal_x", "attack_goal_x", "field_x_max"):
            if k in ra_scaled:
                log.info(f"[strategy]   {k}: {ra_scaled[k]:+.3f}")
        if "home_keeper" in ra_scaled:
            log.info(f"[strategy]   home_keeper: {ra_scaled['home_keeper']}")

    return [
        Node(
            package="humanoid_strategy",
            executable="role_assigner",
            name="role_assigner_node",
            output="screen",
            parameters=common + ([ra_scaled] if ra_scaled else []),
        ),
        Node(
            package="humanoid_strategy",
            executable="strategy_fsm",
            name="strategy_fsm_node",
            output="screen",
            parameters=common + ([fsm_scaled] if fsm_scaled else []),
        ),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            "robot", default_value="",
            description="robot_params.yaml 섹션 선택. 비면 hostname 앞부분(robo04 등)"),
        DeclareLaunchArgument(
            "player_number", default_value="",
            description="이 로봇 선수 번호. 비면 robot_params.yaml > strategy.yaml 기본값"),
        DeclareLaunchArgument(
            "field_profile", default_value="s_field",
            description="경기장 규격. s_field(9x6, 기본) | practice(3.9x2.6). "
                        "strategy.yaml 좌표는 s_field 기준이라, practice 면 "
                        "필드 좌표 파라미터를 자동으로 축척한다. "
                        "★ localization(ekf_localization.launch.py)에 넘기는 "
                        "값과 반드시 같아야 한다."),
        OpaqueFunction(function=_setup),
    ])
