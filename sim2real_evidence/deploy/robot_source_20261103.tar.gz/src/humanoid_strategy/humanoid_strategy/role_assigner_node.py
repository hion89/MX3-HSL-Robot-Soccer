# -*- coding: utf-8 -*-
# =============================================================================
#  role_assigner_node.py   (전략 레이어 step1 — 관찰 전용)
#
#  "이 로봇이 지금 무슨 역할인가"를 /game_state 와 /robot_state 만으로 계산해
#    (1) /strategy/role (RoleAssignment)  (2) /strategy/role_markers (RViz) 로 발행.
#
#  ★ 관찰 전용: cmd_vel 도, enable 도, goal 도 일절 내지 않는다(제어 영향 0).
#    역할/zone/home 이 RViz 에서 의도대로 보이는지 먼저 눈으로 검증하는 단계.
#
#  [무엇을 받고 무엇을 내는가]
#  --------------------------------------------------------------------------
#   입력:
#     - /game_state (humanoid_behavior_interfaces/GameState)
#         · players_per_team, our_goalkeeper, penalties[], state 사용.
#         · 안 들어오면(벤치) default_players_per_team/default_keeper_number 가정.
#     - /robot_state (std_msgs/String)  — 낙상 FSM 상태(NORMAL/FALLEN/...).
#         · 내 상태가 NORMAL 이 아니면 is_active=false (robot_state_active_only).
#   출력:
#     - /strategy/role (RoleAssignment) — 내 역할 배정 결과.
#     - /strategy/role_markers (visualization_msgs/MarkerArray, map 프레임)
#         · zone 선/골대/역할 home/상태텍스트. 내 역할은 강조. latched(QoS) 라
#           RViz 가 늦게 떠도 마지막 마커를 받아 바로 보인다.
#
#  [배정 규칙 — 분산 일관성(팀 통신 없이 충돌 방지)]
#  --------------------------------------------------------------------------
#   모든 로봇이 같은 /game_state(penalty 포함)를 보고 동일 규칙으로 계산한다.
#     1) 키퍼는 our_goalkeeper 번호로 고정(규칙상 불변).
#     2) 활성 필드플레이어 = (키퍼 제외) & (penalty==NONE) 인 선수, 번호 오름차순.
#     3) 활성 필드 수 n 으로 포메이션 선택:
#          n>=3 → [A_CENTER, B_WING_POS, C_WING_NEG, (SUPPORTER...)]   (4대)
#          n==2 → [A_CENTER, B_ATTACK]                                 (3대)
#          n==1 → [STRIKER_ROAM]                                       (2대 이하)
#     4) 내 번호가 활성 필드의 몇 번째인지(idx)로 슬롯을 받는다 → 로봇끼리 안 겹침.
#   한계: penalty 가 아닌 "낙상한 팀메이트"는 남 시야엔 활성으로 보여 슬롯을 차지함.
#         → team_comm(다음 단계)에서 팀메이트 낙상까지 공유해 보완.
#
#  [좌표 컨벤션 — 확정]
#   +x=공격(상대 골대), -x=우리 골대(고정). 하프타임 플립은 로컬라이제이션이 미러
#   처리 → 이 노드는 항상 "-x=수비"를 믿는다(first_half 분기 없음).
#
#  [검증]
#   ros2 run humanoid_strategy role_assigner   (또는 launch)
#   ros2 topic echo /strategy/role
#   RViz: Fixed Frame=map, MarkerArray=/strategy/role_markers 추가.
#   GameController 로 penalty 를 넣어 보며 활성 수/포메이션/역할이 바뀌는지 확인.
# =============================================================================

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from std_msgs.msg import String, ColorRGBA, Header
from geometry_msgs.msg import Point
from visualization_msgs.msg import Marker, MarkerArray

from humanoid_behavior_interfaces.msg import GameState, RoleAssignment


# ── 역할 enum (RoleAssignment.msg 상수와 동일하게 유지) ──
ROLE_NONE = 0
ROLE_GOALKEEPER = 1
ROLE_A_CENTER = 2
ROLE_B_WING_POS = 3
ROLE_C_WING_NEG = 4
ROLE_B_ATTACK = 5
ROLE_STRIKER_ROAM = 6
ROLE_SUPPORTER = 7

# 역할 → 사람이 읽는 이름(디버그/RViz)
ROLE_NAME = {
    ROLE_NONE: "NONE",
    ROLE_GOALKEEPER: "GOALKEEPER",
    ROLE_A_CENTER: "A_CENTER",
    ROLE_B_WING_POS: "B_WING+",
    ROLE_C_WING_NEG: "C_WING-",
    ROLE_B_ATTACK: "B_ATTACK",
    ROLE_STRIKER_ROAM: "STRIKER",
    ROLE_SUPPORTER: "SUPPORTER",
}

# 역할 → RViz 색(평상). 내 역할은 강조색으로 덮어쓴다.
ROLE_COLOR = {
    ROLE_GOALKEEPER: (0.10, 0.45, 1.00),   # 파랑
    ROLE_A_CENTER: (0.60, 0.40, 0.95),     # 보라
    ROLE_B_WING_POS: (0.12, 0.70, 0.55),   # 청록
    ROLE_C_WING_NEG: (0.95, 0.65, 0.10),   # 주황
    ROLE_B_ATTACK: (0.12, 0.70, 0.55),     # 청록
    ROLE_STRIKER_ROAM: (0.85, 0.20, 0.55),  # 핑크
    ROLE_SUPPORTER: (0.55, 0.55, 0.55),    # 회색
}

# 낙상 FSM 의 "정상" 상태값(이 외엔 비활성으로 본다). fall_manager STATE_NORMAL 과 동일.
ROBOT_STATE_NORMAL = "NORMAL"


class RoleAssigner(Node):
    def __init__(self):
        super().__init__("role_assigner_node")

        # ──────────────────────────────────────────────────────────────────
        #  파라미터 (기본값은 strategy.yaml 과 일치)
        # ──────────────────────────────────────────────────────────────────
        gp = self.declare_parameter
        self.player_number = int(gp("player_number", 1).value)

        self.default_ppt = int(gp("default_players_per_team", 4).value)
        self.default_keeper = int(gp("default_keeper_number", 1).value)

        # 기본값은 yaml(strategy.yaml)이 없을 때의 폴백. S-Field(9x6) 기준으로 맞춤
        #   — 골/필드 경계는 사실값, home 좌표는 연습장 포메이션 ×2.3077 스케일값.
        self.own_goal_x = float(gp("own_goal_x", -4.5).value)
        self.attack_goal_x = float(gp("attack_goal_x", 4.5).value)
        self.field_x_max = float(gp("field_x_max", 4.5).value)
        self.field_y_max = float(gp("field_y_max", 3.0).value)

        self.defense_line_x = float(gp("defense_line_x", -0.70).value)
        self.wing_split_y = float(gp("wing_split_y", 0.0).value)
        self.wing_hysteresis = float(gp("wing_hysteresis", 0.45).value)

        # home 좌표들 ([x, y] double array). 노드 안에서는 튜플로 보관.
        self.home_keeper = self._xy(gp("home_keeper", [-3.92, 0.0]).value)
        self.home_a_center = self._xy(gp("home_a_center", [-1.62, 0.0]).value)
        self.home_b_wing = self._xy(gp("home_b_wing", [0.69, 1.27]).value)
        self.home_c_wing = self._xy(gp("home_c_wing", [0.69, -1.27]).value)
        self.home_a_center_3 = self._xy(gp("home_a_center_3", [-1.62, 0.0]).value)
        self.home_b_attack_3 = self._xy(gp("home_b_attack_3", [1.38, 0.0]).value)
        self.home_striker = self._xy(gp("home_striker", [0.0, 0.0]).value)
        self.home_supporter = self._xy(gp("home_supporter", [0.69, 0.0]).value)
        # 4대(n>=3) 수비형: 단일 공격수(B_ATTACK) home — 상대진영 중앙.
        self.home_attacker = self._xy(gp("home_attacker", [1.5, 0.0]).value)

        self.publish_rate = float(gp("publish_rate_hz", 5.0).value)
        self.stale_timeout = float(gp("stale_timeout_sec", 2.0).value)
        self.robot_state_active_only = bool(gp("robot_state_active_only", True).value)

        self.role_topic = str(gp("role_topic", "/strategy/role").value)
        self.marker_topic = str(gp("marker_topic", "/strategy/role_markers").value)
        self.marker_frame = str(gp("marker_frame", "map").value)
        self.marker_ns = str(gp("marker_namespace", "strategy").value)

        # ──────────────────────────────────────────────────────────────────
        #  통신
        # ──────────────────────────────────────────────────────────────────
        self.create_subscription(GameState, "/game_state", self._cb_game, 10)
        self.create_subscription(String, "/robot_state", self._cb_robot_state, 10)

        self.role_pub = self.create_publisher(RoleAssignment, self.role_topic, 10)

        # 마커는 latched(TRANSIENT_LOCAL) — RViz 가 늦게 떠도 마지막 상태를 받아 바로 보임.
        latched_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.marker_pub = self.create_publisher(MarkerArray, self.marker_topic, latched_qos)

        # ──────────────────────────────────────────────────────────────────
        #  내부 상태
        # ──────────────────────────────────────────────────────────────────
        self.last_game = None          # 마지막 GameState
        self.last_game_time = None     # 마지막 수신 시각(rclpy Time)
        self.robot_state = None        # 마지막 /robot_state 문자열

        self.create_timer(1.0 / max(self.publish_rate, 1.0), self._tick)

        self.get_logger().info(
            f"role_assigner 시작 — player_number={self.player_number}, "
            f"role→{self.role_topic}, markers→{self.marker_topic} (관찰 전용)")

    # ----------------------------------------------------------------------
    #  유틸
    # ----------------------------------------------------------------------
    @staticmethod
    def _xy(v):
        """[x, y] 파라미터를 (float, float) 튜플로."""
        try:
            return (float(v[0]), float(v[1]))
        except Exception:
            return (0.0, 0.0)

    def _cb_game(self, msg: GameState):
        self.last_game = msg
        self.last_game_time = self.get_clock().now()

    def _cb_robot_state(self, msg: String):
        self.robot_state = msg.data

    def _game_is_fresh(self) -> bool:
        """최근 stale_timeout 안에 /game_state 를 받았는가."""
        if self.last_game is None or self.last_game_time is None:
            return False
        dt = (self.get_clock().now() - self.last_game_time).nanoseconds * 1e-9
        return dt <= self.stale_timeout

    def _get_game_info(self):
        """현재 경기 정보를 (ppt, keeper_num, penalties[list], gc_ok) 로 정리.
        penalties[i] = 선수 i+1 의 penalty 코드. GC 없으면 전부 NONE 가정.
        """
        if self._game_is_fresh() and self.last_game.team_found:
            g = self.last_game
            ppt = max(int(g.players_per_team), 1)
            keeper = int(g.our_goalkeeper)
            # penalties 길이가 ppt 와 다를 수 있으니 안전하게 패딩.
            pen = list(g.penalties)
            if len(pen) < ppt:
                pen = pen + [GameState.PENALTY_NONE] * (ppt - len(pen))
            return ppt, keeper, pen[:ppt], True
        # 벤치 폴백
        ppt = max(self.default_ppt, 1)
        keeper = self.default_keeper
        pen = [GameState.PENALTY_NONE] * ppt
        return ppt, keeper, pen, False

    # ----------------------------------------------------------------------
    #  역할 배정 핵심
    # ----------------------------------------------------------------------
    def _compute(self):
        """이 로봇의 역할을 계산해 (RoleAssignment, formation_slots, keeper_active) 반환.
        formation_slots = [(player_num, role, home), ...]  (마커로 팀 전체 플랜 표시용)
        """
        ppt, keeper, pen, gc_ok = self._get_game_info()
        my = self.player_number

        def penalty_of(p):
            return pen[p - 1] if 1 <= p <= ppt else GameState.PENALTY_NONE

        keeper_active = (1 <= keeper <= ppt) and (penalty_of(keeper) == GameState.PENALTY_NONE)

        # 활성 필드플레이어(키퍼 제외, penalty 없음), 번호 오름차순.
        active_field = [
            p for p in range(1, ppt + 1)
            if p != keeper and penalty_of(p) == GameState.PENALTY_NONE
        ]
        n = len(active_field)

        # 포메이션 슬롯 결정
        if n >= 3:
            # 수비형(공격1+수비2): slot0=단일 공격수(B_ATTACK, 상대진영 전체),
            #   slot1/2=좌/우 윙백(B_WING+/C_WING-, 우리진영 수비). zone 규칙은
            #   strategy_fsm._raw_in_zone / team_comm._ball_in_role_zone 에서 뒤집었다.
            slot_roles = [ROLE_B_ATTACK, ROLE_B_WING_POS, ROLE_C_WING_NEG] \
                + [ROLE_SUPPORTER] * (n - 3)
        elif n == 2:
            slot_roles = [ROLE_A_CENTER, ROLE_B_ATTACK]
        elif n == 1:
            slot_roles = [ROLE_STRIKER_ROAM]
        else:
            slot_roles = []

        # 팀 전체 슬롯 표(마커용): 키퍼 + 각 활성 필드 슬롯
        formation = []
        if 1 <= keeper <= ppt:
            formation.append((keeper, ROLE_GOALKEEPER, self.home_keeper))
        for idx, p in enumerate(active_field):
            role = slot_roles[idx]
            formation.append((p, role, self._home_for(role, n)))

        # ── 내 역할 ──
        my_penalized = penalty_of(my) != GameState.PENALTY_NONE
        # 내 낙상 여부: robot_state 가 들어왔고 NORMAL 이 아니면 비활성으로 본다.
        my_fallen = False
        if self.robot_state_active_only and self.robot_state is not None:
            my_fallen = (self.robot_state != ROBOT_STATE_NORMAL)

        if my == keeper and (1 <= keeper <= ppt):
            my_role = ROLE_GOALKEEPER
            my_home = self.home_keeper
        elif my in active_field:
            my_role = slot_roles[active_field.index(my)]
            my_home = self._home_for(my_role, n)
        else:
            my_role = ROLE_NONE
            my_home = (0.0, 0.0)

        is_active = (not my_penalized) and (not my_fallen) and (my_role != ROLE_NONE)

        # RoleAssignment 메시지 구성
        ra = RoleAssignment()
        ra.header = self._now_header()
        ra.my_player_number = int(my)
        ra.keeper_player_number = int(keeper)
        ra.active_field_count = int(n)
        ra.active_total_count = int(n + (1 if keeper_active else 0))
        ra.role = int(my_role)
        ra.role_name = ROLE_NAME.get(my_role, "?")
        ra.home_x = float(my_home[0])
        ra.home_y = float(my_home[1])
        ra.is_active = bool(is_active)

        return ra, formation, keeper_active, gc_ok

    def _home_for(self, role, n):
        """역할 + 활성 필드 수(n) → home 좌표."""
        if role == ROLE_GOALKEEPER:
            return self.home_keeper
        if n >= 3:
            return {
                ROLE_B_ATTACK: self.home_attacker,    # 단일 공격수(상대진영)
                ROLE_B_WING_POS: self.home_b_wing,     # 좌 윙백(우리진영 +y)
                ROLE_C_WING_NEG: self.home_c_wing,     # 우 윙백(우리진영 -y)
                ROLE_SUPPORTER: self.home_supporter,
            }.get(role, self.home_supporter)
        if n == 2:
            return {
                ROLE_A_CENTER: self.home_a_center_3,
                ROLE_B_ATTACK: self.home_b_attack_3,
            }.get(role, self.home_supporter)
        # n <= 1
        return self.home_striker

    # ----------------------------------------------------------------------
    #  타이머: 계산 → 발행
    # ----------------------------------------------------------------------
    def _tick(self):
        ra, formation, keeper_active, gc_ok = self._compute()
        self.role_pub.publish(ra)
        self.marker_pub.publish(
            self._make_markers(ra, formation, keeper_active, gc_ok))

    # ----------------------------------------------------------------------
    #  RViz 마커
    # ----------------------------------------------------------------------
    def _now_header(self) -> Header:
        h = Header()
        h.stamp = self.get_clock().now().to_msg()
        h.frame_id = self.marker_frame
        return h

    def _make_markers(self, ra, formation, keeper_active, gc_ok) -> MarkerArray:
        """zone 선 + 골대 + 역할 home + 상태텍스트. 고정 id 로 매번 덮어쓴다."""
        arr = MarkerArray()
        h = self._now_header()

        def base(mid, mtype):
            m = Marker()
            m.header = h
            m.ns = self.marker_ns
            m.id = mid
            m.type = mtype
            m.action = Marker.ADD
            m.pose.orientation.w = 1.0
            return m

        def color(r, g, b, a=1.0):
            return ColorRGBA(r=float(r), g=float(g), b=float(b), a=float(a))

        def pt(x, y, z=0.0):
            return Point(x=float(x), y=float(y), z=float(z))

        # ── 1) 필드 외곽(LINE_STRIP) — 벤치에서도 기준선이 보이게 ──
        fx, fy = self.field_x_max, self.field_y_max
        outline = base(1, Marker.LINE_STRIP)
        outline.scale.x = 0.02
        outline.color = color(0.5, 0.5, 0.5, 0.5)
        outline.points = [pt(-fx, -fy), pt(fx, -fy), pt(fx, fy), pt(-fx, fy), pt(-fx, -fy)]
        arr.markers.append(outline)

        # ── 2) 수비 라인(x = defense_line_x, 세로) ──
        dl = base(2, Marker.LINE_STRIP)
        dl.scale.x = 0.02
        dl.color = color(0.95, 0.25, 0.25, 0.8)   # 빨강 = 수비 경계
        dl.points = [pt(self.defense_line_x, -fy), pt(self.defense_line_x, fy)]
        arr.markers.append(dl)

        # ── 3) 윙 분리선(y = wing_split_y, 가로, 공격 반쪽에만) ──
        wl = base(3, Marker.LINE_STRIP)
        wl.scale.x = 0.015
        wl.color = color(0.2, 0.6, 0.95, 0.6)
        wl.points = [pt(self.defense_line_x, self.wing_split_y), pt(fx, self.wing_split_y)]
        arr.markers.append(wl)

        # ── 10/11) 우리 골대(수비) ──
        og = base(10, Marker.CUBE)
        og.pose.position = pt(self.own_goal_x, 0.0, 0.05)
        og.scale.x, og.scale.y, og.scale.z = 0.06, 0.5, 0.1
        og.color = color(0.95, 0.25, 0.25, 0.9)
        arr.markers.append(og)
        ogt = base(11, Marker.TEXT_VIEW_FACING)
        ogt.pose.position = pt(self.own_goal_x, 0.0, 0.25)
        ogt.scale.z = 0.12
        ogt.color = color(1, 1, 1, 0.9)
        ogt.text = "OUR GOAL (-X)"
        arr.markers.append(ogt)

        # ── 12/13) 상대 골대(공격) ──
        ag = base(12, Marker.CUBE)
        ag.pose.position = pt(self.attack_goal_x, 0.0, 0.05)
        ag.scale.x, ag.scale.y, ag.scale.z = 0.06, 0.5, 0.1
        ag.color = color(0.2, 0.8, 0.3, 0.9)
        arr.markers.append(ag)
        agt = base(13, Marker.TEXT_VIEW_FACING)
        agt.pose.position = pt(self.attack_goal_x, 0.0, 0.25)
        agt.scale.z = 0.12
        agt.color = color(1, 1, 1, 0.9)
        agt.text = "ATTACK (+X)"
        arr.markers.append(agt)

        # ── 역할 home 들(키퍼 30/31, 슬롯 40+ ...) ──
        #   매번 모양이 달라질 수 있으니 "쓰는 id 집합"을 추적해 안 쓰는 id 는 DELETE.
        used_ids = set()
        slot_base = 40   # 슬롯 i → 마커 id (slot_base + i*10), 텍스트는 +1
        for i, (pnum, role, home) in enumerate(formation):
            if role == ROLE_GOALKEEPER:
                cyl_id, txt_id = 30, 31
            else:
                # 키퍼 외 슬롯은 등장 순서대로(키퍼가 맨 앞에 있으니 i-1 안 쓰고 별도 카운트)
                k = sum(1 for j in range(i) if formation[j][1] != ROLE_GOALKEEPER)
                cyl_id, txt_id = slot_base + k * 10, slot_base + k * 10 + 1

            is_me = (pnum == self.player_number)
            r, g, b = ROLE_COLOR.get(role, (0.6, 0.6, 0.6))
            if is_me:
                r, g, b = 1.0, 0.85, 0.1  # 내 역할 = 노랑 강조

            cyl = base(cyl_id, Marker.CYLINDER)
            cyl.pose.position = pt(home[0], home[1], 0.02)
            sz = 0.22 if is_me else 0.16
            cyl.scale.x, cyl.scale.y, cyl.scale.z = sz, sz, 0.04
            cyl.color = color(r, g, b, 0.9 if is_me else 0.6)
            arr.markers.append(cyl)
            used_ids.add(cyl_id)

            txt = base(txt_id, Marker.TEXT_VIEW_FACING)
            txt.pose.position = pt(home[0], home[1], 0.22 if is_me else 0.18)
            txt.scale.z = 0.13 if is_me else 0.11
            txt.color = color(r, g, b, 1.0)
            txt.text = f"P{pnum}:{ROLE_NAME.get(role, '?')}" + (" <ME>" if is_me else "")
            arr.markers.append(txt)
            used_ids.add(txt_id)

        # 안 쓰는 home 슬롯 id 들 DELETE(이전 프레임에 그렸을 수 있는 최대치까지)
        for k in range(0, 4):
            for cand in (slot_base + k * 10, slot_base + k * 10 + 1):
                if cand not in used_ids:
                    d = base(cand, Marker.CYLINDER)
                    d.action = Marker.DELETE
                    arr.markers.append(d)
        for cand in (30, 31):
            if cand not in used_ids:
                d = base(cand, Marker.CYLINDER)
                d.action = Marker.DELETE
                arr.markers.append(d)

        # ── 20) 상태 텍스트(필드 위쪽) ──
        st = base(20, Marker.TEXT_VIEW_FACING)
        st.pose.position = pt(0.0, fy + 0.25, 0.2)
        st.scale.z = 0.14
        st.color = color(1, 1, 1, 0.95)
        gc = "GC:ok" if gc_ok else "GC:NONE(bench)"
        if ra.active_field_count >= 3:
            fname = "4-robot"
        elif ra.active_field_count == 2:
            fname = "3-robot"
        elif ra.active_field_count == 1:
            fname = "2-robot(roam)"
        else:
            fname = "no-field"
        kflag = "K" + ("O" if keeper_active else "X")
        me = f"P{ra.my_player_number}:{ra.role_name}" + ("" if ra.is_active else "[inactive]")
        st.text = f"{gc} | {kflag}+field{ra.active_field_count} | {fname} | me={me}"
        arr.markers.append(st)

        return arr


def main(args=None):
    rclpy.init(args=args)
    node = RoleAssigner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
