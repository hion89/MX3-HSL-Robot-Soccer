#!/usr/bin/env python3
# ==========================================================================
# team_comm_node.py
# --------------------------------------------------------------------------
# 로봇 간 팀 통신 노드. 각 로봇이 자기 상태(자세/공/넘어짐 + 역할/단계/공거리)를
# UDP broadcast 로 뿌리고, 팀메이트들의 상태를 받아 한 토픽(/team_comm/state)으로
# 묶는다. 추가로 "누가 공을 잡을지" owner 선출 결과를 파생값으로 제공한다.
#
# [왜 필요한가 — 메모리의 step4]
#   공 소유를 zone-only(통신 없이 같은 규칙으로 분산 판정)로만 하면 두 구멍이 있다.
#     (1) zone 주인이 공을 못 보거나(시야/가림) 넘어지면 그 zone 의 공을 아무도
#         안 쫓는다(0-체이서).
#     (2) 경계에서 누가 가져갈지 떨린다.
#   팀 통신으로 (1) 을 메운다 — "내 zone 공을 내가 못 볼 때, 그 공을 보는
#   팀메이트가 임시로 owner 가 된다". 통신이 끊기면 strategy_fsm 이 zone-only 로
#   degrade 하므로, 통신 장애 = 성능저하지 붕괴가 아니다.
#
# [owner 선출 정책 — owner_select_mode 파라미터]
#   이 노드가 owner 선출을 단독으로 책임진다(strategy_fsm 은 결과만 소비).
#   선출 로직을 여기 한 곳에 가둬 두면, 나중에 정책을 바꿔도 FSM 은 안 건드린다.
#     · 'zone_backup'(기본, 단순·안전) :
#         후보 = 활성(stale/fallen 아님) + 키퍼 아님 + 지금 공 보는 로봇.
#         그중 "자기 zone 안에서 공 보는 로봇(in-zone)"을 우선,
#         in-zone 이 하나도 없으면 zone 밖에서 보는 로봇이 백업으로 채운다.
#         같은 tier 안에선 공거리 최소(동점 시 선수번호). ★무상태 순수 함수라
#         모든 로봇이 같은 멤버 스냅샷이면 같은 owner 를 낸다(분산 일관성).
#     · 'distance' (구버전 호환/디버그) :
#         zone 무시, 공 보는 활성 로봇 중 공거리 최소.
#     · 'cost' (③ 풀세트 자리 — 아직 미구현) :
#         향후 cost = 공거리 + k*(zone 밖으로 벗어난 거리) + 합의 이상치 배제 +
#         전환 히스테리시스. 지금은 안전하게 zone_backup 으로 폴백(경고 1회).
#   ※ 키퍼는 owner 후보에서 제외(키퍼는 골을 지킨다 — 백업 체이서로 끌려나가지 않음).
#     키퍼만 공을 보는 상황은 owner=0 → 필드플레이어는 SEARCH(step3), 키퍼의 공유
#     공좌표가 탐색을 유도한다.
#
# [HSL 2026 규격]
#   · UDP broadcast, 포트 = 10000 + team_number
#   · 메시지당 최대 512바이트(우리 패킷은 45바이트로 여유), GameController 가 모니터링
#   · 팀당 게임당 12,000개 예산 → 4대 × 2Hz × ~20분 ≈ 9,600개로 안전.
#     ※ owner 핸드오프엔 2Hz 면 충분하다. 응답성 위해 송신율을 올리지 말 것
#       (예산 초과 + 더 빠른 전환은 오히려 스래싱).
#   · 전체 네트워크 1Mbit/s 제한
#
# [패킷 — 우리 내부 포맷(KHTM), little-endian, 45바이트, TC_VERSION=2]
#   '<4s 4B 3f B 3f 2B f B I B'
#   offset 0  : char  magic[4]    "KHTM"  (우리 팀 메시지 식별 — 타 팀/노이즈 배제)
#   offset 4  : uint8 version     (= 2)   ★v1(44B)→v2(45B): ball_conf 추가
#   offset 5  : uint8 player_num  1부터
#   offset 6  : uint8 team_num
#   offset 7  : uint8 fallen      1=넘어짐/복구중
#   offset 8  : float pose_x      map[m]
#   offset 12 : float pose_y      map[m]
#   offset 16 : float pose_theta  [rad]
#   offset 20 : uint8 ball_valid  1=최근 공 봄
#   offset 21 : float ball_x      map[m]  (절대좌표 — 선출/공유에 유용)
#   offset 25 : float ball_y      map[m]
#   offset 29 : float ball_age    [s]  (-1=한번도 못봄)
#   offset 33 : uint8 role        RoleAssignment.ROLE_*
#   offset 34 : uint8 phase       TeammateState.PHASE_*
#   offset 35 : float ball_dist   나~공 거리[m] (-1=공 모름) — owner 선출 입력
#   offset 39 : uint8 want_ball   1=공 잡으러 가는 중
#   offset 40 : uint32 seq        시퀀스
#   offset 44 : uint8 ball_conf   ★예약: 공 신뢰도 0~255 (255=1.0). 지금 단순판은
#                                  안 쓰고 placeholder 만 채운다. v2 로 미리 자리만
#                                  잡아 둬, 나중에 ③ 붙일 때 패킷 포맷을 안 바꾼다
#                                  (포맷 변경 = 전 로봇 동시 재배포 필요 → 회피).
#   ※ '<' 표준사이즈라 패딩 없음(비정렬 float 도 packed 처리).
#
# [수집 — 자기 상태 소스]
#   자기 pose : ★pose_source='tf'(기본) → map→base_link TF 룩업(EKF 융합, 제어기와
#               동일 소스 — 부드러움). pose_source='topic' → /localization/vision_pose
#               구독(EKF 입력 raw, 떨림 — 레거시/롤백).
#   /ball/map_point            (PointStamped, map)              → ball
#   /robot_state               (std_msgs/String)                → fallen
#   /strategy/state            (StrategyState)                  → role, phase, want_ball
#
# [발행]
#   /team_comm/state  (TeamComm)        자기+팀메이트 전체 + owner 선출 결과
#   /team_comm/debug  (std_msgs/String) 사람이 읽는 요약(echo 검증용) — mode/사유 포함
#   /team_comm/markers(MarkerArray)     RViz: 팀메이트 위치/번호/owner + 선출사유 표시
#
# [파라미터]
#   team_number/player_number  (int)
#   team_port_base   (int,  기본 10000)  실제 포트 = base + team_number
#   bind_address     (str,  기본 0.0.0.0)
#   broadcast_address(str,  기본 255.255.255.255)
#   send_rate_hz     (float,기본 5.0)
#   teammate_timeout_sec (float, 기본 2.0)  이 시간 무소식이면 stale(끊김/낙상)
#   owner_select_mode (str, 기본 'zone_backup')  zone_backup | distance | cost
#   pose_source      (str, 기본 'tf')      tf(map→base_link, EKF 융합) | topic(레거시)
#   base_frame       (str, 기본 base_link) pose_source='tf' 룩업 대상 프레임
#   defense_line_x   (float, 기본 -0.30)  zone 경계 — strategy/role_assigner 와 동일값 유지
#   wing_split_y     (float, 기본  0.0)   B(y+)/C(y-) 분리선 — 〃
#   *_topic 들        (str)               수집 토픽 이름
#
# [검증 — Step1 은 동작(모터) 불변, 토픽/RViz 로만 확인]
#   ros2 topic echo /team_comm/debug   # owner=Px(사유) mode=... 와 멤버별 z(zone)플래그
#   ros2 topic echo /team_comm/state   # members[] + ball_owner_player/i_am_owner
#   RViz: /team_comm/markers — owner 노랑 강조 + 위에 사유 텍스트(in_zone/backup)
#   2~3대 띄워 한 zone 에 공 놓고:
#     · 그 zone 주인이 owner(in_zone) 인지
#     · 그 주인을 가려(공 안 보이게) 두면 옆 로봇이 owner(backup) 로 넘어가는지
#     · 한 대 넘어뜨리면 stale/fallen 으로 빠지고 owner 가 넘어가는지
# ==========================================================================
import math
import socket
import struct
import threading

import rclpy
from rclpy.node import Node
from rclpy.time import Time as RclpyTime
from tf2_ros import Buffer, TransformListener, TransformException

from std_msgs.msg import String, Header, ColorRGBA
from geometry_msgs.msg import (
    PoseWithCovarianceStamped, PointStamped, Point, Vector3)
from visualization_msgs.msg import Marker, MarkerArray

from humanoid_behavior_interfaces.msg import (
    StrategyState, TeammateState, TeamComm)

# ── 패킷 상수 ──
TC_MAGIC = b'KHTM'
TC_VERSION = 2                              # ★v1(44B)→v2(45B): ball_conf 추가
_TC_FMT = '<4s4B3fB3f2BfBIB'               # 끝에 B(ball_conf) 추가
_TC_SIZE = struct.calcsize(_TC_FMT)        # = 45

# ── 역할 enum (RoleAssignment.msg 상수와 동일하게 유지) ──
#   team_comm 는 RoleAssignment 메시지를 직접 import 하지 않고 int 만 다루므로,
#   zone 판정을 위해 여기 상수를 둔다. RoleAssignment.msg / role_assigner_node.py /
#   strategy_fsm_node._raw_in_zone 과 ★값이 어긋나면 owner 선출이 망가진다 — 동기 유지.
ROLE_NONE = 0
ROLE_GOALKEEPER = 1
ROLE_A_CENTER = 2
ROLE_B_WING_POS = 3
ROLE_C_WING_NEG = 4
ROLE_B_ATTACK = 5
ROLE_STRIKER_ROAM = 6
ROLE_SUPPORTER = 7

# 허용 owner 선출 모드
_VALID_MODES = ('zone_backup', 'distance', 'cost')

# ── FSM strategy_phase 문자열 ↔ 코드(TeammateState.PHASE_*) ──
_PHASE_NO_OWNER = getattr(TeammateState, 'PHASE_NO_OWNER', 9)
_PHASE_BALL_SEARCH = getattr(TeammateState, 'PHASE_BALL_SEARCH', 10)
_PHASE_TO_CODE = {
    'IDLE': TeammateState.PHASE_IDLE,
    'POSITION': TeammateState.PHASE_POSITION,
    'POSITION_DONE': TeammateState.PHASE_POSITION_DONE,
    'CHASE': TeammateState.PHASE_CHASE,
    'SUPPORT': TeammateState.PHASE_SUPPORT,
    'STOP': TeammateState.PHASE_STOP,
    'APPROACH': TeammateState.PHASE_APPROACH,
    'ALIGN_KICK': TeammateState.PHASE_ALIGN_KICK,
    'SETPLAY_STOP': TeammateState.PHASE_STOP,
    'SETPLAY_MOVE': TeammateState.PHASE_POSITION,
    'SETPLAY_OUTKICK': TeammateState.PHASE_POSITION,
    'SETPLAY_APPROACH': TeammateState.PHASE_APPROACH,
    'NO_OWNER': _PHASE_NO_OWNER,
    'BALL_SEARCH': _PHASE_BALL_SEARCH,
}
_CODE_TO_PHASE = {v: k for k, v in _PHASE_TO_CODE.items()}
# "공을 잡으러 가는 중"으로 보는 단계(want_ball=1)
_WANT_BALL_PHASES = {
    TeammateState.PHASE_CHASE,
    TeammateState.PHASE_APPROACH,
    TeammateState.PHASE_ALIGN_KICK,
}


class TeamCommNode(Node):
    def __init__(self):
        super().__init__('team_comm')

        gp = self.declare_parameter   # 짧게 쓰기 위한 별칭

        # ── 파라미터 ──
        self.team_number = int(gp('team_number', 35).value)
        self.player_number = int(gp('player_number', 1).value)
        self.port_base = int(gp('team_port_base', 10000).value)
        self.bind_address = str(gp('bind_address', '0.0.0.0').value)
        self.broadcast_address = str(gp('broadcast_address', '255.255.255.255').value)
        self.send_rate_hz = float(gp('send_rate_hz', 5.0).value)
        self.teammate_timeout = float(gp('teammate_timeout_sec', 2.0).value)

        # owner 선출 모드 + zone 경계(zone_backup 에서 사용)
        mode = str(gp('owner_select_mode', 'zone_backup').value)
        if mode not in _VALID_MODES:
            self.get_logger().warn(
                f"owner_select_mode='{mode}' 인식 불가 → 'zone_backup' 사용 "
                f"(허용: {_VALID_MODES})")
            mode = 'zone_backup'
        self.owner_select_mode = mode
        # zone 경계는 strategy_fsm/role_assigner 와 ★같은 값으로 유지해야 한다.
        self.defense_line_x = float(gp('defense_line_x', -0.30).value)
        self.wing_split_y = float(gp('wing_split_y', 0.0).value)

        # ── 자기 pose 소스 (★EKF 융합 일치 — 제어기와 같은 map→base_link TF) ──
        #   'tf'(기본)    : map→base_frame TF 룩업. pose_goal_controller/ball_follow_nav
        #                   과 ★동일 소스(EKF 융합, 부드러움). 모니터=로봇 실제 pose 일치,
        #                   ball_dist/owner 떨림 제거.
        #   'topic'(레거시): pose_topic 구독(=/localization/vision_pose, EKF 입력 raw).
        #                   랜드마크 재검출마다 튄다 → 비추천. 롤백/디버그용.
        psrc = str(gp('pose_source', 'tf').value)
        if psrc not in ('tf', 'topic'):
            self.get_logger().warn(
                f"pose_source='{psrc}' 인식 불가 → 'tf' 사용 (허용: tf | topic)")
            psrc = 'tf'
        self.pose_source = psrc
        self.base_frame = str(gp('base_frame', 'base_link').value)

        self.pose_topic = str(gp('pose_topic', '/localization/vision_pose').value)
        self.ball_topic = str(gp('ball_topic', '/ball/map_point').value)
        self.robot_state_topic = str(gp('robot_state_topic', '/robot_state').value)
        self.strategy_state_topic = str(gp('strategy_state_topic', '/strategy/state').value)
        self.out_topic = str(gp('out_topic', '/team_comm/state').value)
        self.debug_topic = str(gp('debug_topic', '/team_comm/debug').value)
        self.marker_topic = str(gp('marker_topic', '/team_comm/markers').value)
        self.map_frame = str(gp('map_frame', 'map').value)

        self.port = self.port_base + self.team_number

        # ── 최신값 캐시(콜백 갱신 / 송신·발행 타이머가 읽음) ──
        self._pose = None         # (x, y, yaw) map, m/rad
        self._ball = None         # (x, y) map, m
        self._ball_stamp = None   # 마지막 공 수신시각(rclpy.Time)
        self._fallen = False
        self._role = 0
        self._phase_code = TeammateState.PHASE_UNKNOWN
        self._seq = 0
        # 팀메이트 캐시: player_number → dict(필드..., 'recv': rclpy.Time)
        self._mates = {}
        self._lock = threading.Lock()
        # owner 전환 로그용(값이 바뀔 때만 한 줄 찍기)
        self._prev_owner_log = None

        # ── 구독 ──
        #   pose 는 소스에 따라: 'tf' 면 아래 TF 룩업, 'topic' 이면 여기서 구독.
        if self.pose_source == 'topic':
            self.create_subscription(
                PoseWithCovarianceStamped, self.pose_topic, self._cb_pose, 10)
        self.create_subscription(PointStamped, self.ball_topic, self._cb_ball, 10)
        self.create_subscription(String, self.robot_state_topic, self._cb_state, 10)
        self.create_subscription(
            StrategyState, self.strategy_state_topic, self._cb_strategy, 10)

        # ── TF (pose_source='tf' — map→base_link 룩업용) ──
        #   EKF(map→odom) + walk_odometry(odom→base_link) 합성 = 융합 pose. 제어기와 동일.
        self._tf_buffer = None
        self._tf_listener = None
        if self.pose_source == 'tf':
            self._tf_buffer = Buffer()
            self._tf_listener = TransformListener(self._tf_buffer, self)

        # ── 발행 ──
        self._out_pub = self.create_publisher(TeamComm, self.out_topic, 10)
        self._debug_pub = self.create_publisher(String, self.debug_topic, 10)
        self._marker_pub = self.create_publisher(MarkerArray, self.marker_topic, 10)

        # ── 송신 소켓(broadcast) ──
        self._tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self._tx.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # ── 수신 소켓 + 스레드 ──
        self._rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self._rx.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._rx.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self._rx.bind((self.bind_address, self.port))
        self._rx.settimeout(0.5)
        self._running = True
        self._rx_thread = threading.Thread(target=self._rx_loop, daemon=True)
        self._rx_thread.start()

        # ── 송신/발행 타이머(동일 주기) ──
        rate = self.send_rate_hz if self.send_rate_hz > 0.0 else 5.0
        self._timer = self.create_timer(1.0 / rate, self._on_tick)

        self.get_logger().info(
            f"team_comm 시작 — team={self.team_number} player={self.player_number} "
            f"port={self.port} @ {rate:.1f}Hz timeout={self.teammate_timeout}s "
            f"owner_mode={self.owner_select_mode} "
            f"pose_src={self.pose_source}(base={self.base_frame}) "
            f"zone(dl={self.defense_line_x}, wy={self.wing_split_y})")

    # ======================================================================
    #  구독 콜백
    # ======================================================================
    def _cb_pose(self, msg: PoseWithCovarianceStamped):
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        yaw = self._yaw_from_quat(q.x, q.y, q.z, q.w)
        with self._lock:
            self._pose = (p.x, p.y, yaw)

    def _cb_ball(self, msg: PointStamped):
        with self._lock:
            self._ball = (msg.point.x, msg.point.y)
            self._ball_stamp = self.get_clock().now()

    def _cb_state(self, msg: String):
        # NORMAL 만 정상, 그 외(PROTECT/FALLEN/STANDING_UP/RECOVERING/STANDUP_FAILED)는 넘어짐.
        with self._lock:
            self._fallen = (msg.data != 'NORMAL')

    def _cb_strategy(self, msg: StrategyState):
        code = _PHASE_TO_CODE.get(msg.strategy_phase, TeammateState.PHASE_UNKNOWN)
        with self._lock:
            self._role = int(msg.role.role)
            self._phase_code = code

    def _lookup_tf_pose(self):
        """map→base_frame TF 룩업 → (x, y, yaw) | None(실패 시).

        ★제어기(pose_goal_controller/ball_follow_nav)와 동일한 EKF 융합 pose 소스.
        RclpyTime() = 가장 최신 TF. EKF/TF 미기동이면 None → pose_valid=false 로
        나가고(좌표 0), TF 올라오면 자동 복구.
        """
        if self._tf_buffer is None:
            return None
        try:
            tf = self._tf_buffer.lookup_transform(
                self.map_frame, self.base_frame, RclpyTime())
        except TransformException:
            return None
        t = tf.transform.translation
        q = tf.transform.rotation
        yaw = self._yaw_from_quat(q.x, q.y, q.z, q.w)
        return (t.x, t.y, yaw)

    # ======================================================================
    #  수신 루프(별도 스레드)
    # ======================================================================
    def _rx_loop(self):
        while rclpy.ok() and self._running:
            try:
                data, _addr = self._rx.recvfrom(1024)
            except socket.timeout:
                continue
            except OSError:
                break
            except Exception:   # noqa: BLE001
                continue

            if len(data) != _TC_SIZE or data[0:4] != TC_MAGIC:
                continue   # 우리 포맷/크기 아님(타 팀/노이즈/구버전) → 무시
            if data[4] != TC_VERSION:
                # 크기는 같은데 버전만 다른 경우(레이아웃 변경 위험) → 오파싱 방지.
                self.get_logger().warn(
                    f"TC_VERSION 불일치 rx={data[4]} 기대={TC_VERSION} "
                    f"— 전 로봇 team_comm 재배포 확인",
                    throttle_duration_sec=5.0)
                continue
            try:
                fields = self._unpack(data)
            except struct.error:
                continue
            # 같은 팀 번호만, 그리고 내 패킷(=내 broadcast 가 되돌아온 것)은 제외.
            if fields['team'] != self.team_number:
                continue
            if fields['player'] == self.player_number:
                continue
            fields['recv'] = self.get_clock().now()
            with self._lock:
                self._mates[fields['player']] = fields

    # ======================================================================
    #  송신 + 발행 타이머
    # ======================================================================
    def _on_tick(self):
        now = self.get_clock().now()

        # ── 자기 pose: 'tf' 면 map→base_link 룩업(EKF 융합), 'topic' 이면 콜백 캐시 ──
        if self.pose_source == 'tf':
            pose = self._lookup_tf_pose()        # (x, y, yaw) | None(TF 미수신)
        else:
            with self._lock:
                pose = self._pose

        # ── 자기 상태 스냅샷(공/낙상/역할/시퀀스/팀메이트) ──
        with self._lock:
            ball = self._ball
            ball_stamp = self._ball_stamp
            fallen = self._fallen
            role = self._role
            phase = self._phase_code
            self._seq = (self._seq + 1) & 0xFFFFFFFF
            seq = self._seq
            mates = dict(self._mates)   # 얕은 복사(발행용 스냅샷)

        # 공 신선도/거리 계산
        ball_valid = False
        ball_x = ball_y = 0.0
        ball_age = -1.0
        ball_dist = -1.0
        if ball is not None and ball_stamp is not None:
            ball_x, ball_y = ball
            ball_age = (now - ball_stamp).nanoseconds * 1e-9
            ball_valid = ball_age <= self.teammate_timeout
            if pose is not None:
                ball_dist = math.hypot(ball_x - pose[0], ball_y - pose[1])

        # 공 신뢰도(★예약 필드, placeholder) — 지금은 보면 1.0, 못 보면 0.0.
        #   TODO: 추후 YOLO conf / detection_memory 안정도 토픽을 구독해 실제값으로.
        ball_conf = 1.0 if ball_valid else 0.0

        pose_valid = pose is not None
        px, py, pth = pose if pose is not None else (0.0, 0.0, 0.0)
        want_ball = phase in _WANT_BALL_PHASES

        # ── 패킷 송신 ──
        conf_byte = int(round(ball_conf * 255.0)) & 0xFF
        packet = struct.pack(
            _TC_FMT, TC_MAGIC, TC_VERSION,
            self.player_number & 0xFF, self.team_number & 0xFF, 1 if fallen else 0,
            float(px), float(py), float(pth),
            1 if ball_valid else 0, float(ball_x), float(ball_y), float(ball_age),
            role & 0xFF, phase & 0xFF, float(ball_dist), 1 if want_ball else 0,
            seq, conf_byte)
        try:
            self._tx.sendto(packet, (self.broadcast_address, self.port))
        except OSError as e:
            self.get_logger().error(
                f"송신 실패({self.broadcast_address}:{self.port}) — {e}",
                throttle_duration_sec=2.0)

        # ── 자기 자신 TeammateState 구성 ──
        self_state = self._make_state(
            player=self.player_number, fallen=fallen,
            pose_valid=pose_valid, px=px, py=py, pth=pth,
            ball_valid=ball_valid, bx=ball_x, by=ball_y, ball_age=ball_age,
            ball_conf=ball_conf, role=role, phase=phase, ball_dist=ball_dist,
            want_ball=want_ball, seq=seq, age_sec=0.0, stale=False)

        # ── 팀메이트 TeammateState 구성(stale 판정 포함) ──
        members = [self_state]
        for pnum, f in mates.items():
            age = (now - f['recv']).nanoseconds * 1e-9
            stale = age > self.teammate_timeout
            members.append(self._make_state(
                player=pnum, fallen=bool(f['fallen']),
                pose_valid=bool(f['pose_valid']),
                px=f['pose_x'], py=f['pose_y'], pth=f['pose_theta'],
                ball_valid=bool(f['ball_valid']),
                bx=f['ball_x'], by=f['ball_y'], ball_age=f['ball_age'],
                ball_conf=float(f['ball_conf']),
                role=f['role'], phase=f['phase'], ball_dist=f['ball_dist'],
                want_ball=bool(f['want_ball']), seq=f['seq'],
                age_sec=age, stale=stale))

        # ── owner 선출(모드별) ──
        owner, owner_reason = self._select_owner(members)
        active = sum(1 for m in members if (not m.stale) and (not m.fallen))

        # owner 가 바뀔 때만 한 줄 로그(스팸 방지)
        if owner != self._prev_owner_log:
            self.get_logger().info(
                f"owner P{self._prev_owner_log}→P{owner} "
                f"({owner_reason}, mode={self.owner_select_mode})")
            self._prev_owner_log = owner

        # ── TeamComm 발행 ──
        out = TeamComm()
        out.header = Header()
        out.header.stamp = now.to_msg()
        out.header.frame_id = self.map_frame
        out.my_player_number = self.player_number
        out.team_number = self.team_number
        out.members = members
        out.ball_owner_player = owner
        out.i_am_owner = (owner == self.player_number)
        out.active_count = active
        self._out_pub.publish(out)

        # ── 디버그 String + 마커 ──
        self._publish_debug(members, owner, owner_reason, active)
        self._publish_markers(members, owner, owner_reason, now)

    # ======================================================================
    #  owner 선출
    # ======================================================================
    def _ball_in_role_zone(self, role, bx, by):
        """공(bx,by, map)이 해당 role 의 책임 zone 안인지 (True/False).

        ★strategy_fsm_node._raw_in_zone 과 동일 규칙(부등호/경계값 1:1 일치)을
        유지해야 한다. 한쪽만 바꾸면 통신 owner 와 zone 폴백이 어긋난다.
        """
        dl = self.defense_line_x
        wy = self.wing_split_y
        if role == ROLE_STRIKER_ROAM:
            return True                         # 전구역
        if role == ROLE_A_CENTER:
            return bx < dl                      # 수비 third
        if role == ROLE_B_ATTACK:
            return bx >= dl                     # (3대) 수비 third 제외 전부
        if role == ROLE_B_WING_POS:
            return (bx < dl) and (by >= wy)     # 수비(우리진영) 좌 — 윙백
        if role == ROLE_C_WING_NEG:
            return (bx < dl) and (by < wy)      # 수비(우리진영) 우 — 윙백
        return False                            # GOALKEEPER/SUPPORTER/NONE

    def _select_owner(self, members):
        """현재 멤버 스냅샷으로 공 owner(선수번호)와 사유를 결정.

        ★무상태 순수 함수 — 모든 로봇이 같은 입력이면 같은 결론(분산 일관성).
          cross-tick 히스테리시스(전 owner 기억)는 로봇별로 desync 위험이 있어
          여기선 두지 않는다. 경계 떨림/순간 전환은 strategy_fsm 의
          ownership_cooldown 기반 소비측 래치가 흡수한다(역할 분리).

        반환: (owner_player:int, reason:str)
          reason ∈ {'none','in_zone','backup','distance'}
        """
        # 후보 = 활성(stale/fallen 아님) + 키퍼 아님 + 지금 공 보는 중.
        #   키퍼 제외: 키퍼는 골을 지킨다 — 백업 체이서로 끌려나가지 않음.
        #   ball_valid 요구: 1.9초 전에 본 공으로 owner 가 되는 일 방지(현재 시야만).
        cand = [
            m for m in members
            if (not m.stale) and (not m.fallen)
            and (m.role != ROLE_GOALKEEPER)
            and m.ball_valid and (m.ball_dist >= 0.0)
        ]
        if not cand:
            return 0, 'none'                    # owner 후보 없음(전원 공 분실 여부는 FSM 이 판정)

        mode = self.owner_select_mode

        if mode == 'distance':
            # zone 무시: 공거리 최소(동점 시 선수번호).
            best = min(cand, key=lambda m: (m.ball_dist, m.player_number))
            return best.player_number, 'distance'

        if mode == 'cost':
            # ── ③ 풀세트 자리(미구현) — 안전하게 zone_backup 으로 폴백 ──
            #   향후: cost = ball_dist + k*(zone 밖 벗어난 거리),
            #         합의 이상치(유령 공) 배제, 전환 히스테리시스 추가.
            #         그때 ball_conf(예약 필드)를 합의 가중치로 사용.
            self.get_logger().warn(
                "owner_select_mode='cost' 미구현 — zone_backup 으로 동작",
                throttle_duration_sec=10.0)

        # ── zone_backup(기본) ──
        #   tier1: 자기 zone 안에서 공 보는 로봇(in-zone) — 정상적으로 1명.
        #   tier2: in-zone 이 없으면(zone 주인이 시야상실/낙상) zone 밖에서 보는
        #          로봇이 백업으로 채운다 → 0-체이서 방지.
        #   각 tier 내: 공거리 최소(동점 시 선수번호) → 전 로봇 동일 결론.
        in_zone = [
            m for m in cand
            if self._ball_in_role_zone(m.role, m.ball_x, m.ball_y)
        ]
        if in_zone:
            best = min(in_zone, key=lambda m: (m.ball_dist, m.player_number))
            return best.player_number, 'in_zone'
        best = min(cand, key=lambda m: (m.ball_dist, m.player_number))
        return best.player_number, 'backup'

    # ======================================================================
    #  헬퍼
    # ======================================================================
    def _make_state(self, player, fallen, pose_valid, px, py, pth,
                    ball_valid, bx, by, ball_age, ball_conf, role, phase,
                    ball_dist, want_ball, seq, age_sec, stale) -> TeammateState:
        """필드들로 TeammateState 메시지를 채운다."""
        s = TeammateState()
        s.header = Header()
        s.header.stamp = self.get_clock().now().to_msg()
        s.header.frame_id = self.map_frame
        s.player_number = int(player) & 0xFF
        s.fallen = bool(fallen)
        s.pose_valid = bool(pose_valid)
        s.pose_x = float(px)
        s.pose_y = float(py)
        s.pose_theta = float(pth)
        s.ball_valid = bool(ball_valid)
        s.ball_x = float(bx)
        s.ball_y = float(by)
        s.ball_age = float(ball_age)
        s.ball_conf = float(ball_conf)
        s.role = int(role) & 0xFF
        s.phase = int(phase) & 0xFF
        s.ball_dist = float(ball_dist)
        s.want_ball = bool(want_ball)
        s.seq = int(seq) & 0xFFFFFFFF
        s.age_sec = float(age_sec)
        s.stale = bool(stale)
        return s

    @staticmethod
    def _unpack(data: bytes) -> dict:
        (_magic, _ver, player, team, fallen,
         px, py, pth, ball_valid, bx, by, ball_age,
         role, phase, ball_dist, want_ball, seq, conf_byte) = struct.unpack(
            _TC_FMT, data)
        return {
            'player': player, 'team': team, 'fallen': fallen,
            'pose_valid': True,   # 송신측이 보낸 시점에 pose 값은 항상 들어있음
            'pose_x': px, 'pose_y': py, 'pose_theta': pth,
            'ball_valid': ball_valid, 'ball_x': bx, 'ball_y': by, 'ball_age': ball_age,
            'ball_conf': conf_byte / 255.0,
            'role': role, 'phase': phase, 'ball_dist': ball_dist,
            'want_ball': want_ball, 'seq': seq,
        }

    def _publish_debug(self, members, owner, owner_reason, active):
        parts = []
        for m in sorted(members, key=lambda x: x.player_number):
            tag = '*' if m.player_number == owner else ' '
            flags = []
            if m.stale:
                flags.append('STALE')
            if m.fallen:
                flags.append('FALL')
            # 자기 zone 안에서 공 보는 중이면 'z' (선출 사유 눈으로 확인용)
            if (m.ball_valid and m.role != ROLE_GOALKEEPER
                    and self._ball_in_role_zone(m.role, m.ball_x, m.ball_y)):
                flags.append('z')
            fl = (',' + ','.join(flags)) if flags else ''
            dist = 'NA' if m.ball_dist < 0 else f"{m.ball_dist:.2f}"
            parts.append(
                f"{tag}P{m.player_number}[{_CODE_TO_PHASE.get(m.phase, '?')}"
                f" d={dist}{fl}]")
        msg = String()
        msg.data = (
            f"owner=P{owner}({owner_reason}) mode={self.owner_select_mode} "
            f"active={active} | " + ' '.join(parts))
        self._debug_pub.publish(msg)
        self.get_logger().info(msg.data, throttle_duration_sec=2.0)

    def _publish_markers(self, members, owner, owner_reason, now):
        """팀메이트 위치를 map 에 구 + 번호로 표시. owner 는 강조 + 선출사유 텍스트."""
        arr = MarkerArray()
        stamp = now.to_msg()
        for m in members:
            if not m.pose_valid:
                continue
            is_owner = (m.player_number == owner)
            # 본체 구(stale/fallen 은 회색)
            sph = Marker()
            sph.header.stamp = stamp
            sph.header.frame_id = self.map_frame
            sph.ns = 'team_mates'
            sph.id = int(m.player_number)
            sph.type = Marker.SPHERE
            sph.action = Marker.ADD
            sph.pose.position = Point(x=m.pose_x, y=m.pose_y, z=0.15)
            sph.pose.orientation.w = 1.0
            sph.scale = Vector3(x=0.18, y=0.18, z=0.18)
            if m.stale or m.fallen:
                sph.color = ColorRGBA(r=0.5, g=0.5, b=0.5, a=0.6)
            elif is_owner:
                sph.color = ColorRGBA(r=1.0, g=0.85, b=0.1, a=0.95)   # owner=노랑
            else:
                sph.color = ColorRGBA(r=0.1, g=0.6, b=1.0, a=0.9)     # 일반=파랑
            sph.lifetime = self._dur(self.teammate_timeout * 2.0)
            arr.markers.append(sph)
            # 번호 텍스트
            txt = Marker()
            txt.header.stamp = stamp
            txt.header.frame_id = self.map_frame
            txt.ns = 'team_labels'
            txt.id = int(m.player_number)
            txt.type = Marker.TEXT_VIEW_FACING
            txt.action = Marker.ADD
            txt.pose.position = Point(x=m.pose_x, y=m.pose_y, z=0.40)
            txt.pose.orientation.w = 1.0
            txt.scale.z = 0.18
            txt.color = ColorRGBA(r=1.0, g=1.0, b=1.0, a=0.95)
            txt.text = f"P{m.player_number}"
            txt.lifetime = self._dur(self.teammate_timeout * 2.0)
            arr.markers.append(txt)

        # owner 선출 사유 텍스트(owner 머리 위) — in_zone/backup/distance/none
        owner_m = next(
            (m for m in members
             if m.player_number == owner and m.pose_valid), None)
        rt = Marker()
        rt.header.stamp = stamp
        rt.header.frame_id = self.map_frame
        rt.ns = 'team_owner'
        rt.id = 0
        rt.type = Marker.TEXT_VIEW_FACING
        if owner_m is not None:
            rt.action = Marker.ADD
            rt.pose.position = Point(x=owner_m.pose_x, y=owner_m.pose_y, z=0.60)
            rt.pose.orientation.w = 1.0
            rt.scale.z = 0.15
            rt.color = ColorRGBA(r=1.0, g=0.85, b=0.1, a=1.0)
            rt.text = f"OWNER[{owner_reason}]"
            rt.lifetime = self._dur(self.teammate_timeout * 2.0)
        else:
            rt.action = Marker.DELETE       # owner 없음(전원 공 분실) → 텍스트 제거
        arr.markers.append(rt)

        self._marker_pub.publish(arr)

    @staticmethod
    def _dur(sec):
        from builtin_interfaces.msg import Duration
        d = Duration()
        d.sec = int(sec)
        d.nanosec = int((sec - int(sec)) * 1e9)
        return d

    @staticmethod
    def _yaw_from_quat(x, y, z, w):
        siny = 2.0 * (w * z + x * y)
        cosy = 1.0 - 2.0 * (y * y + z * z)
        return math.atan2(siny, cosy)

    # ----------------------------------------------------------------------
    def destroy_node(self):
        self._running = False
        for s in (self._rx, self._tx):
            try:
                s.close()
            except Exception:   # noqa: BLE001
                pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = TeamCommNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
