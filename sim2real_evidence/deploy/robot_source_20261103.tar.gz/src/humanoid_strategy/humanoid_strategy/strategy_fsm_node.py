# -*- coding: utf-8 -*-
# =============================================================================
#  strategy_fsm_node.py   (전략 레이어 — READY/SUPPORT 포지셔닝 + PLAYING owner)
#
#  게임 상태별로 "어떤 기존 제어기를 켤지"를 결정하는 상위 오케스트레이터.
#   - READY  : 역할별 킥오프 위치로 /pose_goal 발행(pose_goal_controller 가 걸어감).
#   - PLAYING:
#       · 공 소유(zone) 판정 → 내 zone 의 공이면 owner.
#       · owner  : Phase2(ball_follow) 접근 → ARRIVED → Phase3(visual_servo) 정렬+킥.
#       · 비소유 : 역할 home 으로 /pose_goal 이동, 공 바라보기.
#       · 키퍼/공없음 : home 유지(키퍼 전용 동작은 step3b 에서).
#
#  ★ 새 제어기를 만들지 않는다. 기존 pose_goal_controller(~/enable) /
#    ball_follow_nav(~/enable) / visual_servo_kick(~/enable) 를 켜고 끄는 결정만 한다.
#    ※Nav2 제거 — READY/SUPPORT 도 pose_goal_controller 로 통일(RPP 채터 제거).
#
#  [공 소유 — team_comm owner 소비 + zone 폴백  ★Step2]
#    owner 판정 소스를 arbitration_mode 로 고른다(경기 중 롤백 스위치 겸용):
#      · 'team_comm'(기본) : /team_comm/state 의 ball_owner_player 를 본다.
#          team_comm 이 'zone 우선 + 백업' election 을 이미 수행(누가 공을 쫓을지
#          한 곳에서 단일 결정). i_am_owner 면 chase. → 0-체이서/경계 겹침 해소.
#          ★통신이 stale(team_comm_stale_sec 초과) 이면 자동으로 zone 폴백.
#      · 'zone_only' : 통신 완전 무시, 아래 zone 규칙만(=Step2 이전 동작). 롤백용.
#    zone 규칙(폴백/zone_only 공용 — team_comm 의 zone 판정과 ★동일하게 유지):
#      A_CENTER   : 수비 third (x < defense_line)  — 공 오면 전방 클리어
#      B_WING_POS : 공격영역(x>=defense_line) 의 y+ 절반
#      C_WING_NEG : 〃 y- 절반
#      B_ATTACK   : (3대) x >= defense_line 전부
#      STRIKER    : (2대 이하) 전구역
#    경계 떨림은 시간 디바운스(ownership_cooldown_s, 폴백 경로에서).
#    ※owner 라도 내 시야에 공이 없으면(_fresh_ball None) chase 불가 → POSITION.
#      ball_follow 가 내 공 인식을 쓰기 때문. 이땐 다음 election 에서 owner 가 넘어간다.
#    ※전원 공 분실(owner 없음)은 BALL_SEARCH/NO_OWNER phase 로 분리한다.
#
#  [owner 오케스트레이션 — 핸드오프는 ball_follow 의 ARRIVED 신호로]
#    APPROACH   : ball_follow ON, visual_servo OFF.
#      └ /ball_follow/status == 'ARRIVED' →
#    ALIGN_KICK : ball_follow OFF(=nav 침묵), visual_servo ON(정밀 정렬 + /kick_trigger).
#      └ /kick_done → kick_cooldown 동안 APPROACH 로 복귀(공 위치 갱신 후 재평가).
#    킥 방향은 공격 골대(+X). ball_follow/visual_servo 의 target_goal 기본값(1.95,0)이
#    이미 +X 라 여기서 건드리지 않는다(우리 골대 -X 고정 컨벤션 덕분).
#
#  [세트플레이 게이트 — PLAYING 중 set_play(쓰로인/프리킥/코너/골킥/페널티)]
#    ★별도 노드 대신 FSM 에 통합. set_play 포지셔닝은 "메커니즘"이 아니라 "결정"
#      (어디 서야 하나)이라 READY 포지셔닝과 동급 → _decide() 안에 둔다.
#    PLAYING 인데 set_play != NONE 이면(=공이 인플레이 아님) 일반 추격을 가로채고
#    _decide_set_play() 로 보낸다. 그 외 상태/일반 PLAYING 은 무손상.
#      STOP : set_play 감지 직후. "일단 정지"(IDLE 반환 → 기존 정지 경로). 최소
#             정지홀드(setplay_min_stop_sec) + secondary_time 클럭이 떠야 다음 단계.
#             (secondary 가 안 채워지는 GC 대비 setplay_secondary_fallback_sec 폴백)
#      MOVE : 역할/주도권별 목적지. 정책:
#             · 키퍼            : 골 앞 home 유지 + 공 바라봄(접근 안 함).
#             · 상대 주도/비키커: 전원 공 중심 clear_radius 밖으로(거리확보). home 이
#                                 원 안이면 공 반대쪽(우리 골 방향)으로 밀어냄.
#             · 우리 주도 + 키커(★out_kick 통합, setplay_taker_approach=true):
#                 정지 대기 대신 공까지 접근한다. 공이 라인 근처(out_kick_band_m 이내)면
#                 라인 바깥 목표점으로 이동해 경기장 안쪽을 바라보고(POSITION=pose_goal,
#                 SETTLE→ARRIVED 로 최종 yaw 정렬), 아니면 ball_follow 로 직진 접근(CHASE).
#                 킥은 세트플레이 중 억제 → set_play 가 NONE(GC 인플레이 선언)으로 풀리는
#                 순간 일반 CHASE 로 복귀하며 visual_servo 가 킥한다("휘슬 없이 GC 신호로만 킥").
#                 setplay_taker_approach=false 면 기존 공 뒤 standoff 대기(롤백).
#    set_play 가 NONE 으로 풀리면 onset 리셋 → 다음 tick 부터 일반 PLAYING 복귀.
#    setplay_enable=false 로 끄면 set_play 무시(=통합 이전 동작). 경기 중 롤백 스위치.
#
#  [안전 게이트] robot_state != NORMAL(낙상/기립) 또는 is_active=false → 전부 OFF.
#    SET/INITIAL/FINISHED 에선 game_stop_lock 이 정지시키고, 이 노드는 모두 OFF.
#
#  [twist_mux 경로] ball_follow→pose_goal_controller→cmd_vel_nav(20),
#    visual_servo→cmd_vel_behavior(10). owner 일 땐 ball_follow 가 pose 를 몰고,
#    POSITION 일 땐 strategy 가 직접 /pose_goal 로 몬다(둘은 mode 배타 → nav 슬롯 안 다툼).
#    ALIGN_KICK 에선 ball_follow OFF → pose_ctrl 침묵 → visual_servo 가 behavior 로 구동.
#
#  [출력]
#    - /pose_goal (PoseStamped) : READY/SUPPORT 위치 이동(pose_goal_controller 가 추종).
#    - SetBool ~/enable 호출 : pose_ctrl(정지용) / ball_follow / visual_servo on/off.
#    - /strategy/state (StrategyState) : 현재 단계/역할/공.
#    - /strategy/target_marker (MarkerArray) : 목표 화살표 + 공 owner 표시. latched.
#
#  [검증]
#    드라이런: /game_state PLAYING + /ball/map_point 수동 발행 → /strategy/state 의
#             strategy_phase(SUPPORT/CHASE_APPROACH/CHASE_KICK) 와 enable 서비스 호출 로그 확인.
#    실주행 : control+localization+game_controller+visual_servo+ball_follow+pose_goal+전략.
#             (Nav2 불필요)
# =============================================================================

import math

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from std_msgs.msg import String, Bool, ColorRGBA, Header, Float32
from std_srvs.srv import SetBool
from geometry_msgs.msg import PoseStamped, PointStamped, Point, Quaternion, Twist
from visualization_msgs.msg import Marker, MarkerArray

from humanoid_behavior_interfaces.msg import (
    GameState, RoleAssignment, StrategyState, TeamComm)


ROBOT_STATE_NORMAL = "NORMAL"   # fall_manager STATE_NORMAL 과 동일

# 세트플레이 좌표 계산의 퇴화(0 으로 나누기) 판정용 미세거리[m].
#   · 공이 골대에 거의 붙거나(standoff 기준선 소멸), home 이 공과 거의 겹칠 때 폴백.
_SETPLAY_EPS = 0.05


class StrategyFsm(Node):
    def __init__(self):
        super().__init__("strategy_fsm_node")
        gp = self.declare_parameter

        self.player_number = int(gp("player_number", 1).value)

        # ── READY 좌표 12개(우리/상대 킥오프 × 역할) ──
        #   기본값은 yaml 폴백. S-Field(9x6)용으로 연습장 포메이션 ×2.3077 스케일.
        #   (전원 자기 진영 -x, 센터서클 r=0.75 밖 — 규칙 제약 확인 완료)
        #   ※[수정] b/c_wing(양쪽 공격수)은 킥오프 준비 시 너무 전방이라
        #     우리 진영으로 약 0.7m 당김(우리킥 -1.75, 상대킥 -2.00). yaml 값과 일치.
        ready_defaults = {
            "ready_ourkick_keeper": [-3.92, 0.0],
            "ready_ourkick_a_center": [-0.92, 0.0],
            "ready_ourkick_b_wing": [-1.75, 1.27],
            "ready_ourkick_c_wing": [-1.75, -1.27],
            "ready_ourkick_b_attack": [-1.04, 0.92],
            "ready_ourkick_striker": [-0.92, 0.0],
            "ready_oppkick_keeper": [-3.92, 0.0],
            "ready_oppkick_a_center": [-1.27, 0.0],
            "ready_oppkick_b_wing": [-2.00, 1.27],
            "ready_oppkick_c_wing": [-2.00, -1.27],
            "ready_oppkick_b_attack": [-1.27, 0.92],
            "ready_oppkick_striker": [-1.27, 0.0],
        }
        self._ready = {k: self._xy(gp(k, v).value) for k, v in ready_defaults.items()}
        self.ready_yaw = math.radians(float(gp("ready_yaw_deg", 0.0).value))

        # ── zone 경계(공 소유 판정) ──
        self.defense_line_x = float(gp("defense_line_x", -0.70).value)
        self.wing_split_y = float(gp("wing_split_y", 0.0).value)
        self.ownership_cooldown = float(gp("ownership_cooldown_s", 0.5).value)

        # ── 세트플레이(set_play) 게이트 파라미터 ──
        # setplay_enable: False 면 set_play 무시(=통합 이전 동작). 경기 중 롤백 스위치.
        self.setplay_enable = bool(gp("setplay_enable", True).value)
        # 공격 골대 좌표(map). 키커 standoff 정렬 + 퇴화 시 우리 골 방향 기준.
        #   ★좌표계는 팀 상대다: 우리 골 = 항상 -x, 상대(공격) 골 = 항상 +x.
        #     재진입 시드(localization 의 sideline_reentry_pose)가 own_goal_sign=-1
        #     로 우리 골을 늘 -x 에 심으므로, 하프타임에 물리 사이드가 바뀌어도
        #     이 컨벤션은 그대로 유지된다. → attack_goal_x 는 4.5 고정이며 사이드
        #     배정에 따라 뒤집지 않는다(뒤집으면 공격/킥 방향이 반대가 됨).
        #     (다른 필드 프로파일 대응용 override 로만 파라미터를 남겨둔다.)
        self.attack_goal_x = float(gp("attack_goal_x", 4.5).value)
        self.attack_goal_y = float(gp("attack_goal_y", 0.0).value)
        # clear_radius: 비키커가 공에서 떨어져 있어야 하는 최소거리[m].
        #   ★ HSL 2026 규정의 프리킥 거리에 맞춰 set 할 것(기본 0.75 는 보수적 추정값).
        self.clear_radius = float(gp("clear_radius", 0.75).value)
        # taker_standoff: 우리 키커가 공 뒤(공격골 반대쪽)에서 멈추는 거리[m].
        self.taker_standoff = float(gp("taker_standoff", 0.40).value)
        # min_stop_sec: set_play 감지 후 최소 이만큼은 무조건 STOP 유지("일단 정지").
        self.setplay_min_stop_sec = float(gp("setplay_min_stop_sec", 1.0).value)
        # use_secondary_gate: True 면 secondary_time>0(준비 클럭 활성)일 때만 MOVE.
        self.setplay_use_secondary_gate = bool(
            gp("setplay_use_secondary_gate", True).value)
        # secondary_fallback_sec: 게이트 ON 이어도 이 시간 지나면 게이트 무시(영구정지 방지).
        self.setplay_secondary_fallback_sec = float(
            gp("setplay_secondary_fallback_sec", 3.0).value)

        # ── 세트플레이 taker 접근/아웃킥 파라미터 (★out_kick 통합) ──
        #   V1 out_kick_node / pnt_kick(=ball_follow_nav) 를 별도 노드로 띄우지 않고,
        #   "우리 주도 세트플레이에서 taker 는 정지 대기 대신 공까지 접근" 결정을 여기 통합.
        #   실제 이동/킥은 기존 컨트롤러(pose_goal_controller / ball_follow / visual_servo)가
        #   하고, strategy 가 단일 소유자로 그 목표·enable 만 준다(소유권 충돌 없음).
        #   ※킥은 세트플레이 중엔 억제(_run_owner) → set_play 가 NONE(GC 인플레이 선언)
        #     으로 풀리는 순간 일반 CHASE 로 복귀하며 그때 visual_servo 가 킥한다.
        # setplay_taker_approach: False 면 접근 안 하고 기존 taker standoff 대기(롤백 스위치).
        self.setplay_taker_approach = bool(gp("setplay_taker_approach", True).value)
        # 필드 반길이/반폭[m] (라인 좌표 = ±이 값). out_kick 라인거리 계산의 기준.
        #   S-Field(9x6): half_length=4.5, half_width=3.0. attack_goal_x 와 일치해야 자연스럽다.
        self.field_half_length_x = float(gp("field_half_length_x", 4.5).value)
        self.field_half_width_y = float(gp("field_half_width_y", 3.0).value)
        # out_kick_band_m: 공이 가장 가까운 라인에서 이 거리 이내면 "라인 근처"로 보고
        #   ball_follow 직진 접근(공 라인밖으로 차버릴 위험) 대신 라인 바깥 목표점 방식 사용.
        self.out_kick_band_m = float(gp("out_kick_band_m", 0.6).value)
        # outside_margin_m: 라인 바깥 방향으로 목표점을 둘 최소 거리[m] (V1 outside_margin_m).
        self.outside_margin_m = float(gp("outside_margin_m", 0.35).value)
        # ball_clearance_m: 공과 목표점 사이 최소 여유[m]. 최종 offset=max(margin, clearance).
        self.ball_clearance_m = float(gp("ball_clearance_m", 0.20).value)

        # ── owner 판정 소스 (★Step2 — team_comm 소비 + 롤백 스위치) ──
        #   'team_comm' : /team_comm/state 의 ball_owner_player 사용(통신 stale 시 zone 폴백).
        #   'zone_only' : 통신 무시, zone 규칙만(=Step2 이전 동작). 경기 중 문제 시 롤백.
        amode = str(gp("arbitration_mode", "team_comm").value)
        if amode not in ("team_comm", "zone_only"):
            self.get_logger().warn(
                f"arbitration_mode='{amode}' 인식 불가 → 'team_comm' 사용 "
                f"(허용: team_comm | zone_only)")
            amode = "team_comm"
        self.arbitration_mode = amode
        self.team_comm_state_topic = str(
            gp("team_comm_state_topic", "/team_comm/state").value)
        # team_comm 메시지가 이 시간 동안 안 오면 통신 끊김으로 보고 zone 폴백.
        self.team_comm_stale_sec = float(gp("team_comm_stale_sec", 1.0).value)

        # ── PLAYING 동작 ──
        self.ball_lost_timeout = float(gp("ball_lost_timeout_s", 1.0).value)
        self.kick_cooldown = float(gp("kick_cooldown_s", 1.0).value)
        self.post_kick_settle = max(
            0.0, float(gp("post_kick_settle_s", 3.0).value))
        self.playing_face_ball = bool(gp("playing_face_ball", True).value)
        self.ball_search_enable = bool(gp("ball_search_enable", True).value)
        self.ball_search_period = float(gp("ball_search_period_s", 4.0).value)
        self.ball_search_neck_pitch_deg = float(
            gp("ball_search_neck_pitch_deg", -25.0).value)
        self.ball_search_neck_second_pitch_deg = float(
            gp("ball_search_neck_second_pitch_deg", -45.0).value)
        self.ball_search_neck_yaw_min_deg = float(
            gp("ball_search_neck_yaw_min_deg", -90.0).value)
        self.ball_search_neck_yaw_max_deg = float(
            gp("ball_search_neck_yaw_max_deg", 90.0).value)
        self.ball_search_initial_scan_s = float(
            gp("ball_search_initial_scan_s", 3.0).value)
        self.ball_search_turn_speed_z = float(
            gp("ball_search_turn_speed_z", -1.5).value)
        self.ball_search_cmd_vel_topic = str(
            gp("ball_search_cmd_vel_topic", "cmd_vel_behavior").value)
        self.neck_yaw_cmd_topic = str(gp("neck_yaw_cmd_topic", "/neck/yaw_deg").value)
        self.neck_pitch_cmd_topic = str(
            gp("neck_pitch_cmd_topic", "/neck/pitch_deg").value)

        # ── pose controller 연동(Nav2 대체) ──
        # READY/SUPPORT 포지셔닝을 NavigateToPose 대신 /pose_goal 발행으로 한다.
        #   · 켜기: /pose_goal 발행 시 pose_goal_controller 가 auto_enable 로 켜짐.
        #   · 끄기(정지): pose_ctrl ~/enable(false) 직접 호출.
        self.pose_goal_topic = str(gp("pose_goal_topic", "/pose_goal").value)
        self.pose_state_topic = str(gp("pose_state_topic", "/pose_goal/state").value)
        self.pc_srv_name = str(
            gp("pose_ctrl_enable_srv", "/pose_goal_controller_node/enable").value)
        self.resend_threshold = float(gp("resend_threshold_m", 0.15).value)
        self.resend_yaw_threshold = math.radians(
            float(gp("resend_yaw_threshold_deg", 10.0).value))

        # ── 동작 ──
        self.publish_rate = float(gp("publish_rate_hz", 5.0).value)
        self.stale_timeout = float(gp("stale_timeout_sec", 2.0).value)
        self.robot_state_active_only = bool(gp("robot_state_active_only", True).value)

        # ── 토픽/서비스/프레임 ──
        self.map_frame = str(gp("map_frame", "map").value)
        self.state_topic = str(gp("state_topic", "/strategy/state").value)
        self.marker_topic = str(gp("target_marker_topic", "/strategy/target_marker").value)
        self.marker_ns = str(gp("marker_namespace", "strategy_fsm").value)
        self.ball_topic = str(gp("ball_point_topic", "/ball/map_point").value)
        self.bf_status_topic = str(gp("ball_follow_status_topic", "/ball_follow/status").value)
        self.vs_state_topic = str(gp("visual_servo_state_topic", "/visual_servo/state").value)
        self.kick_done_topic = str(gp("kick_done_topic", "/kick_done").value)
        self.bf_srv_name = str(
            gp("ball_follow_enable_srv", "/ball_follow_nav_node/enable").value)
        self.vs_srv_name = str(
            gp("visual_servo_enable_srv", "/visual_servo_kick_node/enable").value)
        self.game_stop_lock_topic = str(
            gp("game_stop_lock_topic", "game_stop_lock").value)

        # ── 통신 ──
        self.create_subscription(GameState, "/game_state", self._cb_game, 10)
        self.create_subscription(RoleAssignment, "/strategy/role", self._cb_role, 10)
        self.create_subscription(String, "/robot_state", self._cb_robot_state, 10)
        self.create_subscription(PointStamped, self.ball_topic, self._cb_ball, 10)
        self.create_subscription(String, self.bf_status_topic, self._cb_bf_status, 10)
        self.create_subscription(String, self.vs_state_topic, self._cb_vs_state, 10)
        self.create_subscription(Bool, self.kick_done_topic, self._cb_kick_done, 10)
        self.create_subscription(
            Bool, self.game_stop_lock_topic, self._cb_game_stop_lock, 10)

        # team_comm owner 선출 결과 구독(★Step2). team_comm_node 가 'zone 우선 + 백업'
        # 으로 단일 owner 를 뽑아 발행 → 여기선 그 결과만 소비한다.
        self.create_subscription(
            TeamComm, self.team_comm_state_topic, self._cb_team_comm, 10)

        self.state_pub = self.create_publisher(StrategyState, self.state_topic, 10)
        latched_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.marker_pub = self.create_publisher(MarkerArray, self.marker_topic, latched_qos)

        self._goal_pub = self.create_publisher(PoseStamped, self.pose_goal_topic, 10)
        self._pc_client = self.create_client(SetBool, self.pc_srv_name)
        self.create_subscription(
            String, self.pose_state_topic, self._cb_pose_state, 10)
        self._bf_client = self.create_client(SetBool, self.bf_srv_name)
        self._vs_client = self.create_client(SetBool, self.vs_srv_name)
        self._search_cmd_pub = self.create_publisher(
            Twist, self.ball_search_cmd_vel_topic, 10)
        self._neck_yaw_pub = self.create_publisher(Float32, self.neck_yaw_cmd_topic, 10)
        self._neck_pitch_pub = self.create_publisher(
            Float32, self.neck_pitch_cmd_topic, 10)

        # ── 내부 상태 ──
        self.game = None
        self.game_time = None
        self.role = None
        self.robot_state = None
        self._game_stop_locked = False

        self.ball_xy = None
        self.ball_stamp = None
        self.bf_status = None          # ball_follow 상태 문자열
        self.vs_state = None           # visual_servo 상태 문자열
        self._kick_done_time = None    # 마지막 /kick_done 수신 시각[s]

        # pose controller 포지셔닝 관리(READY/SUPPORT 공용)
        self._sent_target = None       # 마지막 발행한 (x, y)
        self._sent_yaw = None          # 마지막 발행한 yaw
        self._arrived = False          # pose controller 가 ARRIVED/BLOCKED 인지
        self._pose_state = None        # /pose_goal/state 최신값
        self._pc_driving = False       # strategy 가 지금 POSITION 주행 중인지(끄기 판정용)

        # 공 소유/오케스트레이션
        self._own_ball = False
        self._zone_change_since = None
        self._was_chasing = False
        self._owner_phase = "APPROACH"
        self._search_active = False
        self._search_started_s = None

        # 세트플레이 게이트 상태
        self._sp_onset = None          # 현재 set_play 진입 시각[s] (NONE 되면 리셋)
        self._sp_secondary_seen = False  # 이번 set_play 중 secondary_time>0 본 적 있나
        self._sp_phase = None          # 이번 tick 세트플레이 단계 라벨(None=세트플레이 아님)
        self._setplay_ready_token = None
        self._setplay_ready_started = False
        self._setplay_ready_done = False
        self._last_my_penalty = None
        self._penalty_reentry_ready_pending = False
        self._penalty_reentry_ready_started = False

        # team_comm owner 캐시(★Step2)
        self._tc_owner_player = 0      # /team_comm/state.ball_owner_player (0=없음)
        self._tc_active = 0            # 활성 로봇 수
        self._tc_any_ball_valid = False  # 활성 로봇 중 공을 보는 로봇이 하나라도 있는지
        self._tc_stamp = None         # 마지막 team_comm 수신 시각(통신 stale 판정용)
        self._owner_src = "-"          # 이번 tick owner 판정 소스: 'comm'|'zone'|'-' (마커/로그용)
        self._comm_owner_latched = 0
        self._comm_owner_candidate = None
        self._comm_owner_since = None

        # enable 캐시(None=미상 → 첫 호출 강제). 노드 기동 시 양쪽 강제 OFF 동기화.
        self._bf_enabled = None
        self._vs_enabled = None

        self._nav_warn_t = 0.0
        self.create_timer(1.0 / max(self.publish_rate, 1.0), self._tick)

        self.get_logger().info(
            f"strategy_fsm 시작 — player_number={self.player_number}, "
            f"arbitration_mode={self.arbitration_mode} "
            f"(team_comm='{self.team_comm_state_topic}', "
            f"stale={self.team_comm_stale_sec}s), "
            f"pose_goal='{self.pose_goal_topic}', pc_srv='{self.pc_srv_name}', "
            f"bf_srv='{self.bf_srv_name}', vs_srv='{self.vs_srv_name}' "
            f"(READY/SUPPORT=pose_goal + PLAYING=ball_follow/visual_servo)")

    # ----------------------------------------------------------------------
    #  유틸 / 콜백
    # ----------------------------------------------------------------------
    @staticmethod
    def _xy(v):
        try:
            return (float(v[0]), float(v[1]))
        except Exception:
            return (0.0, 0.0)

    @staticmethod
    def _dist(a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])

    @staticmethod
    def _angle_diff(a, b):
        return math.atan2(math.sin(a - b), math.cos(a - b))

    def _now_s(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _cb_game(self, msg):
        self.game = msg
        self.game_time = self.get_clock().now()
        my_penalty = self._my_penalty(msg)
        if my_penalty is not None:
            if (self._last_my_penalty is not None
                    and self._last_my_penalty != GameState.PENALTY_NONE
                    and my_penalty == GameState.PENALTY_NONE):
                self._penalty_reentry_ready_pending = True
                self._penalty_reentry_ready_started = False
            self._last_my_penalty = my_penalty
        # 세트플레이 게이트용 — set_play 종료 시 onset/래치 리셋, 준비 클럭 뜨면 래치.
        sp = int(msg.set_play)
        if sp == GameState.SET_PLAY_NONE:
            self._sp_onset = None
            self._sp_secondary_seen = False
            self._setplay_ready_token = None
            self._setplay_ready_started = False
            self._setplay_ready_done = False
        elif int(msg.secondary_time) > 0:
            self._sp_secondary_seen = True
            token = (sp, bool(msg.we_are_kicking))
            if self._setplay_ready_token != token:
                self._setplay_ready_token = token
                self._setplay_ready_started = False
                self._setplay_ready_done = False
        else:
            token = (sp, bool(msg.we_are_kicking))
            if self._setplay_ready_token != token:
                self._setplay_ready_token = token
                self._setplay_ready_started = False
                self._setplay_ready_done = False

    def _cb_role(self, msg):
        self.role = msg

    def _cb_robot_state(self, msg):
        self.robot_state = msg.data

    def _cb_ball(self, msg):
        x, y = float(msg.point.x), float(msg.point.y)
        if not (math.isfinite(x) and math.isfinite(y)):
            return
        self.ball_xy = (x, y)
        self.ball_stamp = self.get_clock().now()

    def _cb_bf_status(self, msg):
        self.bf_status = msg.data

    def _cb_vs_state(self, msg):
        self.vs_state = msg.data

    def _cb_kick_done(self, msg):
        if bool(msg.data):
            self._kick_done_time = self._now_s()
            if self.post_kick_settle > 0.0:
                self.get_logger().info(
                    f"kick_done -> post-kick settle {self.post_kick_settle:.1f}s")

    def _cb_game_stop_lock(self, msg):
        locked = bool(msg.data)
        if locked and not self._game_stop_locked:
            self._abort_for_game_stop_lock()
        self._game_stop_locked = locked

    def _abort_for_game_stop_lock(self):
        """Forget execution-phase memory when game_stop_lock turns on."""
        self._own_ball = False
        self._zone_change_since = None
        self._owner_src = "-"
        self._was_chasing = False
        self._owner_phase = "APPROACH"
        self._kick_done_time = None
        self.bf_status = None
        self.vs_state = None

        self._sp_onset = None
        self._sp_secondary_seen = False
        self._sp_phase = None
        self._setplay_ready_token = None
        self._setplay_ready_started = False
        self._setplay_ready_done = False
        self._penalty_reentry_ready_pending = False
        self._penalty_reentry_ready_started = False

        self._stop_ball_search()
        self._set_pc_enable(False)
        self._sent_target = None
        self._sent_yaw = None
        self._arrived = False
        self._pose_state = None
        self._pc_driving = False

        # Force child nodes to receive a fresh OFF even if our cache is stale.
        self._bf_enabled = None
        self._vs_enabled = None
        self._set_phase_enables(False, False)
        self.get_logger().warn(
            "game_stop_lock ON -> strategy phase/goal/action cache cleared")

    def _cb_team_comm(self, msg):
        """team_comm owner 선출 결과 캐시(★Step2).

        i_am_owner 를 그대로 믿지 않고 ball_owner_player==내 번호로 직접 판정한다
        — team_comm 의 player_number 가 내 설정과 어긋나도(오설정) 안전하게.
        """
        self._tc_owner_player = int(msg.ball_owner_player)
        self._tc_active = int(msg.active_count)
        self._tc_any_ball_valid = any(
            (not m.stale) and (not m.fallen) and bool(m.ball_valid)
            for m in msg.members)
        self._tc_stamp = self.get_clock().now()

    def _game_fresh(self):
        if self.game is None or self.game_time is None:
            return False
        dt = (self.get_clock().now() - self.game_time).nanoseconds * 1e-9
        return dt <= self.stale_timeout

    def _fresh_ball(self):
        """최근 ball_lost_timeout 안에 본 공 좌표(x,y) | None."""
        if self.ball_xy is None or self.ball_stamp is None:
            return None
        dt = (self.get_clock().now() - self.ball_stamp).nanoseconds * 1e-9
        if dt > self.ball_lost_timeout:
            return None
        return self.ball_xy

    def _team_comm_fresh(self):
        """team_comm 결과가 신선한지(통신 살아있는지). False 면 zone 폴백."""
        if self._tc_stamp is None:
            return False
        dt = (self.get_clock().now() - self._tc_stamp).nanoseconds * 1e-9
        return dt <= self.team_comm_stale_sec

    def _i_should_chase(self, ball):
        """PLAYING 에서 내가 공을 쫓아야(=owner) 하는가. (키퍼는 호출 전 제외)

        owner 판정 소스:
          · arbitration_mode='team_comm' & 통신 신선 → /team_comm/state 의
            ball_owner_player == 내 번호 (team_comm 이 'zone 우선+백업'을 이미 반영).
          · 그 외(zone_only, 또는 통신 stale 폴백) → 기존 zone 판정(+0.5s 디바운스).

        ★owner 여도 내 시야에 공이 없으면(ball is None) chase 불가 → False.
          ball_follow 가 내 공 인식을 쓰기 때문. 이땐 다음 election 에서 owner 가 넘어간다.
        부수효과: self._own_ball(마커/상태용), self._owner_src('comm'|'zone'|'-') 갱신.
        """
        if ball is None:
            self._own_ball = False
            self._zone_change_since = None
            self._reset_comm_owner_latch()
            self._owner_src = "-"
            return False

        use_comm = (self.arbitration_mode == "team_comm") and self._team_comm_fresh()
        if use_comm:
            self._owner_src = "comm"
            owner = self._comm_owner_decision(self._tc_owner_player)
            self._own_ball = (owner == self.player_number)
            # 폴백 경로의 디바운스 상태가 굳지 않도록 초기화(나중에 stale 되면 깨끗이 시작).
            self._zone_change_since = None
            return self._own_ball
        # 폴백 / zone_only: 기존 zone 판정(+0.5s 디바운스). _own_ball 은 내부에서 갱신.
        self._reset_comm_owner_latch()
        self._owner_src = "zone"
        return self._own_ball_decision(ball)

    def _reset_comm_owner_latch(self):
        self._comm_owner_latched = 0
        self._comm_owner_candidate = None
        self._comm_owner_since = None

    def _comm_owner_decision(self, raw_owner):
        """team_comm owner 도 너무 빨리 바뀌지 않도록 소비측에서 래치한다."""
        owner = int(raw_owner)
        now_s = self._now_s()

        if owner <= 0:
            self._reset_comm_owner_latch()
            return 0

        if self._comm_owner_latched == owner:
            self._comm_owner_candidate = None
            self._comm_owner_since = None
            return owner

        if self._comm_owner_candidate != owner:
            self._comm_owner_candidate = owner
            self._comm_owner_since = now_s
            return self._comm_owner_latched

        if (self._comm_owner_since is not None
                and now_s - self._comm_owner_since >= self.ownership_cooldown):
            self._comm_owner_latched = owner
            self._comm_owner_candidate = None
            self._comm_owner_since = None

        return self._comm_owner_latched

    def _team_has_ball_observation(self, ball):
        """True면 적어도 한 활성 로봇이 지금 공을 보고 있다."""
        if ball is not None:
            return True
        if (self.arbitration_mode == "team_comm") and self._team_comm_fresh():
            return self._tc_any_ball_valid
        return False

    def _my_penalty(self, msg):
        if not msg.team_found:
            return None
        idx = self.player_number - 1
        if 0 <= idx < len(msg.penalties):
            return int(msg.penalties[idx])
        return None

    def _is_inplace_restart_setplay(self):
        """home 복귀 없이 현재 자리에서 scan/재개할 set play."""
        return int(self.game.set_play) in (
            GameState.SET_PLAY_PENALTY_KICK,
            GameState.SET_PLAY_THROW_IN,
            GameState.SET_PLAY_GOAL_KICK,
            GameState.SET_PLAY_CORNER_KICK,
        )

    def _is_ball_search_robot(self):
        """전원 공 분실 때 search 동작을 수행할 로봇 번호."""
        return self.ball_search_enable and self.player_number in (1, 2, 3, 4)

    def _is_field_search_robot(self):
        """목 스캔 후 제자리 회전을 맡는 필드 로봇."""
        return self.player_number in (2, 3, 4)

    def _neck_sweep_yaw(self, elapsed_s, one_way):
        """-90↔90 목 스캔 yaw[deg]. one_way면 min→max 1회만 진행."""
        ymin = self.ball_search_neck_yaw_min_deg
        ymax = self.ball_search_neck_yaw_max_deg
        if one_way:
            span_s = max(self.ball_search_initial_scan_s, 0.1)
            r = max(0.0, min(1.0, elapsed_s / span_s))
            return ymin + (ymax - ymin) * r

        period = max(self.ball_search_period, 0.1)
        phase = (elapsed_s % period) / period
        if phase <= 0.5:
            return ymin + (ymax - ymin) * (phase / 0.5)
        return ymax - (ymax - ymin) * ((phase - 0.5) / 0.5)

    def _search_turn_pitch(self, turn_elapsed_s):
        """Body-turn search pitch: first turn low, then one more turn looking lower."""
        speed = abs(self.ball_search_turn_speed_z)
        if speed <= 1e-3:
            return self.ball_search_neck_pitch_deg
        one_turn_s = (2.0 * math.pi) / speed
        if turn_elapsed_s < one_turn_s:
            return self.ball_search_neck_pitch_deg
        return self.ball_search_neck_second_pitch_deg

    def _publish_search_neck(self, yaw_deg, pitch_deg=None):
        pitch = self.ball_search_neck_pitch_deg if pitch_deg is None else pitch_deg
        self._neck_pitch_pub.publish(Float32(data=float(pitch)))
        self._neck_yaw_pub.publish(Float32(data=float(yaw_deg)))

    def _publish_search_turn(self, angular_z):
        cmd = Twist()
        cmd.angular.z = float(angular_z)
        self._search_cmd_pub.publish(cmd)

    def _run_ball_search(self):
        """전원 공 분실 중 search 명령을 발행한다."""
        now_s = self._now_s()
        if not self._search_active:
            self._search_active = True
            self._search_started_s = now_s

        started_s = self._search_started_s if self._search_started_s is not None else now_s
        elapsed = now_s - started_s

        if self.player_number == 1:
            self._publish_search_neck(self._neck_sweep_yaw(elapsed, one_way=False))
            self._publish_search_turn(0.0)
            return

        if self._is_field_search_robot():
            if elapsed < max(self.ball_search_initial_scan_s, 0.1):
                self._publish_search_neck(self._neck_sweep_yaw(elapsed, one_way=True))
                self._publish_search_turn(0.0)
            else:
                turn_elapsed = elapsed - max(self.ball_search_initial_scan_s, 0.1)
                self._publish_search_neck(0.0, self._search_turn_pitch(turn_elapsed))
                self._publish_search_turn(self.ball_search_turn_speed_z)
            return

        self._publish_search_turn(0.0)

    def _stop_ball_search(self):
        """search에서 빠져나갈 때 몸 회전 명령을 확실히 끊는다."""
        if self._search_active:
            self._publish_search_turn(0.0)
        self._search_active = False
        self._search_started_s = None

    # ----------------------------------------------------------------------
    #  결정: (mode, payload)
    #    mode = 'IDLE' | 'STOP' | 'POSITION' | 'CHASE' | 'NO_OWNER' | 'BALL_SEARCH'
    #    payload(POSITION) = (x, y, yaw),  payload(others) = None
    # ----------------------------------------------------------------------
    def _decide(self):
        if not self._game_fresh() or self.role is None:
            return "IDLE", None

        # 안전 게이트: penalty/낙상이면 아무 것도 안 함
        my_active = bool(self.role.is_active)
        if (self.robot_state_active_only and self.robot_state is not None
                and self.robot_state != ROBOT_STATE_NORMAL):
            my_active = False
        if not my_active:
            self._own_ball = False
            self._zone_change_since = None
            return "IDLE", None

        state = int(self.game.state)

        if state == GameState.STATE_PLAYING and bool(self.game.stopped):
            self._own_ball = False
            self._zone_change_since = None
            return "STOP", None

        if state == GameState.STATE_PLAYING:
            ready_gate = self._penalty_reentry_ready_gate()
            if ready_gate is not None:
                return ready_gate

        # ── 세트플레이 게이트 ─────────────────────────────────────────────
        # PLAYING 인데 set_play 가 걸리면(공이 인플레이 아님) 일반 추격을 가로채고
        # 세트플레이 포지셔닝으로 분기한다. setplay_enable=false 면 무시(롤백).
        if self.setplay_enable and state == GameState.STATE_PLAYING:
            if int(self.game.set_play) != GameState.SET_PLAY_NONE:
                return self._decide_set_play()

        # ── READY: 킥오프 위치로 이동 ──
        if state == GameState.STATE_READY:
            self._own_ball = False
            tgt = self._ready_pos(self.role.role, bool(self.game.we_are_kicking))
            if tgt is None:
                return "IDLE", None
            return "POSITION", (tgt[0], tgt[1], self.ready_yaw)

        # ── PLAYING: owner 면 접근/킥, 아니면 home 지원 ──
        if state == GameState.STATE_PLAYING:
            ball = self._fresh_ball()
            is_keeper = (self.role.role == RoleAssignment.ROLE_GOALKEEPER)
            if (not is_keeper) and self._i_should_chase(ball):
                return "CHASE", None
            if not self._team_has_ball_observation(ball):
                self._own_ball = False
                self._zone_change_since = None
                if self._is_ball_search_robot():
                    return "BALL_SEARCH", None
                return "NO_OWNER", None
            # 비소유 / 키퍼 / 공없음(또는 owner 아님) → 역할 home 으로.
            #   ★home 도착 시 상대(공격) 골대를 바라본다(전방 주시). owner 전환/전개가
            #     일어나면 즉시 전방 플레이가 되도록. (세트플레이 키퍼는 _face_yaw 로 공 주시)
            self._own_ball = False
            hx, hy = float(self.role.home_x), float(self.role.home_y)
            yaw = self._attack_goal_yaw(hx, hy)
            return "POSITION", (hx, hy, yaw)

        # ── SET/INITIAL/FINISHED: 정지(락) ──
        self._own_ball = False
        self._zone_change_since = None
        return "IDLE", None

    def _ready_pos(self, role, we_kick):
        prefix = "ourkick" if we_kick else "oppkick"
        key = {
            RoleAssignment.ROLE_GOALKEEPER: f"ready_{prefix}_keeper",
            RoleAssignment.ROLE_A_CENTER: f"ready_{prefix}_a_center",
            RoleAssignment.ROLE_B_WING_POS: f"ready_{prefix}_b_wing",
            RoleAssignment.ROLE_C_WING_NEG: f"ready_{prefix}_c_wing",
            RoleAssignment.ROLE_B_ATTACK: f"ready_{prefix}_b_attack",
            RoleAssignment.ROLE_STRIKER_ROAM: f"ready_{prefix}_striker",
            RoleAssignment.ROLE_SUPPORTER: f"ready_{prefix}_striker",
        }.get(role)
        return self._ready.get(key) if key else None

    def _face_yaw(self, fx, fy, ball):
        """home(fx,fy) 에서 공을 바라보는 yaw. 공 없으면 +X(0)."""
        if not self.playing_face_ball or ball is None:
            return self.ready_yaw
        return math.atan2(ball[1] - fy, ball[0] - fx)

    def _attack_goal_yaw(self, fx, fy):
        """(fx,fy) 에서 상대(공격) 골대(attack_goal_x/y)를 바라보는 yaw.

        PLAYING 비소유 home 포지셔닝의 '전방(상대 골대) 주시'용. ready_yaw(map +X 고정)
        가 아니라 실제 골대 방향이라, 윙처럼 y 가 큰 위치에선 살짝 안쪽으로 틀어 골대를
        향한다. 좌표계가 팀 상대(상대 골=+x 고정)라 하프타임에도 이 값은 그대로다
        — attack_goal_x 를 사이드에 따라 뒤집을 필요가 없다.
        """
        return math.atan2(self.attack_goal_y - fy, self.attack_goal_x - fx)

    def _ready_position_for_current_game(self):
        tgt = self._ready_pos(self.role.role, bool(self.game.we_are_kicking))
        if tgt is None:
            return None
        return (tgt[0], tgt[1], self.ready_yaw)

    def _penalty_reentry_ready_gate(self):
        if not self._penalty_reentry_ready_pending:
            return None

        dest = self._ready_position_for_current_game()
        if dest is None:
            self._penalty_reentry_ready_pending = False
            self._penalty_reentry_ready_started = False
            return None

        if self._penalty_reentry_ready_started and self._arrived:
            self._penalty_reentry_ready_pending = False
            self._penalty_reentry_ready_started = False
            return None

        self._penalty_reentry_ready_started = True
        self._sp_phase = "PENALTY_REENTRY_READY"
        return "POSITION", dest

    def _setplay_ready_gate(self):
        token = (int(self.game.set_play), bool(self.game.we_are_kicking))
        if self._setplay_ready_token != token:
            self._setplay_ready_token = token
            self._setplay_ready_started = False
            self._setplay_ready_done = False

        if self._setplay_ready_done:
            return None

        dest = self._ready_position_for_current_game()
        if dest is None:
            self._setplay_ready_done = True
            return None

        if self._setplay_ready_started and self._arrived:
            self._setplay_ready_done = True
            return None

        self._setplay_ready_started = True
        self._sp_phase = "SETPLAY_READY"
        return "POSITION", dest

    # ----------------------------------------------------------------------
    #  세트플레이 결정 — 정지(STOP) → 타이밍 → 역할별 목적지(MOVE)
    # ----------------------------------------------------------------------
    def _decide_set_play(self):
        """PLAYING 중 set_play 동안의 (mode, payload) 결정.

        반환: ('IDLE', None)            = 정지(STOP),
              ('POSITION', (x,y,yaw))  = 목적지 이동(MOVE).
        부수효과: self._sp_phase 에 단계 라벨('SETPLAY_STOP'/'SETPLAY_MOVE') 기록
                  → _tick 이 보고용 phase 를 이 라벨로 덮어쓴다.
        """
        # 세트플레이 동안엔 공 소유(추격) 개념이 없다 → 리셋(마커/상태 일관성).
        self._own_ball = False
        self._zone_change_since = None

        # 진입 시각 래치(상승엣지). set_play=NONE 시 _cb_game 이 리셋한다.
        if self._sp_onset is None:
            self._sp_onset = self._now_s()
        held = self._now_s() - self._sp_onset

        # STOP→MOVE 게이트:
        #   · 최소 정지홀드(min_stop_sec) 는 무조건 채운다("일단 정지").
        #   · 그 뒤, secondary_time 클럭이 떴거나(준비 윈도우 활성) 폴백시간 경과 시 MOVE.
        gate = ((not self.setplay_use_secondary_gate)
                or self._sp_secondary_seen
                or (held >= self.setplay_secondary_fallback_sec))
        if held < self.setplay_min_stop_sec or not gate:
            self._sp_phase = "SETPLAY_STOP"
            return "IDLE", None

        ready_gate = self._setplay_ready_gate()
        if ready_gate is not None:
            return ready_gate

        # MOVE — 역할/주도권별 목적지.
        #   ★taker 접근(out_kick 통합): 우리 주도 + 내가 키커(공이 내 zone) + 접근허용이면
        #     정지 대기 대신 공까지 접근한다. 공이 라인 근처면 라인 바깥 목표점(POSITION,
        #     pose_goal_controller 가 최종 yaw 까지 정렬), 아니면 ball_follow 직진 접근(CHASE).
        #     ※킥은 _run_owner 가 세트플레이 중(_sp_phase!=None) 억제 → set_play 가 NONE 으로
        #       풀리는 순간 일반 CHASE 로 복귀하며 그때 visual_servo 가 킥한다("GC 신호로만 킥").
        ball = self._fresh_ball()
        if self._is_inplace_restart_setplay() and ball is None:
            if not self._team_has_ball_observation(ball) and self._is_ball_search_robot():
                self._sp_phase = "BALL_SEARCH"
                return "BALL_SEARCH", None
            self._sp_phase = "NO_OWNER"
            return "NO_OWNER", None

        is_taker = (bool(self.game.we_are_kicking)
                    and ball is not None
                    and int(self.role.role) != RoleAssignment.ROLE_GOALKEEPER
                    and self._raw_in_zone(ball))
        if is_taker and self.setplay_taker_approach:
            self._own_ball = True                 # 마커/상태 일관성(이 로봇이 이 공 처리 중)
            if int(self.game.set_play) in (
                    GameState.SET_PLAY_THROW_IN,
                    GameState.SET_PLAY_CORNER_KICK):
                self._sp_phase = "SETPLAY_APPROACH"
                return "CHASE", None
            if self._near_boundary(ball):
                # out_kick: 라인 바깥으로 나가 경기장 안쪽을 바라보는 목표점(pose_goal 이동).
                gx, gy, yaw = self._outside_goal(ball)
                self._sp_phase = "SETPLAY_OUTKICK"
                return "POSITION", (gx, gy, yaw)
            # pnt_kick: 라인에서 충분히 안쪽 → ball_follow 직진 접근(킥은 억제됨).
            self._sp_phase = "SETPLAY_APPROACH"
            return "CHASE", None

        # 그 외(키퍼 / 비키커 / 상대 주도 / 접근금지 롤백) — 기존 포지셔닝(정지 대기 성격).
        dest = self._setplay_dest()
        if dest is None:
            self._sp_phase = "SETPLAY_STOP"
            return "IDLE", None
        self._sp_phase = "SETPLAY_MOVE"
        return "POSITION", dest

    def _setplay_dest(self):
        """세트플레이 목적지 (x, y, yaw) | None.

        · 키퍼            : 골 앞 home + 공 바라봄(접근 안 함).
        · 공 분실         : 거리확보/standoff 계산 불가 → role home(공격방향). 안전.
        · 우리 주도 + 키커: 공이 내 zone(추격 owner 규칙과 동일) → 공 뒤 standoff.
        · 그 외           : keep-clear home(공 중심 clear_radius 밖).
        """
        role = int(self.role.role)
        home = (float(self.role.home_x), float(self.role.home_y))
        we_kick = bool(self.game.we_are_kicking)
        ball = self._fresh_ball()

        # 키퍼 — 항상 골 앞 home 유지, 공(있으면) 바라봄.
        if role == RoleAssignment.ROLE_GOALKEEPER:
            return home[0], home[1], self._face_yaw(home[0], home[1], ball)

        # 공 분실 — 어느 정책도 공 좌표가 필요 → 헛걸음 대신 role home 으로(공격방향).
        if ball is None:
            return home[0], home[1], self._face_yaw(home[0], home[1], None)

        # 우리 주도 + 내가 키커(공이 내 zone) — 공 뒤 standoff(킥 셋업).
        #   ※ _raw_in_zone 은 self.role.role 을 보고 판정(추격 owner 와 동일 규칙) →
        #     키커가 정확히 1명만 뽑힌다(zone 이 상호배타이므로).
        if we_kick and self._raw_in_zone(ball):
            return self._taker_setup(ball)

        # 비키커 / 상대 주도 — keep-clear home(공 거리확보).
        return self._keep_clear(home, ball)

    def _taker_setup(self, ball):
        """공 뒤 standoff(공격골–공 연장선) + 공 관통해 골대 바라보는 yaw. | None(퇴화)."""
        bx, by = ball
        agx, agy = self.attack_goal_x, self.attack_goal_y
        gbx, gby = (bx - agx), (by - agy)        # 공격골 → 공 벡터
        n = math.hypot(gbx, gby)
        if n < _SETPLAY_EPS:
            # 공이 골대에 거의 붙음 → 우리 골 방향을 기준선으로 폴백.
            ogx, ogy = -agx, -agy
            gbx, gby = (bx - ogx), (by - ogy)
            n = math.hypot(gbx, gby)
            if n < _SETPLAY_EPS:
                return None
        ux, uy = gbx / n, gby / n                # 골대에서 공을 향하는 단위벡터
        px = bx + self.taker_standoff * ux       # 공보다 골대에서 더 먼 쪽(공 뒤)
        py = by + self.taker_standoff * uy
        yaw = math.atan2(agy - py, agx - px)     # 공을 관통해 골대 바라봄
        return px, py, yaw

    def _keep_clear(self, home, ball):
        """home 을 공 중심 clear_radius 밖으로 밀어낸 좌표 + 공 바라보는 yaw."""
        hx, hy = home
        bx, by = ball
        dx, dy = (hx - bx), (hy - by)            # 공 → home 벡터
        dist = math.hypot(dx, dy)
        cr = self.clear_radius
        if dist >= cr:
            gx, gy = hx, hy                      # 이미 원 밖
        elif dist > _SETPLAY_EPS:
            ux, uy = dx / dist, dy / dist        # 공에서 home 쪽으로 밀어냄
            gx, gy = bx + cr * ux, by + cr * uy
        else:
            # home==공(퇴화) → 우리 골 방향(-attack_goal)으로 밀어냄.
            ogx, ogy = -self.attack_goal_x, -self.attack_goal_y
            vx, vy = (ogx - bx), (ogy - by)
            vn = math.hypot(vx, vy)
            if vn < _SETPLAY_EPS:
                vx, vy, vn = -1.0, 0.0, 1.0      # 최후 폴백: -x
            gx, gy = bx + cr * vx / vn, by + cr * vy / vn
        yaw = math.atan2(by - gy, bx - gx)       # 목적지에서 공 바라봄
        return gx, gy, yaw

    # ----------------------------------------------------------------------
    #  out_kick — 라인 근처 공 처리(라인 바깥에서 안쪽으로 킥할 자세)
    #    ※V1 out_kick_node 의 순수 계산부(_compute_outside_goal / _is_outside_boundary)
    #      만 이식. 이동은 pose_goal_controller, 킥은 visual_servo 가 하므로 여기선
    #      "어디 설지" 목표점만 계산한다(결정만, 메커니즘 없음).
    # ----------------------------------------------------------------------
    def _near_boundary(self, ball):
        """공이 가장 가까운 라인(골라인/사이드라인)에서 out_kick_band_m 이내인가.

        라인 밖(사이드아웃 직전)도 포함하도록 남은거리는 절댓값으로 잰다.
        True 면 직진 접근(공을 라인밖으로 차버릴 위험) 대신 라인 바깥 목표점을 쓴다.
        """
        bx, by = ball
        d_x = abs(self.field_half_length_x - abs(bx))   # 골라인(±x)까지 남은 거리
        d_y = abs(self.field_half_width_y - abs(by))    # 사이드라인(±y)까지 남은 거리
        return min(d_x, d_y) <= self.out_kick_band_m

    def _outside_goal(self, ball):
        """라인 근처 공에 대해 '라인 바깥 목표점' + '경기장 안쪽 바라보는 yaw'.

        가장 가까운 라인을 고르고, 그 라인 바깥 법선 방향으로 공에서 offset 만큼
        나간 점을 목표로 한다. yaw 는 그 지점에서 필드 안쪽을 바라보게 잡아, 도착
        즉시 공을 안쪽으로 찰 수 있는 자세가 된다.
        pose_goal_controller 가 SETTLE→ARRIVED 로 이 yaw 까지 정렬하므로, V1 의
        GOING_OUTSIDE + FINAL_ROTATING(이동 + cmd_vel 직접회전) 2단계가 목표점 하나로 접힌다.
        반환: (gx, gy, yaw). 항상 계산 가능(None 없음).
        """
        bx, by = ball
        hl = self.field_half_length_x
        hw = self.field_half_width_y
        # 후보: (라인까지 거리, 라인 바깥 법선(nx,ny), 필드 안쪽 바라보는 yaw)
        #   +x 골라인 밖 → 안쪽(-x) 봄(π) / -x → +x(0) / +y → -y(-π/2) / -y → +y(+π/2)
        candidates = [
            (abs(hl - bx), (1.0, 0.0), math.pi),
            (abs(-hl - bx), (-1.0, 0.0), 0.0),
            (abs(hw - by), (0.0, 1.0), -0.5 * math.pi),
            (abs(-hw - by), (0.0, -1.0), 0.5 * math.pi),
        ]
        _, (nx, ny), yaw = min(candidates, key=lambda c: c[0])
        # 공에서 라인 바깥 법선 방향으로 offset 만큼(공보다 라인 밖). margin/clearance 중 큰 값.
        offset = max(self.outside_margin_m, self.ball_clearance_m)
        return bx + nx * offset, by + ny * offset, yaw

    # ----------------------------------------------------------------------
    #  공 소유(zone) — 시간 디바운스로 경계 떨림 방지
    # ----------------------------------------------------------------------
    def _raw_in_zone(self, ball):
        role = self.role.role
        bx, by = ball
        dl = self.defense_line_x
        wy = self.wing_split_y
        if role == RoleAssignment.ROLE_STRIKER_ROAM:
            return True                          # 전구역
        if role == RoleAssignment.ROLE_A_CENTER:
            return bx < dl                       # 수비 third
        if role == RoleAssignment.ROLE_B_ATTACK:
            return bx >= dl                      # (3대) 수비 third 제외 전부
        if role == RoleAssignment.ROLE_B_WING_POS:
            return (bx < dl) and (by >= wy)      # 수비(우리진영) 좌 — 윙백
        if role == RoleAssignment.ROLE_C_WING_NEG:
            return (bx < dl) and (by < wy)       # 수비(우리진영) 우 — 윙백
        return False                             # GOALKEEPER/SUPPORTER/NONE

    def _own_ball_decision(self, ball):
        raw = self._raw_in_zone(ball)
        now_s = self._now_s()
        if raw != self._own_ball:
            if self._zone_change_since is None:
                self._zone_change_since = now_s
            elif now_s - self._zone_change_since >= self.ownership_cooldown:
                self._own_ball = raw
                self._zone_change_since = None
        else:
            self._zone_change_since = None
        return self._own_ball

    # ----------------------------------------------------------------------
    #  타이머
    # ----------------------------------------------------------------------
    def _tick(self):
        self._sp_phase = None        # 세트플레이 단계 라벨 초기화(_decide_set_play 가 채움)
        if self._game_stop_locked:
            self._was_chasing = False
            self._stop_position_drive()
            self._set_phase_enables(False, False)
            self._stop_ball_search()
            self.state_pub.publish(self._make_state("STOP"))
            self.marker_pub.publish(self._make_markers("STOP", None))
            return

        mode, payload = self._decide()

        if mode == "CHASE":
            self._stop_ball_search()
            self._stop_position_drive()          # 내 POSITION 주행 종료(ball_follow 가 pose 사용)
            phase = self._run_owner()
            target = None
        elif mode == "BALL_SEARCH":
            self._was_chasing = False
            self._stop_position_drive()
            self._set_phase_enables(False, False)
            self._run_ball_search()
            target = None
            phase = "BALL_SEARCH"
        elif mode == "NO_OWNER":
            self._was_chasing = False
            self._stop_position_drive()
            self._set_phase_enables(False, False)
            self._stop_ball_search()
            target = None
            phase = "NO_OWNER"
        elif mode == "POSITION":
            self._was_chasing = False
            self._stop_ball_search()
            self._set_phase_enables(False, False)
            self._drive_to((payload[0], payload[1]), payload[2])
            target = payload
            st = int(self.game.state) if self._game_fresh() else 0
            if st == GameState.STATE_PLAYING:
                phase = "SUPPORT"
            elif self._arrived:
                phase = "POSITION_DONE"
            else:
                phase = "POSITION"
        elif mode == "STOP":
            self._was_chasing = False
            self._stop_position_drive()
            self._set_phase_enables(False, False)
            self._stop_ball_search()
            target = None
            phase = "STOP"
        else:  # IDLE
            self._was_chasing = False
            self._stop_position_drive()
            self._set_phase_enables(False, False)
            self._stop_ball_search()
            target = None
            st = int(self.game.state) if self._game_fresh() else -1
            phase = "STOP" if st == GameState.STATE_SET else "IDLE"

        # 세트플레이 중이면 보고용 phase 를 전용 라벨로 덮어쓴다(STOP/SUPPORT 오인 방지).
        if self._sp_phase is not None:
            phase = self._sp_phase

        self.state_pub.publish(self._make_state(phase))
        self.marker_pub.publish(self._make_markers(phase, target))

    # ----------------------------------------------------------------------
    #  owner 오케스트레이션 (Phase2 ↔ Phase3)
    # ----------------------------------------------------------------------
    def _run_owner(self):
        now_s = self._now_s()
        if not self._was_chasing:
            self._owner_phase = "APPROACH"       # CHASE 진입 시 초기화
            self._was_chasing = True

        # ★세트플레이 킥 억제: set_play 진행 중(_sp_phase!=None)이면 접근만 하고 절대 킥 안 함.
        #   우리 세트플레이는 공을 건드려야 인플레이되지만, 킥 자체는 GC 가 set_play 를 NONE
        #   으로 풀어 인플레이를 선언한 뒤에만 한다("GC 신호로만 킥"). 그 순간 _decide 가 일반
        #   CHASE 로 복귀(_sp_phase=None)하며 아래 정상 핸드오프가 킥한다. 여기선 ALIGN_KICK
        #   진입/유지를 막고 ball_follow 접근(APPROACH)에 고정한다.
        setplay_hold = self._sp_phase is not None

        # 킥 직후 쿨다운: 막 킥했으면 재정렬 전에 재접근(공이 차여 멀어졌을 테니).
        in_cooldown = (self._kick_done_time is not None
                       and now_s - self._kick_done_time < self.kick_cooldown)
        in_post_kick_settle = (
            self._kick_done_time is not None
            and now_s - self._kick_done_time < self.post_kick_settle)

        # ── ALIGN_KICK 하드 래치 ─────────────────────────────────────
        # 한번 들어오면 visual_servo 가 정렬+킥을 끝낼 때까지 머문다.
        # ★bf_status 가 IDLE 로 바뀌어도(=ball_follow disable 부작용) 절대 APPROACH 로
        #   안 돌아간다. 이게 핵심 — 안 그러면 'ARRIVED→끔→IDLE→다시 ARRIVED' 진동.
        # 빠져나가는 건 /kick_done(킥 완료) 뿐. 공 분실/소유상실은 mode 가 CHASE 를
        # 벗어나며 _was_chasing 리셋 → 다음 CHASE 에서 APPROACH 로 새로 시작.
        if self._owner_phase == "ALIGN_KICK":
            if in_post_kick_settle:
                self._set_phase_enables(False, False)
                return "CHASE_KICK"
            if setplay_hold:
                # 세트플레이로 진입 — 킥 단계에서 접근으로 강등(visual_servo OFF, ball_follow ON).
                self._owner_phase = "APPROACH"
                self._set_phase_enables(True, False)
                return "SETPLAY_APPROACH"
            if self._kick_done_time is not None:
                self._owner_phase = "APPROACH"
                self.get_logger().info("킥 완료 → 재접근(APPROACH)")
                return "CHASE_APPROACH"
            self._set_phase_enables(False, True)         # visual_servo 유지(ball_follow OFF)
            if self._kick_done_time is not None:
                # 이번 킥 완료 → 재접근(cooldown 동안 APPROACH 에서 재핸드오프 차단).
                self._owner_phase = "APPROACH"
                self.get_logger().info("킥 완료 → 재접근(APPROACH)")
                return "CHASE_APPROACH"
            return "CHASE_KICK"

        # ── APPROACH ─────────────────────────────────────────────────
        if in_post_kick_settle:
            self._set_phase_enables(False, False)
            return "CHASE_KICK"
        self._set_phase_enables(True, False)             # ball_follow ON
        if setplay_hold:
            return "SETPLAY_APPROACH"                    # 세트플레이: 접근만, 킥 핸드오프 금지
        if (not in_cooldown) and self.bf_status == "ARRIVED":
            self._owner_phase = "ALIGN_KICK"
            self._kick_done_time = None                  # 이번 킥을 기다림(이전 흔적 제거)
            self.get_logger().info("ARRIVED → 핸드오프(ALIGN_KICK)")
            self._set_phase_enables(False, True)         # → visual_servo ON
            return "CHASE_KICK"
        return "CHASE_APPROACH"

    def _set_phase_enables(self, bf, vs):
        """ball_follow / visual_servo enable 토글(변화가 있을 때만 서비스 호출)."""
        if bf != self._bf_enabled and self._call_enable(self._bf_client, self.bf_srv_name, bf):
            self._bf_enabled = bf
        if vs != self._vs_enabled and self._call_enable(self._vs_client, self.vs_srv_name, vs):
            self._vs_enabled = vs

    def _call_enable(self, client, name, want):
        """SetBool ~/enable 비동기 호출. 서버 준비 안 됐으면 보류(다음 tick 재시도)."""
        if not client.service_is_ready():
            now = self._now_s()
            if now - self._nav_warn_t > 2.0:
                self.get_logger().warn(f"enable 서비스 '{name}' 대기 중 — 해당 노드 떠있는지 확인")
                self._nav_warn_t = now
            return False
        req = SetBool.Request()
        req.data = bool(want)
        client.call_async(req)
        self.get_logger().info(f"enable '{name}' → {'ON' if want else 'OFF'}")
        return True

    # ----------------------------------------------------------------------
    #  pose controller 포지셔닝 (READY/SUPPORT 공용) — Nav2 대체
    #    · 켜기: /pose_goal 발행 → pose_goal_controller 가 auto_enable 로 켜짐.
    #    · 끄기: strategy 가 POSITION 주행을 멈출 때만 ~/enable(false) 호출.
    #  ★소유권: POSITION 은 strategy 가, PLAYING CHASE 는 ball_follow 가 pose 를 몬다.
    #    mode 배타라 동시 점유 없음. strategy 는 자기 POSITION 주행 종료 시에만 끈다.
    # ----------------------------------------------------------------------
    def _cb_pose_state(self, msg):
        """pose controller 상태 캐시 — POSITION 도착/막힘 판정."""
        self._pose_state = msg.data
        self._arrived = msg.data in ("ARRIVED", "BLOCKED")

    def _set_pc_enable(self, on):
        """pose_ctrl ~/enable 호출. 서버 준비 안 됐으면 False 반환(다음 tick 재시도)."""
        if not self._pc_client.service_is_ready():
            now = self._now_s()
            if now - self._nav_warn_t > 2.0:
                self.get_logger().warn(
                    f"pose_ctrl '{self.pc_srv_name}' 대기 중 — pose_goal_controller 확인")
                self._nav_warn_t = now
            return False
        req = SetBool.Request()
        req.data = bool(on)
        self._pc_client.call_async(req)
        return True

    def _drive_to(self, target, yaw):
        """POSITION 목적지로 /pose_goal 발행(자동 enable). 같은 목표면 재발행 생략."""
        same_xy = (self._sent_target is not None
                   and self._dist(self._sent_target, target) <= self.resend_threshold)
        same_yaw = (self._sent_yaw is not None
                    and abs(self._angle_diff(self._sent_yaw, yaw))
                    <= self.resend_yaw_threshold)
        if same_xy and same_yaw and self._pc_driving:
            return  # 같은 목표 — pose controller 가 유지(스팸 방지)
        self._goal_pub.publish(self._pose_stamped(target, yaw))
        self._sent_target = target
        self._sent_yaw = yaw
        self._arrived = False
        self._pc_driving = True
        self.get_logger().info(
            f"POSITION goal 발행 → ({target[0]:.2f}, {target[1]:.2f})")

    def _stop_position_drive(self):
        """내 POSITION 주행 종료 → pose controller 정지(enable false).

        주행 중일 때만 끈다(서비스 미준비 시 다음 tick 재시도). PLAYING CHASE 로
        넘어갈 땐 여기서 끈 뒤 ball_follow 가 /pose_goal 발행으로 다시 켠다.
        """
        if not self._pc_driving:
            self._sent_target = None
            self._sent_yaw = None
            return
        if self._set_pc_enable(False):
            self._pc_driving = False
            self._sent_target = None
            self._sent_yaw = None
            self._arrived = False

    # ----------------------------------------------------------------------
    #  메시지/마커
    # ----------------------------------------------------------------------
    def _now_header(self):
        h = Header()
        h.stamp = self.get_clock().now().to_msg()
        h.frame_id = self.map_frame
        return h

    def _yaw_quat(self, yaw):
        return Quaternion(x=0.0, y=0.0, z=math.sin(yaw / 2.0), w=math.cos(yaw / 2.0))

    def _pose_stamped(self, target, yaw):
        ps = PoseStamped()
        ps.header = self._now_header()
        ps.pose.position = Point(x=float(target[0]), y=float(target[1]), z=0.0)
        ps.pose.orientation = self._yaw_quat(yaw)
        return ps

    def _make_state(self, phase):
        s = StrategyState()
        s.header = self._now_header()
        s.game_state = int(self.game.state) if self._game_fresh() else 0
        s.strategy_phase = phase
        s.role = self.role if self.role is not None else RoleAssignment()
        ball = self._fresh_ball()
        s.ball_valid = ball is not None
        s.ball_in_my_zone = bool(self._own_ball)
        s.ball_map_x = float(ball[0]) if ball is not None else 0.0
        s.ball_map_y = float(ball[1]) if ball is not None else 0.0
        return s

    def _make_markers(self, phase, target):
        arr = MarkerArray()
        h = self._now_header()

        def base(mid, mtype):
            m = Marker()
            m.header = h
            m.ns = self.marker_ns
            m.id = mid
            m.type = mtype
            m.action = Marker.ADD
            m.pose.orientation.w = 1.0
            return m

        # 1/2) 이동 목표(화살표+텍스트) — POSITION/SUPPORT 일 때만
        if target is not None:
            r, g, b = (0.2, 0.85, 0.3) if self._arrived else (1.0, 0.82, 0.1)
            ar = base(1, Marker.ARROW)
            ar.pose.position = Point(x=float(target[0]), y=float(target[1]), z=0.03)
            ar.pose.orientation = self._yaw_quat(target[2])
            ar.scale.x, ar.scale.y, ar.scale.z = 0.30, 0.06, 0.06
            ar.color = ColorRGBA(r=r, g=g, b=b, a=0.95)
            arr.markers.append(ar)
            tx = base(2, Marker.TEXT_VIEW_FACING)
            tx.pose.position = Point(x=float(target[0]), y=float(target[1]), z=0.25)
            tx.scale.z = 0.13
            tx.color = ColorRGBA(r=r, g=g, b=b, a=1.0)
            rn = self.role.role_name if self.role is not None else "?"
            tx.text = f"{rn} [{phase}]"
            arr.markers.append(tx)
        else:
            for mid in (1, 2):
                d = base(mid, Marker.ARROW)
                d.action = Marker.DELETE
                arr.markers.append(d)

        # 3/4) 공 마커(소유=빨강, 비소유=회색) + 텍스트
        ball = self._fresh_ball()
        if ball is not None:
            mine = self._own_ball
            br, bg, bb = (0.95, 0.2, 0.2) if mine else (0.6, 0.6, 0.6)
            bs = base(3, Marker.SPHERE)
            bs.pose.position = Point(x=float(ball[0]), y=float(ball[1]), z=0.05)
            sz = 0.12 if mine else 0.09
            bs.scale.x, bs.scale.y, bs.scale.z = sz, sz, sz
            bs.color = ColorRGBA(r=br, g=bg, b=bb, a=0.9)
            arr.markers.append(bs)
            if mine:
                bt = base(4, Marker.TEXT_VIEW_FACING)
                bt.pose.position = Point(x=float(ball[0]), y=float(ball[1]), z=0.22)
                bt.scale.z = 0.12
                bt.color = ColorRGBA(r=br, g=bg, b=bb, a=1.0)
                bt.text = f"OWNER [{phase}] ({self._owner_src})"
                arr.markers.append(bt)
            else:
                d = base(4, Marker.TEXT_VIEW_FACING)
                d.action = Marker.DELETE
                arr.markers.append(d)
        else:
            for mid in (3, 4):
                d = base(mid, Marker.SPHERE)
                d.action = Marker.DELETE
                arr.markers.append(d)

        # 5) 세트플레이 keep-out 원(공 중심 clear_radius) — 비키커 정지/포지셔닝 단계에서만.
        #    비키커가 이 빨강 원 밖에 목적지를 잡는지 RViz 로 확인. taker 접근 단계
        #    (SETPLAY_OUTKICK / SETPLAY_APPROACH)에선 공에 다가가는 게 정상이라 원을
        #    숨긴다(공에서 멀어지라는 표시와 모순되지 않게).
        circ = base(5, Marker.LINE_STRIP)
        if self._sp_phase in ("SETPLAY_STOP", "SETPLAY_MOVE") and ball is not None:
            circ.scale.x = 0.02
            circ.color = ColorRGBA(r=1.0, g=0.3, b=0.1, a=0.85)
            seg = 48
            for i in range(seg + 1):
                a = 2.0 * math.pi * i / seg
                circ.points.append(Point(
                    x=float(ball[0]) + self.clear_radius * math.cos(a),
                    y=float(ball[1]) + self.clear_radius * math.sin(a), z=0.02))
        else:
            circ.action = Marker.DELETE
        arr.markers.append(circ)

        return arr


def main(args=None):
    rclpy.init(args=args)
    node = StrategyFsm()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
