"""Verify metadata-only repair, rejection, idempotence, and rollback."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import repair_xm540_walk_limits as tool


class RepairTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root/'tensorrt').mkdir()
        self.pt = b'fake checkpoint for transactional tests'
        self.engine = b'fake engine for transactional tests'
        self.sha = hashlib.sha256(self.pt).hexdigest()
        self.esh = hashlib.sha256(self.engine).hexdigest()
        (self.root/'RL_walk.pt').write_bytes(self.pt)
        (self.root/'tensorrt/RL_walk.engine').write_bytes(self.engine)
        source = {'role': 'walk', 'observation_size': 355, 'step_dt': 0.02,
                  'checkpoint_sha256': self.sha, 'command_limits': tool.OLD_LIMITS,
                  'untouched_metadata': {'array': [1, 2, 3]}}
        deployed = dict(source, engine_sha256=self.esh, engine_verified=True, deployment_contract_available=True)
        for path, doc in [('RL_walk.json', source), ('tensorrt/RL_walk.json', deployed),
                          ('tensorrt/RL_walk.build.json', deployed)]:
            (self.root/path).write_text(json.dumps(doc), encoding='utf-8')
        (self.root/'RL_fall_after_walk.json').write_bytes(b'recovery must not change')
        self.before = {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}

    def tearDown(self):
        self.temp.cleanup()

    def apply(self):
        with patch.object(tool, 'ensure_policy_stopped'):
            return tool.repair(self.root, apply=True, expected_checkpoint=self.sha)

    def test_only_limits_change_and_backup_is_exact_and_retry_is_idempotent(self):
        result = self.apply()
        self.assertEqual(result['status'], 'REPAIRED_AND_VERIFIED')
        for name in ('RL_walk.json', 'tensorrt/RL_walk.json'):
            old = json.loads(self.before[name])
            self.assertEqual(json.loads((self.root/name).read_bytes()), dict(old, command_limits=tool.TRAINING_LIMITS))
            self.assertEqual((Path(result['backup'])/name).read_bytes(), self.before[name])
        for name in ('RL_walk.pt', 'tensorrt/RL_walk.engine', 'tensorrt/RL_walk.build.json', 'RL_fall_after_walk.json'):
            self.assertEqual((self.root/name).read_bytes(), self.before[name])
        self.assertEqual(self.apply()['status'], 'ALREADY_CORRECT')

    def test_inspect_does_not_create_backup_or_modify_files(self):
        self.assertEqual(tool.repair(self.root, expected_checkpoint=self.sha)['status'], 'INSPECTED_NO_FILES_CHANGED')
        self.assertFalse((self.root/'archive').exists())
        for name, raw in self.before.items():
            self.assertEqual((self.root/name).read_bytes(), raw)

    def test_wrong_checkpoint_or_engine_rejected_before_any_write(self):
        with self.assertRaisesRegex(ValueError, '0902'):
            tool.repair(self.root, apply=True)
        (self.root/'tensorrt/RL_walk.engine').write_bytes(b'changed engine')
        with self.assertRaisesRegex(ValueError, 'Engine hash'):
            self.apply()
        self.assertFalse((self.root/'archive').exists())

    def test_other_contract_mismatch_rejected(self):
        path = self.root/'tensorrt/RL_walk.json'
        doc = json.loads(path.read_bytes())
        doc['gait_period'] = 99
        path.write_text(json.dumps(doc))
        with self.assertRaisesRegex(ValueError, 'other policy fields'):
            self.apply()
        self.assertFalse((self.root/'archive').exists())

    def test_failure_during_second_replace_rolls_back_first(self):
        real_write = tool.atomic_write
        calls = 0
        def fail_second(path, raw):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise OSError('injected write failure')
            return real_write(path, raw)
        with patch.object(tool, 'atomic_write', side_effect=fail_second):
            with self.assertRaisesRegex(OSError, 'injected'):
                self.apply()
        for name, raw in self.before.items():
            self.assertEqual((self.root/name).read_bytes(), raw)
        manifest = next((self.root/'archive').glob('*/repair_manifest.json'))
        self.assertEqual(json.loads(manifest.read_bytes())['status'], 'ROLLED_BACK')

    def test_policy_process_guard(self):
        proc = self.root/'proc'
        (proc/'123').mkdir(parents=True)
        (proc/'123/cmdline').write_bytes(b'python3\0/home/user/lib/humanoid_policy_runner/xm540_dual_policy\0')
        with self.assertRaisesRegex(RuntimeError, 'PID 123'):
            tool.ensure_policy_stopped(proc)
        (proc/'123/cmdline').write_bytes(b'python3\0-\0--models\0/home/models\0')
        tool.ensure_policy_stopped(proc)


if __name__ == '__main__':
    unittest.main()
