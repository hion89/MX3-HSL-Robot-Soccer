"""Repair command metadata for the verified 2026-09-02 WALK checkpoint only.

Standard library only; no ROS node, inference, serial port, or motor command.
Default is inspection. --apply requires the XM540 policy process to be stopped.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile


CHECKPOINT_SHA256 = '9ac0d65d4c27e8d95c05f3e350ec39b0b322c21f345ca30bab26ad1a9dcdd1b8'
TRAINING_ENV_SHA256 = '584b76b7bb1263f16c16c86eb26ea5d41473121c03edc3f1ac55e2fc95895219'
OLD_LIMITS = [[-0.3, 0.7], [-0.2, 0.2], [-0.3, 0.3]]
TRAINING_LIMITS = [[-0.15, 0.35], [-0.1, 0.1], [-0.15, 0.15]]
COMMON_FIELDS = (
    'schema_version', 'role', 'task', 'joint_names', 'default_joint_pos',
    'action_scale', 'action_clip', 'lower_limits', 'upper_limits',
    'step_dt', 'gait_period', 'activation', 'history_layout', 'terms', 'observation_size',
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ensure_policy_stopped(proc_root=Path('/proc')):
    if not proc_root.is_dir():
        raise RuntimeError('--apply requires a Linux /proc process check')
    blocked = {'xm540_dual_policy', 'xm540_dual_policy_node.py', 'xm540_dual_policy.launch.py',
               'humanoid_policy_runner.xm540_dual_policy_node'}
    for process in proc_root.iterdir():
        if not process.name.isdigit():
            continue
        try:
            arguments = (process / 'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        if any(Path(os.fsdecode(arg)).name in blocked for arg in arguments if arg):
            raise RuntimeError(f'Stop the XM540 policy/launch process first (PID {process.name})')


def atomic_write(path, data):
    permissions = stat.S_IMODE(path.stat().st_mode)
    fd, name = tempfile.mkstemp(prefix=path.name+'.', suffix='.tmp', dir=path.parent)
    candidate = Path(name)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(candidate, permissions)
        os.replace(candidate, path)
    finally:
        candidate.unlink(missing_ok=True)


def repair(models, apply=False, expected_checkpoint=CHECKPOINT_SHA256):
    models = Path(models).resolve()
    paths = [models/'RL_walk.json', models/'tensorrt/RL_walk.json']
    originals = [p.read_bytes() for p in paths]
    documents = [json.loads(raw) for raw in originals]
    checkpoint_hash = digest((models/'RL_walk.pt').read_bytes())
    engine_hash = digest((models/'tensorrt/RL_walk.engine').read_bytes())
    build = json.loads((models/'tensorrt/RL_walk.build.json').read_bytes())
    if checkpoint_hash != expected_checkpoint:
        raise ValueError('This repair only supports the verified 0902 WALK checkpoint')
    for path, doc in zip(paths, documents):
        if doc.get('checkpoint_sha256') != checkpoint_hash:
            raise ValueError(f'Checkpoint identity mismatch: {path}')
        if doc.get('role') != 'walk' or doc.get('observation_size') != 355 or doc.get('step_dt') != 0.02:
            raise ValueError(f'Unexpected WALK contract: {path}')
        if doc.get('command_limits') not in (OLD_LIMITS, TRAINING_LIMITS):
            raise ValueError(f'Unexpected command limits; inspect instead of overwriting: {path}')
    if any(documents[0].get(key) != documents[1].get(key) for key in COMMON_FIELDS):
        raise ValueError('Source and engine contracts disagree on other policy fields')
    if documents[1].get('engine_sha256') != engine_hash or build.get('engine_sha256') != engine_hash:
        raise ValueError('Engine hash mismatch')
    if build.get('checkpoint_sha256') != checkpoint_hash:
        raise ValueError('Build report belongs to another checkpoint')
    if any(doc.get(key) is not True for doc in (documents[1], build)
           for key in ('engine_verified', 'deployment_contract_available')):
        raise ValueError('Engine/contract verification flags are not true')

    result = {'apply': apply, 'checkpoint_sha256': checkpoint_hash,
              'before': {str(p): d['command_limits'] for p, d in zip(paths, documents)},
              'expected_command_limits': TRAINING_LIMITS, 'backup': None}
    if not apply:
        result['status'] = 'INSPECTED_NO_FILES_CHANGED'
        return result
    ensure_policy_stopped()
    if all(doc['command_limits'] == TRAINING_LIMITS for doc in documents):
        result['status'] = 'ALREADY_CORRECT'
        return result
    if any(path.read_bytes() != raw for path, raw in zip(paths, originals)):
        raise RuntimeError('Contract changed during inspection; no repair applied')

    archive = models/'archive'
    archive.mkdir(exist_ok=True)
    prefix = 'walk_limits_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ_')
    backup = Path(tempfile.mkdtemp(prefix=prefix, dir=archive))
    manifest = {'checkpoint_sha256': checkpoint_hash, 'engine_sha256': engine_hash,
                'training_env_sha256': TRAINING_ENV_SHA256, 'changed_field': 'command_limits',
                'new_limits': TRAINING_LIMITS, 'files': []}
    updated = []
    for path, raw, doc in zip(paths, originals, documents):
        relative = path.relative_to(models)
        destination = backup/relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        changed = dict(doc, command_limits=TRAINING_LIMITS)
        data = (json.dumps(changed, indent=2, ensure_ascii=False)+'\n').encode('utf-8')
        updated.append(data)
        manifest['files'].append({'path': str(relative), 'before_sha256': digest(raw), 'after_sha256': digest(data)})
    manifest_path = backup/'repair_manifest.json'
    manifest['status'] = 'PREPARED'
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
    written = []
    try:
        for path, data in zip(paths, updated):
            atomic_write(path, data)
            written.append(path)
        for path, raw, old in zip(paths, updated, documents):
            actual = json.loads(path.read_bytes())
            if path.read_bytes() != raw or actual != dict(old, command_limits=TRAINING_LIMITS):
                raise RuntimeError(f'Readback mismatch: {path}')
        if digest((models/'RL_walk.pt').read_bytes()) != checkpoint_hash or digest((models/'tensorrt/RL_walk.engine').read_bytes()) != engine_hash:
            raise RuntimeError('Checkpoint/engine changed during repair')
    except Exception as exc:
        for path, raw in zip(paths, originals):
            if path in written:
                atomic_write(path, raw)
        manifest['status'] = 'ROLLED_BACK'
        manifest['error'] = str(exc)
        manifest_path.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
        raise
    manifest['status'] = 'VERIFIED'
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
    result.update(status='REPAIRED_AND_VERIFIED', backup=str(backup),
                  after={str(p): json.loads(p.read_bytes())['command_limits'] for p in paths})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--models', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        result = repair(args.models, args.apply)
    except (OSError, ValueError, RuntimeError) as exc:
        parser.exit(1, f'REPAIR FAILED: {exc}\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
