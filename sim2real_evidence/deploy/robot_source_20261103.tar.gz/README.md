# Sim-to-Real 실행 워크스페이스

기존 `Sim to real sample`의 ROS 2 패키지를 이 워크스페이스의 `src/`로 옮겼습니다.
학습 코드와 로봇 자산은 상위의 `robotmodel/`, `unitree_rl_lab/`에서 관리합니다.

현재 우선 작업은 2026-10-07 실물 적용 실패를 분석하고 기존 학습 결과를 실물에 적용하는 것입니다.
[XM540 실물 적용 계획](docs/XM540_REAL_DEPLOYMENT_PLAN.md)에서 확인된 실패 근거,
모델 고정·배포 점검·관절/부하 시험·Preview·영속도 시험의 순서와 판정 기준을 확인합니다.

## 구조와 모델 적용 매뉴얼

ZED Mini 카메라(SDK 확인 시리얼 19124660)의 로봇 보드 영상·깊이 수신과 CPU 부하 비교는
[독립 카메라 테스트 환경](zed_mini_test/README.md)을 사용합니다. 해당 폴더만 로봇으로 복사해서 실행할 수 있습니다.

백업 RoboCup 모델로 ZED 영상 검출·브라우저 시각화 및 추가 CPU/GPU 부하를 비교하려면
[검출 테스트 안내](zed_mini_test/detection/README.md)를 사용합니다.

학습, 체크포인트 선택, 규격 추출, Jetson TensorRT 변환, 토크 ON/OFF, Preview와
실제 모터 정책 실행까지 이어지는 작업은
[XM540 학습부터 Jetson 실물 구동까지 통합 매뉴얼](docs/XM540_END_TO_END_MANUAL.md)을 따릅니다.

XM540 두 체크포인트의 연결은 [보행·버티기 정책 적용](docs/XM540_WALK_RECOVERY.md)을 따릅니다.
전용 러너, Ubuntu 규격 추출, 전환 각도 파라미터와 추론 확인 명령을 설명합니다.

[Sim-to-Real 구조와 모델 적용 매뉴얼](docs/SIM_TO_REAL_MANUAL.md)에서 계층별 역할,
하위 폴더·토픽의 연결, 모델 규격 관리, 새 학습 모델 적용 절차와 기록 양식을 확인할 수 있습니다.

```text
sim2real_ws/
├─ src/
│  ├─ humanoid_behavior_interfaces/  # 공통 메시지·서비스
│  ├─ humanoid_bringup/              # 통합 실행·로봇별 설정
│  ├─ humanoid_game_controller/      # 경기 상태 처리
│  ├─ humanoid_localization/         # 위치 추정·내비게이션
│  ├─ humanoid_perception/           # 카메라·물체 인식
│  ├─ humanoid_policy_runner/        # ONNX 정책 실행·모델
│  ├─ humanoid_serial_bridge/        # 모터·IMU 통신
│  ├─ humanoid_strategy/             # 상위 전략
│  └─ humanoid_utils/                # 보정·실험 도구
├─ build/                           # 빌드 시 생성
├─ install/                         # 빌드 시 생성
└─ log/                             # 빌드 시 생성
```

## 빌드 위치

ROS 2와 패키지 의존성이 설치된 Linux 실행 환경에서, 해당 ROS 2 환경을 먼저
source한 뒤 이 디렉터리(`sim2real_ws`)에서 빌드합니다.

```bash
colcon build --symlink-install
```

빌드 후 새 터미널에서 ROS 2 환경과 이 워크스페이스를 source합니다.

```bash
source install/setup.bash
```

## 모델과 설정 위치

- 정책 모델: `src/humanoid_policy_runner/models/`
- 정책 실행기: `src/humanoid_policy_runner/humanoid_policy_runner/`
- 통합 실행: `src/humanoid_bringup/launch/`
- 로봇별 설정: `src/humanoid_bringup/config/robot_params.yaml`
- 모터 매핑·게인: `src/humanoid_serial_bridge/config/`

이번 정리는 폴더 배치만 변경했습니다. 학습한 XM540 모델을 적용하려면 해당
체크포인트의 관측 순서, 관절 순서, 기준 자세, 행동 배율에 실행기를 맞춰야 합니다.
폴더 이동 자체가 모델 호환성을 보장하지는 않습니다.
